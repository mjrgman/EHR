// ============================================================================
// PATIENT DATABASE GENERATOR
// Generates 100 diverse, realistic patients for medical system
// ============================================================================

// Helper functions for random selection
const randomChoice = (array) => array[Math.floor(Math.random() * array.length)];
const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const randomFloat = (min, max, decimals = 1) => 
  parseFloat((Math.random() * (max - min) + min).toFixed(decimals));

// Name generators
const FIRST_NAMES = {
  M: ['James', 'John', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Joseph', 'Thomas', 'Charles',
      'Christopher', 'Daniel', 'Matthew', 'Anthony', 'Donald', 'Mark', 'Paul', 'Steven', 'Andrew', 'Kenneth',
      'Joshua', 'Kevin', 'Brian', 'George', 'Edward', 'Ronald', 'Timothy', 'Jason', 'Jeffrey', 'Ryan'],
  F: ['Mary', 'Patricia', 'Jennifer', 'Linda', 'Barbara', 'Elizabeth', 'Susan', 'Jessica', 'Sarah', 'Karen',
      'Nancy', 'Lisa', 'Betty', 'Margaret', 'Sandra', 'Ashley', 'Dorothy', 'Kimberly', 'Emily', 'Donna',
      'Michelle', 'Carol', 'Amanda', 'Melissa', 'Deborah', 'Stephanie', 'Rebecca', 'Laura', 'Sharon', 'Cynthia']
};

const LAST_NAMES = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez',
  'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin',
  'Lee', 'Perez', 'Thompson', 'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
  'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen', 'Hill', 'Flores'
];

// Clinical condition templates
const CONDITIONS = {
  // Acute conditions (simple)
  acute: [
    {
      name: 'Acute Sinusitis',
      problems: ['Acute bacterial sinusitis'],
      medications: [
        { name: 'Amoxicillin-Clavulanate', dose: '875mg', frequency: 'BID', duration: '10 days' }
      ],
      complexity: 'low',
      alerts: []
    },
    {
      name: 'Upper Respiratory Infection',
      problems: ['Acute viral URI'],
      medications: [
        { name: 'Pseudoephedrine', dose: '60mg', frequency: 'q6h PRN', duration: 'PRN' }
      ],
      complexity: 'low',
      alerts: []
    },
    {
      name: 'Acute Bronchitis',
      problems: ['Acute bronchitis'],
      medications: [
        { name: 'Benzonatate', dose: '200mg', frequency: 'TID PRN', duration: 'PRN' },
        { name: 'Albuterol inhaler', dose: '2 puffs', frequency: 'q4h PRN', duration: 'PRN' }
      ],
      complexity: 'low',
      alerts: []
    },
    {
      name: 'UTI',
      problems: ['Uncomplicated UTI'],
      medications: [
        { name: 'Nitrofurantoin', dose: '100mg', frequency: 'BID', duration: '5 days' }
      ],
      complexity: 'low',
      alerts: []
    },
    {
      name: 'Gastroenteritis',
      problems: ['Acute gastroenteritis'],
      medications: [
        { name: 'Ondansetron', dose: '4mg', frequency: 'q8h PRN', duration: 'PRN' }
      ],
      complexity: 'low',
      alerts: []
    }
  ],

  // Chronic single condition (moderate)
  chronic_single: [
    {
      name: 'Hypertension Only',
      problems: ['Essential Hypertension'],
      medications: [
        { name: 'Lisinopril', dose: '20mg', frequency: 'daily', active: true }
      ],
      labs: {
        bp: [{ date: '2024-10-01', systolic: randomInt(125, 145), diastolic: randomInt(75, 90) }]
      },
      complexity: 'low',
      alerts: []
    },
    {
      name: 'Hyperlipidemia Only',
      problems: ['Hyperlipidemia'],
      medications: [
        { name: 'Atorvastatin', dose: '40mg', frequency: 'daily', active: true }
      ],
      labs: {
        ldl: [{ date: '2024-10-01', value: randomInt(100, 140) }]
      },
      complexity: 'low',
      alerts: []
    },
    {
      name: 'Hypothyroidism',
      problems: ['Hypothyroidism'],
      medications: [
        { name: 'Levothyroxine', dose: '100mcg', frequency: 'daily', active: true }
      ],
      labs: {
        tsh: [{ date: '2024-10-01', value: randomFloat(1.5, 4.5) }]
      },
      complexity: 'low',
      alerts: []
    }
  ],

  // Multiple chronic conditions (moderate-high)
  chronic_multiple: [
    {
      name: 'Diabetes + HTN',
      problems: ['Type 2 Diabetes Mellitus', 'Hypertension', 'Prediabetes'],
      medications: [
        { name: 'Metformin', dose: '1000mg', frequency: 'BID', active: true },
        { name: 'Lisinopril', dose: '20mg', frequency: 'daily', active: true },
        { name: 'Atorvastatin', dose: '20mg', frequency: 'daily', active: true }
      ],
      labs: {
        a1c: [{ date: '2024-10-01', value: randomFloat(6.5, 9.5) }],
        glucose: [{ date: '2024-10-01', value: randomInt(120, 250) }],
        creatinine: [{ date: '2024-10-01', value: randomFloat(0.9, 1.4) }],
        egfr: [{ date: '2024-10-01', value: randomInt(55, 90) }]
      },
      complexity: 'moderate',
      alerts: function(labs) {
        const alerts = [];
        if (labs.a1c[0].value > 8) alerts.push('A1C above goal - consider intensifying therapy');
        if (labs.egfr[0].value < 60) alerts.push('CKD Stage 3 - monitor closely');
        return alerts;
      }
    },
    {
      name: 'COPD + CAD',
      problems: ['COPD GOLD 2', 'CAD s/p MI', 'Hypertension'],
      medications: [
        { name: 'Advair', dose: '250/50', frequency: '2 puffs BID', active: true },
        { name: 'Albuterol', dose: '2 puffs', frequency: 'q4h PRN', active: true },
        { name: 'Aspirin', dose: '81mg', frequency: 'daily', active: true },
        { name: 'Atorvastatin', dose: '80mg', frequency: 'daily', active: true },
        { name: 'Metoprolol', dose: '25mg', frequency: 'BID', active: true }
      ],
      labs: {
        ldl: [{ date: '2024-10-01', value: randomInt(60, 100) }]
      },
      complexity: 'moderate-high',
      alerts: ['Post-MI - on dual antiplatelet therapy', 'COPD - monitor for exacerbations']
    },
    {
      name: 'CKD + Diabetes + HTN',
      problems: ['CKD Stage 3b', 'Type 2 Diabetes', 'Hypertension', 'Anemia of CKD'],
      medications: [
        { name: 'Metformin', dose: '500mg', frequency: 'BID', active: true },
        { name: 'Lisinopril', dose: '40mg', frequency: 'daily', active: true },
        { name: 'Furosemide', dose: '40mg', frequency: 'daily', active: true }
      ],
      labs: {
        creatinine: [{ date: '2024-10-01', value: randomFloat(1.8, 2.5) }],
        egfr: [{ date: '2024-10-01', value: randomInt(30, 44) }],
        a1c: [{ date: '2024-10-01', value: randomFloat(7.0, 8.5) }],
        hemoglobin: [{ date: '2024-10-01', value: randomFloat(9.5, 11.5) }]
      },
      complexity: 'high',
      alerts: function(labs) {
        return [
          'CKD Stage 3b - approaching Stage 4',
          'Anemia of CKD present',
          labs.egfr[0].value < 35 ? 'Consider nephrology referral' : ''
        ].filter(a => a);
      }
    }
  ],

  // Complex multi-system (high/very-high)
  complex: [
    {
      name: 'Heart Failure Complex',
      problems: ['HFrEF (EF 35%)', 'Type 2 Diabetes', 'CKD Stage 3b', 'Atrial Fibrillation', 'CAD s/p stent'],
      medications: [
        { name: 'Furosemide', dose: '40mg', frequency: 'BID', active: true },
        { name: 'Carvedilol', dose: '12.5mg', frequency: 'BID', active: true },
        { name: 'Lisinopril', dose: '20mg', frequency: 'daily', active: true },
        { name: 'Spironolactone', dose: '25mg', frequency: 'daily', active: true },
        { name: 'Apixaban', dose: '5mg', frequency: 'BID', active: true },
        { name: 'Metformin', dose: '500mg', frequency: 'BID', active: true },
        { name: 'Atorvastatin', dose: '80mg', frequency: 'daily', active: true }
      ],
      labs: {
        bnp: [{ date: '2024-10-01', value: randomInt(400, 1200) }],
        creatinine: [{ date: '2024-10-01', value: randomFloat(1.5, 2.0) }],
        egfr: [{ date: '2024-10-01', value: randomInt(35, 45) }],
        potassium: [{ date: '2024-10-01', value: randomFloat(4.0, 5.2) }]
      },
      complexity: 'high',
      alerts: [
        'HF - monitor daily weights',
        'On triple RAAS blockade - watch K+ closely',
        'AFib on anticoagulation - monitor for bleeding'
      ]
    },
    {
      name: 'COPD End-Stage',
      problems: ['COPD GOLD 4', 'Cor Pulmonale', 'Chronic Respiratory Failure on O2', 'Pulmonary HTN', 'Depression'],
      medications: [
        { name: 'Advair', dose: '250/50', frequency: '2 puffs BID', active: true },
        { name: 'Spiriva', dose: '18mcg', frequency: 'daily inhaled', active: true },
        { name: 'Albuterol', dose: '2 puffs', frequency: 'q4h PRN', active: true },
        { name: 'Oxygen', dose: '2-3L', frequency: 'continuous', active: true },
        { name: 'Prednisone', dose: '5mg', frequency: 'daily', active: true }
      ],
      labs: {
        o2sat: [{ date: '2024-10-01', value: randomInt(88, 92) }]
      },
      complexity: 'very-high',
      alerts: [
        'End-stage COPD - high exacerbation risk',
        'Home oxygen dependent',
        'Palliative care discussions needed'
      ]
    }
  ]
};

// Generate a single patient
function generatePatient(index) {
  const sex = randomChoice(['M', 'F']);
  const age = randomInt(18, 90);
  
  // Determine complexity based on age and random factor
  let conditionPool;
  const complexity = Math.random();
  
  if (age < 40 && complexity < 0.7) {
    conditionPool = CONDITIONS.acute;
  } else if (age < 50 && complexity < 0.6) {
    conditionPool = [...CONDITIONS.acute, ...CONDITIONS.chronic_single];
  } else if (age < 65) {
    conditionPool = [...CONDITIONS.chronic_single, ...CONDITIONS.chronic_multiple];
  } else {
    conditionPool = [...CONDITIONS.chronic_multiple, ...CONDITIONS.complex];
  }
  
  const template = randomChoice(conditionPool);
  const firstName = randomChoice(FIRST_NAMES[sex]);
  const lastName = randomChoice(LAST_NAMES);
  
  // Generate labs with function evaluation if needed
  const labs = {};
  if (template.labs) {
    Object.keys(template.labs).forEach(key => {
      labs[key] = template.labs[key];
    });
  }
  
  // Generate alerts with function evaluation if needed
  let alerts = [];
  if (typeof template.alerts === 'function') {
    alerts = template.alerts(labs);
  } else if (Array.isArray(template.alerts)) {
    alerts = [...template.alerts];
  }
  
  // Generate visit dates (last 6 months, varying frequency)
  const visitDaysAgo = randomInt(1, 180);
  const lastVisit = new Date();
  lastVisit.setDate(lastVisit.getDate() - visitDaysAgo);
  
  return {
    id: `P${String(index + 1).padStart(3, '0')}`,
    name: `${firstName} ${lastName}`,
    age: age,
    sex: sex,
    mrn: `MRN-${randomInt(2015, 2024)}-${String(randomInt(10000, 99999))}`,
    problems: template.problems,
    medications: template.medications.map(m => ({
      ...m,
      active: m.active !== false
    })),
    labs: labs,
    lastVisit: lastVisit.toISOString().split('T')[0],
    alerts: alerts,
    complexity: template.complexity || 'moderate'
  };
}

// Generate all 100 patients
export function generatePatientDatabase() {
  const patients = {};
  
  // Distribution targets
  const distribution = {
    acute: 20,           // Simple acute cases
    chronic_single: 25,  // Single chronic condition
    chronic_multiple: 35, // 2-3 chronic conditions
    complex: 15,         // Complex multi-system
    very_complex: 5      // End-stage/palliative
  };
  
  let generated = 0;
  
  // Generate acute cases (younger patients)
  for (let i = 0; i < distribution.acute; i++) {
    const patient = generatePatient(generated);
    patients[patient.id] = patient;
    generated++;
  }
  
  // Generate remaining 80 patients
  for (let i = generated; i < 100; i++) {
    const patient = generatePatient(i);
    patients[patient.id] = patient;
  }
  
  return patients;
}

// Helper to export as JSON
export function exportPatientDatabase() {
  const patients = generatePatientDatabase();
  return JSON.stringify(patients, null, 2);
}

// Statistics function
export function getPatientStatistics(patients) {
  const stats = {
    total: Object.keys(patients).length,
    byComplexity: {
      low: 0,
      moderate: 0,
      'moderate-high': 0,
      high: 0,
      'very-high': 0
    },
    byAge: {
      'under_30': 0,
      '30-49': 0,
      '50-64': 0,
      '65-79': 0,
      '80_plus': 0
    },
    bySex: {
      M: 0,
      F: 0
    },
    topConditions: {},
    patientsWithAlerts: 0
  };
  
  Object.values(patients).forEach(p => {
    // Complexity
    stats.byComplexity[p.complexity] = (stats.byComplexity[p.complexity] || 0) + 1;
    
    // Age
    if (p.age < 30) stats.byAge['under_30']++;
    else if (p.age < 50) stats.byAge['30-49']++;
    else if (p.age < 65) stats.byAge['50-64']++;
    else if (p.age < 80) stats.byAge['65-79']++;
    else stats.byAge['80_plus']++;
    
    // Sex
    stats.bySex[p.sex]++;
    
    // Conditions
    p.problems.forEach(prob => {
      stats.topConditions[prob] = (stats.topConditions[prob] || 0) + 1;
    });
    
    // Alerts
    if (p.alerts.length > 0) stats.patientsWithAlerts++;
  });
  
  return stats;
}

// Example usage and testing
if (typeof window !== 'undefined') {
  window.generatePatients = generatePatientDatabase;
  window.exportPatients = exportPatientDatabase;
  window.patientStats = getPatientStatistics;
}

// Export for module usage
export default {
  generatePatientDatabase,
  exportPatientDatabase,
  getPatientStatistics
};

// Test generation
console.log('Patient Database Generator Ready');
console.log('Usage:');
console.log('  const patients = generatePatientDatabase();');
console.log('  const json = exportPatientDatabase();');
console.log('  const stats = getPatientStatistics(patients);');

// Generate sample and show stats
const sampleDB = generatePatientDatabase();
const sampleStats = getPatientStatistics(sampleDB);
console.log('\nSample Database Statistics:');
console.log(`Total Patients: ${sampleStats.total}`);
console.log('By Complexity:', sampleStats.byComplexity);
console.log('By Age Group:', sampleStats.byAge);
console.log('By Sex:', sampleStats.bySex);
console.log(`Patients with Alerts: ${sampleStats.patientsWithAlerts}`);
console.log('\nTop 5 Conditions:');
Object.entries(sampleStats.topConditions)
  .sort((a, b) => b[1] - a[1])
  .slice(0, 5)
  .forEach(([condition, count]) => {
    console.log(`  ${condition}: ${count}`);
  });