import json
import random
from faker import Faker
from datetime import datetime, timedelta

# Initialize Faker for generating realistic synthetic data
fake = Faker()

# --- Configuration Constants ---
GENDER_OPTIONS = ['male', 'female', 'other']
COMMON_CONDITIONS = {
    'Hypertension': 'I10',
    'Type 2 Diabetes Mellitus': 'E11.9',
    'Hyperlipidemia': 'E78.5',
    'Obesity': 'E66.9',
    'Acute Upper Respiratory Infection': 'J06.9'
}
COMMON_MEDICATIONS = {
    'Lisinopril 10mg PO daily': '218868', # RxNorm code
    'Metformin 500mg PO BID': '860942',
    'Atorvastatin 20mg PO daily': '314076',
    'Amoxicillin 500mg PO TID': '834015'
}

# --- Core FHIR Data Structures (Simplified for Simulation) ---

def create_fhir_patient(patient_id):
    """Generates a simplified FHIR Patient resource."""
    gender = random.choice(GENDER_OPTIONS)
    birth_date = fake.date_of_birth(minimum_age=25, maximum_age=85).strftime('%Y-%m-%d')
    return {
        "resourceType": "Patient",
        "id": patient_id,
        "name": [{"use": "official", "family": fake.last_name(), "given": [fake.first_name(gender)]}],
        "gender": gender,
        "birthDate": birth_date,
        "telecom": [{"system": "phone", "value": fake.phone_number(), "use": "home"}]
    }

def create_fhir_encounter(patient_id, encounter_id):
    """Generates a simplified FHIR Encounter resource."""
    start_time = datetime.now() - timedelta(minutes=random.randint(5, 60))
    end_time = start_time + timedelta(minutes=random.randint(15, 45))
    return {
        "resourceType": "Encounter",
        "id": encounter_id,
        "status": "in-progress",
        "class": {"system": "http://terminology.hl7.org/CodeSystem/v3-ActCode", "code": "AMB", "display": "Ambulatory"},
        "subject": {"reference": f"Patient/{patient_id}"},
        "period": {"start": start_time.isoformat(), "end": end_time.isoformat()},
        "serviceType": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/service-type", "code": "260", "display": "General internal medicine"}]}
    }

# --- Clinical Note Generation Logic ---

def generate_clinical_note(patient_data):
    """
    Generates a realistic, unstructured SOAP-style physician dictation.
    This text is the input for the NLP Microservice.
    """
    # 1. Subjective (HPI & ROS)
    age = datetime.now().year - int(patient_data['birthDate'][:4])
    hpi_detail = random.choice([
        f"The patient, a {age}-year-old {patient_data['gender']}, presents today for routine follow-up. They report feeling generally well.",
        f"Chief complaint is a persistent non-productive cough and mild sore throat for the past 4 days. Patient denies fever.",
        f"Follow-up for management of chronic conditions. Patient states their diet has been poor lately and admits to missing a few doses of medication."
    ])

    ros_detail = random.choice([
        "ROS is negative except for some mild fatigue.",
        "ROS positive for rhinorrhea and scratchy throat; otherwise negative.",
        "ROS significant for occasional leg swelling at night, denies chest pain or shortness of breath."
    ])

    subjective = f"S: {hpi_detail} {ros_detail}"

    # 2. Objective (Vitals & Physical Exam) - Contains entities for NLP to extract
    bp = f"{random.randint(110, 150)}/{random.randint(70, 95)}"
    hr = random.randint(60, 90)
    temp = round(random.uniform(97.5, 99.5), 1)

    objective = f"O: Vitals: BP: {bp} mmHg, HR: {hr} bpm, Temp: {temp}°F. Physical Exam: Lungs clear to auscultation bilaterally. Heart: Regular rate and rhythm. Exam is otherwise unremarkable. "

    # 3. Assessment and Plan (A&P) - Contains conditions and planned actions
    condition, icd_code = random.choice(list(COMMON_CONDITIONS.items()))
    medication, rx_code = random.choice(list(COMMON_MEDICATIONS.items()))

    assessment = f"A: 1. **{condition}** ({icd_code}) - Stable. 2. **Obesity** ({COMMON_CONDITIONS['Obesity']}) - Ongoing management. 3. New mild URI symptoms (J06.9)."
    
    plan = f"P: 1. Continue {medication}. 2. Recheck BP in 3 months. 3. Encourage lifestyle modification for weight loss. 4. Patient to take Tylenol as needed for comfort for URI symptoms. "

    return {
        "raw_note": f"{subjective}\n\n{objective}\n\n{assessment}\n\n{plan}",
        "expected_fhir_entities": {
            "conditions": [condition, "Obesity", "Acute Upper Respiratory Infection"],
            "medications": [medication, "Tylenol as needed"],
            "vitals": [f"BP: {bp}", f"HR: {hr}", f"Temp: {temp}°F"]
        }
    }


def create_simulated_encounter(count=1):
    """
    Main function to generate a specified number of synthetic encounters.
    Outputs a list of dictionaries containing both raw text and FHIR structures.
    """
    simulated_data = []
    
    print(f"--- Generating {count} Synthetic Clinical Encounters (JSON Output) ---")
    
    for i in range(1, count + 1):
        patient_id = f"P-00{i}"
        encounter_id = f"E-2025-{i}"
        
        patient = create_fhir_patient(patient_id)
        encounter = create_fhir_encounter(patient_id, encounter_id)
        note_details = generate_clinical_note(patient)
        
        simulated_data.append({
            "meta_description": f"Encounter Simulation #{i} for Patient {patient_id}",
            "fhir_patient_resource": patient,
            "fhir_encounter_resource": encounter,
            "raw_physician_dictation": note_details["raw_note"],
            "nlp_target_entities": note_details["expected_fhir_entities"]
        })
    
    print("--- First Generated Encounter Example ---")
    print(json.dumps(simulated_data[0], indent=2))
    print("---------------------------------------")

    return simulated_data

# Execute the simulation generator
if __name__ == "__main__":
    create_simulated_encounter(count=3)
