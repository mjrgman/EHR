// ============================================================================
// COMPREHENSIVE PATIENT DATABASE
// Complete medical records for full day primary care schedule
// Demonstrates AI-powered EHR capabilities across complexity spectrum
// ============================================================================

export const PATIENT_DATABASE = {

  // ==========================================================================
  // PATIENT 1: SARAH MITCHELL (Already created - Moderate Complexity)
  // 62F with worsening diabetes, CKD, stopped medication without informing
  // ==========================================================================
  
  "P001": {
    slot_time: "08:00",
    complexity: "moderate",
    patient_id: "P001",
    mrn: "MRN-2018-04792",
    
    demographics: {
      name: { first: "Sarah", middle: "Ann", last: "Mitchell", preferred: "Sarah" },
      dob: "1963-01-15",
      age: 62,
      sex: "F"
    },
    
    visit_reason: "Diabetes and hypertension follow-up, lab review",
    chief_complaint: "Here for routine diabetes and blood pressure check",
    
    clinical_summary: {
      active_problems: [
        { problem: "Type 2 Diabetes Mellitus", status: "Uncontrolled", last_a1c: 8.4 },
        { problem: "Chronic Kidney Disease Stage 3a", status: "Progressive", egfr: 52 },
        { problem: "Hypertension", status: "Suboptimally controlled", bp: "142/88" },
        { problem: "Obesity", bmi: 32.1 }
      ]
    },
    
    key_clinical_issues: [
      "A1C worsened to 8.4% after secretly stopping Jardiance",
      "New microalbuminuria indicates diabetic nephropathy",
      "Needs GLP-1 agonist for diabetes, weight, CV and renal protection"
    ]
  },

  // ==========================================================================
  // PATIENT 2: ROBERT WILLIAMS (High Complexity)
  // 78M - Complex elderly with CHF, COPD, CKD, DM, post-MI, polypharmacy
  // ==========================================================================
  
  "P002": {
    slot_time: "08:30",
    complexity: "high",
    patient_id: "P002",
    mrn: "MRN-2015-03281",
    
    demographics: {
      name: { first: "Robert", middle: "James", last: "Williams", preferred: "Bob" },
      dob: "1946-11-22",
      age: 78,
      sex: "M",
      race: "Black",
      ethnicity: "Non-Hispanic"
    },
    
    contact: {
      phone: "478-555-8821",
      address: "892 Elm Street, Macon, GA 31201",
      lives_with: "Wife (Mary, age 76)",
      emergency_contact: {
        name: "Robert Williams Jr. (son)",
        phone: "478-555-8822",
        relationship: "Son"
      }
    },
    
    insurance: {
      primary: "Medicare Part B",
      secondary: "BCBS Medicare Supplement",
      part_d: "SilverScript",
      copays_affordable: true
    },
    
    visit_reason: "Post-hospital follow-up after heart failure exacerbation",
    chief_complaint: "Discharged from hospital 5 days ago for heart failure, doing better but still short of breath with stairs",
    
    clinical_summary: {
      complexity_factors: [
        "Multiple organ system involvement",
        "Recent hospitalization",
        "Polypharmacy (15 medications)",
        "Multiple specialists",
        "High fall risk",
        "Cognitive impairment (mild)"
      ],
      
      active_problems: [
        {
          problem: "Heart Failure with Reduced Ejection Fraction (HFrEF)",
          onset: "2019-03",
          status: "Recently decompensated",
          ejection_fraction: "25% (echo 2024-10-01)",
          nyha_class: "II-III",
          last_hospitalization: {
            date: "2024-10-01 to 2024-10-04",
            reason: "Acute decompensated heart failure",
            hospital: "Medical Center of Central Georgia",
            discharge_weight: "198 lbs",
            discharge_summary: "78M with known HFrEF (EF 25%) admitted with 3-day history of increasing dyspnea, orthopnea, and bilateral lower extremity edema. Weight up 12 lbs from baseline. CXR showed pulmonary edema. BNP 2847. Treated with IV furosemide 80mg BID with good diuresis (net negative 8L over 3 days). Uptitrated carvedilol from 12.5mg to 25mg BID. Echo showed unchanged EF 25%, moderate MR. D/C on torsemide 40mg BID (increased from 20mg daily), carvedilol 25mg BID, continue lisinopril, spironolactone. Close PCP follow-up in 5-7 days. Cardiology follow-up in 2 weeks."
          },
          current_weight: "195 lbs (down 3 from discharge)",
          daily_weights_at_home: [
            { date: "2024-10-05", weight: 198 },
            { date: "2024-10-06", weight: 196 },
            { date: "2024-10-07", weight: 195 },
            { date: "2024-10-08", weight: 195 },
            { date: "2024-10-09", weight: 195 }
          ],
          target_weight: "190 lbs (dry weight)",
          current_medications: ["Torsemide 40mg BID", "Carvedilol 25mg BID", "Lisinopril 40mg daily", "Spironolactone 25mg daily"]
        },
        {
          problem: "Coronary Artery Disease, status post MI",
          onset: "2018-06",
          status: "Stable on medical management",
          history: "STEMI June 2018, cardiac cath showed 95% LAD lesion, DES placed to LAD. EF dropped from 55% to 35%, later declined to 25%. No angina since revascularization.",
          current_medications: ["Aspirin 81mg", "Ticagrelor 90mg BID (until June 2025)", "Atorvastatin 80mg"]
        },
        {
          problem: "Chronic Obstructive Pulmonary Disease (COPD)",
          onset: "2010",
          status: "Moderate, stable",
          gold_stage: "GOLD 2 (moderate)",
          last_pfts: {
            date: "2023-11-15",
            fev1: "58% predicted",
            fvc: "72% predicted",
            fev1_fvc_ratio: "0.61"
          },
          exacerbations_last_year: 1,
          last_exacerbation: "March 2024, treated with prednisone and azithromycin",
          current_medications: ["Symbicort 160/4.5 2 puffs BID", "Albuterol PRN"],
          smoking_history: "60 pack-years, quit 2012",
          oxygen_use: "Room air, O2 sat 94% at rest"
        },
        {
          problem: "Type 2 Diabetes Mellitus",
          onset: "2008",
          status: "Reasonably controlled",
          last_a1c: { value: 7.3, date: "2024-09-15" },
          complications: ["Diabetic neuropathy", "Diabetic retinopathy (mild NPDR)"],
          current_medications: ["Metformin 1000mg BID", "Glimepiride 4mg daily"]
        },
        {
          problem: "Chronic Kidney Disease Stage 3b",
          onset: "2020",
          status: "Stable",
          last_egfr: { value: 38, date: "2024-10-05" },
          last_creatinine: { value: 1.8, date: "2024-10-05" },
          etiology: "Diabetic nephropathy, hypertensive nephrosclerosis, cardiorenal syndrome",
          monitoring: "Every 3 months"
        },
        {
          problem: "Hypertension",
          onset: "1995",
          status: "Controlled on multiple agents",
          target_bp: "<130/80",
          recent_bp: "122/76 (in hospital), 128/82 today"
        },
        {
          problem: "Hyperlipidemia",
          status: "Controlled on high-intensity statin",
          last_lipids: {
            date: "2024-09-15",
            ldl: 68,
            hdl: 38,
            triglycerides: 145,
            on_statin: "Atorvastatin 80mg"
          }
        },
        {
          problem: "Atrial Fibrillation",
          onset: "2019",
          status: "Persistent, rate controlled",
          anticoagulation: "Apixaban 5mg BID",
          chads2_vasc_score: 6,
          hasbled_score: 2,
          last_rate: "HR 68-82 at rest"
        },
        {
          problem: "Benign Prostatic Hyperplasia",
          status: "Managed medically",
          symptoms: "Mild LUTS, nocturia x2-3",
          current_medication: "Tamsulosin 0.4mg daily"
        },
        {
          problem: "Osteoarthritis",
          locations: ["Bilateral knees", "Lower back"],
          status: "Chronic pain, limiting mobility",
          current_management: "Acetaminophen PRN, tried NSAIDs but stopped due to CKD",
          mobility: "Uses cane for walking distances"
        },
        {
          problem: "History of Falls",
          last_fall: "2024-08-12",
          circumstances: "Tripped over rug, no injury",
          fall_risk_factors: ["Polypharmacy", "Orthostatic hypotension", "Neuropathy", "Use of cane"],
          interventions: "PT evaluation, home safety assessment done"
        }
      ],
      
      past_surgical_history: [
        { year: 2018, procedure: "Percutaneous coronary intervention (PCI) with DES to LAD" },
        { year: 2012, procedure: "Cholecystectomy (laparoscopic)" },
        { year: 1998, procedure: "Inguinal hernia repair" }
      ],
      
      current_medications: [
        { name: "Torsemide", dose: "40mg", frequency: "twice daily", indication: "Heart failure", recent_change: "Increased from 20mg daily after hospitalization" },
        { name: "Carvedilol", dose: "25mg", frequency: "twice daily", indication: "Heart failure, CAD", recent_change: "Increased from 12.5mg BID in hospital" },
        { name: "Lisinopril", dose: "40mg", frequency: "once daily", indication: "Heart failure, HTN, DM" },
        { name: "Spironolactone", dose: "25mg", frequency: "once daily", indication: "Heart failure" },
        { name: "Apixaban", dose: "5mg", frequency: "twice daily", indication: "Atrial fibrillation (anticoagulation)" },
        { name: "Atorvastatin", dose: "80mg", frequency: "once daily", indication: "Post-MI, hyperlipidemia" },
        { name: "Aspirin", dose: "81mg", frequency: "once daily", indication: "Post-MI" },
        { name: "Ticagrelor", dose: "90mg", frequency: "twice daily", indication: "Post-PCI (continue through June 2025)" },
        { name: "Metformin", dose: "1000mg", frequency: "twice daily", indication: "Type 2 Diabetes", note: "Max dose for eGFR 38" },
        { name: "Glimepiride", dose: "4mg", frequency: "once daily", indication: "Type 2 Diabetes" },
        { name: "Symbicort (budesonide/formoterol)", dose: "160/4.5mcg", frequency: "2 puffs twice daily", indication: "COPD" },
        { name: "Albuterol inhaler", dose: "2 puffs", frequency: "as needed", indication: "COPD rescue" },
        { name: "Tamsulosin", dose: "0.4mg", frequency: "once daily at bedtime", indication: "BPH" },
        { name: "Gabapentin", dose: "300mg", frequency: "three times daily", indication: "Diabetic neuropathy" },
        { name: "Acetaminophen", dose: "650mg", frequency: "as needed", indication: "Arthritis pain", note: "Max 3000mg/day" }
      ],
      
      medication_adherence: {
        overall_assessment: "Generally good but complex regimen",
        barriers: "Large pill burden, multiple pharmacies, confusion about new doses post-discharge",
        interventions: "Pillbox system, wife helps with administration, post-hospital medication reconciliation needed"
      },
      
      allergies: [
        { allergen: "Sulfa drugs", reaction: "Rash", severity: "Moderate", verified: true }
      ],
      
      pharmacy_records: {
        primary_pharmacy: "Walgreens on Riverside Drive",
        secondary_pharmacy: "VA Pharmacy (for some medications)",
        recent_fills: "All medications filled 10/05/24 at discharge",
        adherence_issues: "Sometimes confuses twice daily vs once daily dosing"
      }
    },
    
    recent_hospitalizations: [
      {
        admission_date: "2024-10-01",
        discharge_date: "2024-10-04",
        hospital: "Medical Center of Central Georgia",
        reason: "Acute decompensated heart failure",
        attending: "Dr. Sarah Martinez (Hospitalist)",
        
        admission_note: {
          chief_complaint: "Shortness of breath x3 days",
          hpi: "78M with history of HFrEF (EF 25%), CAD s/p PCI, COPD, DM2, CKD3b presents with 3-day history of progressive dyspnea, orthopnea (now requiring 3 pillows), PND, and bilateral lower extremity edema. Patient reports medication adherence but admits he 'ran out' of torsemide for about 5 days last week and didn't refill immediately. Weight increased from baseline 186 to 198 lbs. Denies chest pain, denies fever, denies cough productive of purulent sputum.",
          
          physical_exam: {
            vitals: "BP 148/88, HR 88 (irregularly irregular), RR 24, O2 sat 88% on RA â†’ 94% on 2L NC, Temp 98.2F, Weight 198 lbs",
            general: "Elderly male in moderate respiratory distress, speaking in short sentences",
            heent: "JVP elevated to 12cm",
            cardiovascular: "Irregularly irregular rhythm, S3 gallop present, 2/6 systolic murmur at apex",
            respiratory: "Bilateral crackles 1/2 up lung fields, no wheezes",
            abdomen: "Soft, non-tender, liver edge palpable 2cm below costal margin",
            extremities: "3+ pitting edema to mid-calf bilaterally",
            neurologic: "Alert and oriented x3, no focal deficits"
          },
          
          admission_labs: {
            bmp: "Na 136, K 4.8, Cl 102, CO2 24, BUN 42, Cr 2.1 (baseline 1.8), Glucose 156",
            cbc: "WBC 8.2, Hgb 11.8, Plt 245",
            bnp: "2847 (markedly elevated)",
            troponin: "0.08 (mildly elevated, likely demand ischemia)",
            liver_function: "Within normal limits"
          },
          
          imaging: {
            chest_xray: {
              date: "2024-10-01",
              findings: "Cardiomegaly, bilateral pulmonary edema with Kerley B lines, small bilateral pleural effusions",
              impression: "Findings consistent with acute decompensated heart failure"
            },
            echocardiogram: {
              date: "2024-10-01",
              findings: "LV severely dilated with global hypokinesis, LVEF 25% (unchanged from prior), moderate mitral regurgitation (functional), moderate tricuspid regurgitation, RA and RV mildly dilated, estimated RVSP 45mmHg, no pericardial effusion",
              impression: "Severe LV systolic dysfunction, unchanged from 2023"
            }
          },
          
          assessment_plan: "78M with acute decompensated heart failure in setting of medication non-adherence. Volume overloaded by exam and imaging. Plan for aggressive diuresis, uptitrate GDMT, monitor renal function and electrolytes."
        },
        
        hospital_course: [
          {
            date: "Day 1 (10/01)",
            events: "Started IV furosemide 80mg BID. Net output 2.1L. Cr stable at 2.1. Breathing improved, O2 weaned to 1L."
          },
          {
            date: "Day 2 (10/02)",
            events: "Continued IV furosemide 80mg BID. Net output 3.2L. Cr improved to 1.9. Edema improving. Patient feeling much better. Transitioned to 2L NC only at night."
          },
          {
            date: "Day 3 (10/03)",
            events: "Continued IV diuresis. Net output 2.8L. Total net negative 8.1L since admission. Cr stable 1.9. Edema trace. Clear lung fields. Uptitrated carvedilol to 25mg BID (from 12.5mg). Tolerating well, no hypotension. Transitioned to oral torsemide 40mg BID."
          },
          {
            date: "Day 4 (10/04)",
            events: "On oral diuretics, stable. Weight 198 lbs (down from 210 on admission). Room air O2 sat 94%. Ambulating without dyspnea. Cardiology consulted - recommend continued GDMT optimization, close outpatient follow-up. Ready for discharge."
          }
        ],
        
        discharge_summary: {
          discharge_diagnosis: [
            "Acute decompensated heart failure",
            "Heart failure with reduced ejection fraction (EF 25%)",
            "Coronary artery disease, status post MI and PCI",
            "Atrial fibrillation on anticoagulation",
            "Type 2 Diabetes Mellitus",
            "Chronic Kidney Disease Stage 3b",
            "COPD"
          ],
          
          discharge_medications: [
            "Torsemide 40mg PO BID (INCREASED from 20mg daily)",
            "Carvedilol 25mg PO BID (INCREASED from 12.5mg BID)",
            "Lisinopril 40mg PO daily",
            "Spironolactone 25mg PO daily",
            "Apixaban 5mg PO BID",
            "Atorvastatin 80mg PO daily",
            "Aspirin 81mg PO daily",
            "Ticagrelor 90mg PO BID",
            "Metformin 1000mg PO BID",
            "Glimepiride 4mg PO daily",
            "Symbicort 2 puffs BID",
            "Albuterol PRN",
            "Tamsulosin 0.4mg PO qHS",
            "Gabapentin 300mg PO TID",
            "Acetaminophen 650mg PRN"
          ],
          
          discharge_instructions: [
            "Weigh yourself every morning after urination, before breakfast",
            "Call if weight increases >3 lbs in one day or 5 lbs in one week",
            "Call if increasing shortness of breath, chest pain, or severe swelling",
            "Strict sodium restriction <2000mg/day",
            "Fluid restriction 1.5-2 liters per day",
            "Continue all medications as prescribed - DO NOT SKIP DIURETICS",
            "Follow-up with PCP in 5-7 days",
            "Follow-up with Cardiology (Dr. Patterson) in 2 weeks"
          ],
          
          discharge_weight: "198 lbs",
          target_weight: "190 lbs (dry weight)"
        }
      }
    ],
    
    specialist_consultations: [
      {
        specialty: "Cardiology",
        provider: "Dr. James Patterson, MD",
        practice: "Macon Cardiology Associates",
        phone: "478-555-CARD",
        
        recent_visits: [
          {
            date: "2024-09-10",
            reason: "Routine HFrEF follow-up",
            findings: "Patient stable on current regimen. EF remains 25%. No hospitalizations since March. Some mild LE edema. Weight 186 lbs (baseline). BNP 487 (down from 892 in March).",
            recommendations: "Continue current medications. Recheck labs in 3 months. Return sooner if symptoms worsen. Discussed importance of medication adherence and daily weights.",
            next_appointment: "December 2024 (now will be sooner given hospitalization)"
          }
        ],
        
        most_recent_note: "2024-10-03 (inpatient consult): 78M with known HFrEF EF 25% admitted for ADHF. Now s/p diuresis with 8L net negative. Recommend continue aggressive oral diuresis with torsemide 40mg BID. Uptitrated carvedilol to 25mg BID today - tolerating well. Continue lisinopril 40mg, spironolactone 25mg. Close outpatient follow-up in 2 weeks. May need ICD evaluation if EF remains â‰¤35% despite optimal medical therapy."
      },
      {
        specialty: "Nephrology",
        provider: "Dr. Lisa Chen, MD",
        practice: "Georgia Kidney Specialists",
        
        most_recent_visit: {
          date: "2024-08-15",
          reason: "CKD management",
          findings: "CKD Stage 3b, eGFR 38-42 range over past year. Etiology multifactorial - diabetic nephropathy, hypertensive nephrosclerosis, cardiorenal syndrome. Currently no proteinuria. Anemia of CKD present (Hgb 11.8).",
          recommendations: "Continue ACE-I for renal protection. Metformin dose appropriate for eGFR. Avoid nephrotoxins (NSAIDs). Monitor Cr q3 months. Consider EPO if Hgb drops below 10. Return in 6 months.",
          labs_ordered: "BMP, CBC, iron studies in 3 months"
        }
      },
      {
        specialty: "Pulmonology",
        provider: "Dr. Michael Torres, MD",
        
        most_recent_visit: {
          date: "2023-11-15",
          reason: "COPD management, annual PFTs",
          findings: "COPD GOLD 2 (moderate). FEV1 58% predicted. One exacerbation in past year. Currently stable on Symbicort + albuterol PRN. No oxygen requirement at rest. O2 sat 94% on RA.",
          recommendations: "Continue current inhaler regimen. Smoking cessation maintained (quit 2012) - excellent. Pneumonia and flu vaccines up to date. Return PRN for exacerbations or if increasing symptoms.",
          next_pfts: "November 2024"
        }
      }
    ],
    
    family_history: {
      father: {
        status: "Deceased age 72",
        cause: "Myocardial infarction",
        conditions: ["CAD", "Hypertension", "Diabetes"]
      },
      mother: {
        status: "Deceased age 84",
        cause: "Stroke",
        conditions: ["Hypertension", "Atrial fibrillation"]
      },
      siblings: {
        brother_1: { status: "Living", age: 75, conditions: ["Hypertension", "CAD s/p CABG"] },
        sister_1: { status: "Deceased age 68", cause: "Breast cancer" }
      },
      children: {
        son: { age: 52, conditions: ["Hypertension", "Prediabetes"] },
        daughter: { age: 48, conditions: ["Healthy"] }
      }
    },
    
    social_history: {
      marital_status: "Married 54 years",
      spouse: "Mary Williams, age 76, healthy and supportive",
      living_situation: "Single-story home, owns, safe environment, bathroom on main floor",
      children_nearby: "Son lives 10 minutes away, daughter in Atlanta",
      occupation: "Retired postal worker (retired 2008)",
      
      tobacco: {
        status: "Former smoker",
        pack_years: 60,
        quit_date: "2012 (after MI scare)",
        current: "None for 12 years"
      },
      
      alcohol: { status: "None", history: "Quit 20 years ago, used to drink socially" },
      drugs: { status: "Never used" },
      
      functional_status: {
        adls: "Independent with all ADLs",
        iadls: "Wife manages medications, cooking; patient manages finances",
        mobility: "Uses cane for walking >1 block; can climb stairs slowly with handrail",
        falls: "One fall in past year (tripped on rug, no injury)",
        driving: "Still drives short distances during day"
      },
      
      exercise: "Limited by dyspnea and arthritis. Walks around house and yard. No structured exercise program.",
      diet: "Wife prepares low-sodium meals. Adherence good at home, occasionally cheats with salty foods.",
      
      support_system: {
        primary_caregiver: "Wife (Mary)",
        backup: "Son available for emergencies",
        home_health: "None currently",
        dme: "Cane, raised toilet seat, shower chair"
      },
      
      advance_directives: {
        healthcare_proxy: "Wife (Mary Williams)",
        living_will: "Completed, on file",
        code_status: "Full code",
        wishes: "Wants all measures if reversible condition, but does not want prolonged life support if no meaningful recovery expected"
      }
    },
    
    today_visit: {
      date: "2024-10-09",
      time: "08:30",
      reason: "Post-hospital follow-up",
      days_since_discharge: 5,
      
      hpi: "78M returns for post-discharge follow-up after admission 10/1-10/4 for acute decompensated heart failure. Patient reports feeling much better than on admission. Breathing is improved - no longer orthopneic, can lie flat with one pillow. LE edema has continued to improve. Has been weighing himself daily - weights have been stable at 195 lbs for past 2 days (discharge weight 198 lbs, target 190 lbs). Reports good adherence to new medication doses. Wife has been helping with pillbox. Some mild dyspnea with climbing stairs but much improved from before. No chest pain. No PND. Urinating frequently due to increased diuretic but tolerating it. Appetite good. No nausea or dizziness. Checking blood sugars - running 110-140s.",
      
      review_of_systems: {
        constitutional: "No fever, chills, or night sweats. Energy improving.",
        cardiovascular: "No chest pain, palpitations well-controlled. Trace edema only.",
        respiratory: "Dyspnea improved significantly. Can walk around house without SOB. Occasional cough, nonproductive. No wheezing. COPD stable.",
        gastrointestinal: "Good appetite. No nausea, vomiting, diarrhea, constipation.",
        genitourinary: "Increased urinary frequency due to diuretics (expected). Nocturia x3-4 (increased from baseline x2). No dysuria.",
        musculoskeletal: "Chronic knee and back pain, unchanged. Managing with acetaminophen.",
        neurologic: "No dizziness, weakness, numbness. Neuropathy symptoms unchanged (baseline tingling in feet).",
        psychiatric: "Mood good. Grateful to be feeling better."
      },
      
      vitals: {
        bp: "128/82 (seated), 118/76 (standing after 1 minute)",
        hr: 76,
        rr: 16,
        temp: 98.1,
        weight: 195,
        o2_sat: "96% on room air",
        orthostatic_vitals: "No significant orthostasis"
      },
      
      physical_exam: {
        general: "Well-appearing elderly male, no acute distress, speaking in full sentences",
        heent: "JVP normal at 8cm (was 12cm on admission)",
        cardiovascular: "Irregularly irregular rhythm (AFib), normal S1/S2, soft systolic murmur at apex (chronic MR), no S3 gallop today",
        respiratory: "Clear to auscultation bilaterally, no crackles, no wheezes, good air movement",
        abdomen: "Soft, non-tender, non-distended, liver edge not palpable",
        extremities: "Trace pitting edema bilateral ankles (was 3+ on admission), pulses 2+ throughout, no calf tenderness",
        neurologic: "Alert and oriented x3, CN II-XII intact, strength 4/5 lower extremities (baseline), sensation decreased in feet to monofilament (baseline neuropathy)",
        skin: "Warm, dry, no rashes"
      },
      
      labs_reviewed: {
        date: "2024-10-05 (at discharge)",
        bmp: "Na 138, K 4.3, Cl 104, CO2 26, BUN 38, Cr 1.8 (back to baseline), Glucose 145",
        note: "Renal function improved back to baseline after diuresis. K normal despite triple RAAS blockade + diuretic."
      },
      
      medication_reconciliation: {
        discrepancies_found: "None - patient bringing correct bottles",
        new_doses_understood: "Yes, wife has updated pillbox with new doses",
        adherence_barriers: "None identified - has refills, can afford copays"
      },
      
      assessment_and_plan: [
        {
          problem: "Acute Decompensated Heart Failure - RESOLVED",
          assessment: "Patient has responded excellently to inpatient diuresis and medication optimization. Clinically much improved - no orthopnea, clear lungs, minimal edema. Weight down 3 lbs from discharge (now 195 lbs, target 190 lbs). No signs of overdiuresis - BP stable, no orthostasis, Cr at baseline.",
          plan: [
            "Continue torsemide 40mg BID (increased from 20mg daily)",
            "Continue carvedilol 25mg BID (increased from 12.5mg BID) - tolerating well",
            "Continue lisinopril 40mg daily, spironolactone 25mg daily",
            "Continue daily weights - call if >3 lbs in 1 day or 5 lbs in 1 week",
            "Continue low sodium diet, fluid restriction",
            "Target weight 190 lbs - may further adjust diuretic as needed",
            "Recheck BMP, BNP in 1 week",
            "Cardiology follow-up with Dr. Patterson in 1 week (appointment scheduled)"
          ],
          education: "Reinforced importance of medication adherence - explained that stopping diuretics led to hospitalization. Wife understands. Reviewed warning signs of worsening HF."
        },
        {
          problem: "HFrEF with EF 25%",
          assessment: "On optimal GDMT: ACE-I, beta blocker, aldosterone antagonist, diuretic. May be ICD candidate given EF â‰¤35% - will discuss with cardiology.",
          plan: "Continue current GDMT. Cardiology to assess ICD candidacy at next visit."
        },
        {
          problem: "CAD s/p MI and PCI - stable",
          assessment: "No angina. On appropriate dual antiplatelet therapy (aspirin + ticagrelor through June 2025) plus high-intensity statin.",
          plan: "Continue current regimen. LDL 68 at goal."
        },
        {
          problem: "Atrial Fibrillation - stable",
          assessment: "Rate controlled on carvedilol. On anticoagulation with apixaban. CHA2DS2-VASc 6.",
          plan: "Continue apixaban 5mg BID, continue beta blocker for rate control."
        },
        {
          problem: "Type 2 Diabetes - reasonably controlled",
          assessment: "A1C 7.3 last month. Blood sugars running 110-140s at home. On metformin and glimepiride. Metformin dose appropriate for eGFR 38.",
          plan: "Continue current regimen. Recheck A1C in 3 months."
        },
        {
          problem: "CKD Stage 3b - stable",
          assessment: "Cr back to baseline 1.8 after diuresis. eGFR 38. On ACE-I for renal protection. K normal despite RAAS blockade.",
          plan: "Monitor Cr and K closely given diuretic increase and triple RAAS blockade. Recheck BMP in 1 week, then q1 month x 2, then q3 months if stable."
        },
        {
          problem: "COPD - stable",
          assessment: "No recent exacerbations. On maintenance Symbicort. O2 sat 96% RA.",
          plan: "Continue Symbicort and PRN albuterol. Due for annual PFTs with pulmonology this month."
        }
      ],
      
      orders: [
        { type: "Labs", tests: "BMP, BNP", timing: "In 1 week" },
        { type: "Follow-up", with: "PCP", when: "2 weeks (or sooner if symptoms worsen)" },
        { type: "Follow-up", with: "Cardiology (Dr. Patterson)", when: "1 week (already scheduled)" }
      ],
      
      time_spent: {
        face_to_face: "35 minutes",
        counseling: "20 minutes (>50% of visit time)",
        complexity: "High - post-hospital, multiple chronic conditions, medication reconciliation, extensive counseling"
      },
      
      billing: {
        cpt: "99215",
        icd10: ["I50.23 (ADHF)", "I50.22 (HFrEF chronic)", "I25.10 (CAD)", "I48.2 (Chronic AFib)", "E11.9 (DM2)", "N18.3b (CKD3b)", "J44.1 (COPD)"],
        justification: "High complexity visit - post-hospitalization, multiple unstable chronic conditions, extensive medication management and counseling"
      }
    },
    
    key_clinical_issues: [
      "Post-hospital HF patient - high risk for readmission",
      "Recent medication changes - need close monitoring",
      "Polypharmacy with 15 medications - drug interaction risk",
      "Triple RAAS blockade - monitor K+ and renal function closely",
      "Fall risk - using cane, on multiple BP meds",
      "May need ICD for primary prevention given low EF"
    ],
    
    red_flags: [
      "If weight increases >3 lbs - may need diuretic adjustment",
      "If BP drops <100/60 or symptomatic hypotension - may need medication adjustment",
      "If K+ >5.5 - may need to reduce/stop spironolactone",
      "If Cr increases >30% - reassess diuretic dose",
      "Monitor for bleeding on dual antiplatelet + anticoagulation"
    ]
  },

  // ==========================================================================
  // PATIENT 3: JESSICA MARTINEZ (Low Complexity)
  // 24F - Healthy young adult with acute bacterial sinusitis
  // ==========================================================================
  
  "P003": {
    slot_time: "09:00",
    complexity: "low",
    patient_id: "P003",
    mrn: "MRN-2024-08941",
    
    demographics: {
      name: { first: "Jessica", middle: "Marie", last: "Martinez", preferred: "Jess" },
      dob: "2000-03-15",
      age: 24,
      sex: "F",
      race: "Hispanic",
      ethnicity: "Hispanic"
    },
    
    contact: {
      phone: "478-555-2341",
      email: "jmartinez24@email.com",
      address: "1523 University Drive, Apt 2B, Macon, GA 31201",
      lives_with: "Roommate",
      emergency_contact: {
        name: "Maria Martinez (mother)",
        phone: "478-555-2342",
        relationship: "Mother"
      }
    },
    
    insurance: {
      carrier: "Blue Cross Blue Shield (through employer)",
      plan: "PPO",
      copay_primary_care: "$25",
      deductible_status: "Not met"
    },
    
    visit_reason: "Sinus infection",
    chief_complaint: "Terrible sinus pressure and yellow nasal discharge for 10 days, getting worse",
    
    clinical_summary: {
      complexity_factors: ["Generally healthy", "No chronic conditions", "No regular medications"],
      
      active_problems: [
        {
          problem: "Acute Bacterial Rhinosinusitis",
          onset: "10 days ago",
          status: "Currently worsening",
          symptoms: [
            "Purulent nasal discharge (thick yellow/green) for 10 days",
            "Facial pain and pressure, worse over maxillary sinuses bilaterally",
            "Headache, frontal",
            "Nasal congestion",
            "Post-nasal drip with sore throat",
            "Decreased sense of smell",
            "Tooth pain in upper molars",
            "Initially improved on day 5-6, now worsening again ('double sickening')"
          ],
          triggers: "Started with 'a cold' 2 weeks ago after exposure at work"
        }
      ],
      
      past_medical_history: [
        "Generally healthy",
        "No chronic medical conditions",
        "No prior surgeries",
        "No hospitalizations as adult"
      ],
      
      childhood_history: {
        births: "Full-term, normal vaginal delivery, no complications",
        development: "Normal developmental milestones",
        childhood_illnesses: "Usual childhood viral illnesses, no serious infections",
        surgeries: "Tonsillectomy age 6 for recurrent tonsillitis"
      },
      
      current_medications: [
        {
          name: "Oral contraceptive (Junel Fe 1/20)",
          dose: "1 tablet",
          frequency: "daily",
          indication: "Contraception, menstrual regulation",
          adherence: "Excellent"
        }
      ],
      
      over_the_counter_tried: [
        "Sudafed (pseudoephedrine) - helped some with congestion",
        "Tylenol - helped headache temporarily",
        "Mucinex - didn't help much",
        "Saline nasal spray - provides brief relief"
      ],
      
      allergies: [
        { allergen: "No known drug allergies", verified: true }
      ],
      
      immunizations: {
        up_to_date: true,
        recent: [
          { vaccine: "COVID-19 booster", date: "2024-09-15" },
          { vaccine: "Influenza", date: "2024-09-15" },
          { vaccine: "Tdap", date: "2020-05-10", due_next: "2030" },
          { vaccine: "HPV series", completed: "2016", status: "Complete" },
          { vaccine: "MMR", childhood: true, status: "Complete" }
        ]
      }
    },
    
    family_history: {
      father: {
        status: "Living", age: 52,
        conditions: ["Hypertension (controlled)", "Type 2 Diabetes (diet controlled)"]
      },
      mother: {
        status: "Living", age: 50,
        conditions: ["Healthy", "History of gestational diabetes (resolved)"]
      },
      siblings: {
        brother: { age: 22, status: "Healthy" },
        sister: { age: 19, status: "Healthy" }
      },
      grandparents: {
        paternal_grandfather: "Deceased age 75, stroke",
        paternal_grandmother: "Living age 78, diabetes, hypertension",
        maternal_grandfather: "Living age 80, hypertension only",
        maternal_grandmother: "Living age 77, arthritis only"
      },
      cancer_history: "No family history of cancer"
    },
    
    social_history: {
      marital_status: "Single",
      relationship: "In a relationship, boyfriend for 2 years",
      living_situation: "Apartment with roommate, safe neighborhood",
      occupation: "Elementary school teacher, 2nd grade (been teaching for 2 years)",
      education: "Bachelor's degree in Education, graduated 2022",
      
      tobacco: { status: "Never smoked" },
      alcohol: { status: "Social", frequency: "1-2 drinks on weekends", never_excessive: true },
      drugs: { status: "None", denies_all: true },
      
      diet: "Generally healthy, cooks at home most nights, eats out 2-3x/week",
      exercise: "Runs 3-4x per week, 30 minutes, occasional yoga",
      sleep: "Generally 7-8 hours nightly, trouble sleeping with current sinus pressure",
      stress: "Moderate - job is demanding but enjoys it",
      
      sexual_history: {
        sexually_active: true,
        partners: "Monogamous relationship with boyfriend",
        contraception: "Oral contraceptives",
        std_screening: "Negative screening 2023-08",
        pap_smear: {
          last: "2023-08",
          result: "Normal",
          next_due: "2026-08 (q3 years per guidelines)"
        }
      },
      
      functional_status: "Fully independent, no limitations",
      
      occupational_exposures: {
        work: "Elementary school - frequent exposure to viral URIs from students",
        pets: "None",
        environmental: "No known exposures"
      }
    },
    
    review_of_systems: {
      constitutional: "Mild fatigue, low-grade fever yesterday (99.8F at home), no chills, no weight loss",
      head: "Frontal headache, worse with bending forward",
      eyes: "No vision changes, no eye pain",
      ears: "Ears feel 'full', no hearing loss, no ear pain",
      nose: "Thick yellow/green nasal discharge, nasal congestion, decreased smell, occasional bloody mucus with blowing",
      throat: "Sore from post-nasal drip, no difficulty swallowing",
      respiratory: "No cough, no shortness of breath, no wheezing",
      cardiovascular: "No chest pain, palpitations, or edema",
      gastrointestinal: "Normal appetite, no nausea/vomiting, regular bowel habits",
      genitourinary: "No dysuria, normal menses (due in 1 week)",
      musculoskeletal: "No joint pain or swelling",
      skin: "No rashes",
      neurologic: "Headache as above, no dizziness, no weakness",
      psychiatric: "Frustrated with being sick, otherwise mood normal",
      hematologic: "No easy bruising or bleeding"
    },
    
    today_visit: {
      date: "2024-10-09",
      time: "09:00",
      
      hpi: "24F presents with 10 days of sinus symptoms. Started 2 weeks ago with typical viral URI symptoms - runny nose, sneezing, mild sore throat, fatigue. Several students in her 2nd grade class had colds the week prior. Symptoms initially improved around days 5-6, but then worsened significantly over past 4 days ('double sickening' pattern). Now has thick purulent nasal discharge (yellow-green), severe facial pressure and pain over cheeks bilaterally, frontal headache worse with bending forward, complete nasal obstruction, post-nasal drip, decreased sense of smell. Also reports pain in upper back teeth. Had low-grade fever yesterday (99.8F at home). Has tried OTC decongestants, Tylenol, Mucinex, saline spray with minimal relief. No previous sinus infections. Symptoms now interfering with work - hard to concentrate, took sick day today.",
      
      vitals: {
        bp: "118/72",
        hr: 78,
        rr: 16,
        temp: "99.2F",
        weight: "135 lbs",
        height: "5'4\"",
        bmi: 23.2,
        o2_sat: "99% on room air"
      },
      
      physical_exam: {
        general: "Well-appearing young woman, no acute distress, sounds congested when speaking",
        heent: {
          head: "Normocephalic, atraumatic",
          eyes: "Pupils equal, round, reactive. Conjunctivae clear, no injection. No periorbital edema.",
          ears: "TMs gray, mobile, no effusion. Canals clear.",
          nose: "Mucosa erythematous and edematous bilaterally. Thick purulent discharge visible in nasal passages. Septum midline.",
          throat: "Posterior pharynx mildly erythematous with visible post-nasal drip, no exudate, no tonsillar enlargement (s/p tonsillectomy)",
          sinuses: "Significant tenderness to palpation over bilateral maxillary sinuses. Mild tenderness over frontal sinuses. Transillumination not performed."
        },
        neck: "Supple, no lymphadenopathy, no thyromegaly",
        cardiovascular: "Regular rate and rhythm, normal S1/S2, no murmurs",
        respiratory: "Clear to auscultation bilaterally, no wheezes or crackles",
        skin: "Warm, dry, no rashes",
        neurologic: "Alert and oriented x3, cranial nerves II-XII intact"
      },
      
      assessment_and_plan: [
        {
          problem: "Acute Bacterial Rhinosinusitis",
          assessment: "Clinical diagnosis based on: (1) Symptoms >10 days without improvement, (2) 'Double sickening' - initial improvement followed by worsening, (3) Severe symptoms with purulent discharge, maxillary sinus tenderness, fever. Meets criteria for bacterial rather than viral sinusitis per IDSA guidelines. No imaging needed for uncomplicated acute sinusitis.",
          
          plan: [
            "Start amoxicillin-clavulanate (Augmentin) 875mg PO BID x 7 days",
            "Rationale: First-line antibiotic per IDSA guidelines. Amoxicillin alone not preferred due to increasing beta-lactamase resistance.",
            "Continue symptomatic treatment:",
            "- Pseudoephedrine 60mg PO q6h PRN for congestion",
            "- Saline nasal irrigation BID (more effective than spray)",
            "- Ibuprofen 400mg PO q6h PRN for pain/inflammation",
            "- Warm compress over sinuses",
            "Stay well-hydrated, rest",
            "Return if: Fever >101F, severe worsening, eye symptoms (swelling, vision changes), severe headache with neck stiffness, or no improvement in 3-4 days on antibiotics",
            "Should start feeling better within 48-72 hours of starting antibiotic",
            "No work note needed per patient request - planning to return to work Friday if feeling better"
          ],
          
          patient_education: [
            "This is likely bacterial sinusitis given duration >10 days and 'double sickening' pattern",
            "Antibiotics appropriate here - this is NOT just a viral cold",
            "Take full 7-day course even if feeling better",
            "Augmentin may cause diarrhea - take with food to minimize",
            "Continue birth control pill - antibiotics don't affect OCPs (common myth addressed)",
            "Saline irrigation is very effective - demonstrated technique",
            "Prevention: Hand hygiene at school, don't touch face"
          ],
          
          antibiotic_stewardship_note: "Antibiotics indicated here per IDSA guidelines - patient meets criteria for acute bacterial rhinosinusitis (symptoms >10 days OR double sickening OR severe symptoms). This is appropriate antibiotic use."
        }
      ],
      
      prescriptions: [
        {
          medication: "Amoxicillin-Clavulanate 875-125mg",
          directions: "Take 1 tablet by mouth twice daily for 7 days",
          quantity: 14,
          refills: 0,
          pharmacy: "CVS on Riverside Drive",
          notes: "Take with food to reduce GI upset"
        }
      ],
      
      patient_instructions: [
        "Take antibiotic with food twice daily for full 7 days",
        "Use saline irrigation twice daily (demonstrated NeilMed bottle use)",
        "Continue OTC symptom management as needed",
        "Rest, stay hydrated",
        "Return to work when fever-free for 24 hours and feeling well enough (likely Friday)",
        "Call if symptoms worsen or no improvement in 3-4 days",
        "Red flags: High fever, eye swelling/vision changes, severe headache with stiff neck, mental status changes"
      ],
      
      time_spent: {
        face_to_face: "15 minutes",
        straightforward_case: true
      },
      
      billing: {
        cpt: "99213",
        icd10: ["J01.90 (Acute sinusitis, unspecified)"],
        justification: "Low complexity straightforward acute problem in otherwise healthy young adult"
      }
    },
    
    key_clinical_issues: [
      "Meets criteria for bacterial sinusitis - antibiotics appropriate",
      "Otherwise healthy - no comorbidities",
      "Good candidate for standard first-line antibiotic therapy",
      "Low risk for complications"
    ],
    
    teaching_points: {
      antibiotic_stewardship: "This case demonstrates appropriate antibiotic use - meets IDSA criteria for bacterial sinusitis (>10 days without improvement + double sickening pattern + severe symptoms)",
      differential_diagnosis: "Could consider dental abscess given tooth pain, but more likely referred pain from maxillary sinusitis. Would refer to dentist if no improvement with antibiotics.",
      when_to_image: "No imaging needed for uncomplicated acute sinusitis. Would consider CT sinuses if: no response to 2 antibiotic courses, recurrent sinusitis (â‰¥4 episodes/year), or concern for complications (orbital/intracranial)."
    }
  },

  // ==========================================================================
  // PATIENT 4: MICHAEL CHEN (Moderate-High Complexity)  
  // 45M - Acute chest pain, high CV risk, needs urgent workup
  // ==========================================================================
  
  "P004": {
    slot_time: "09:30",
    complexity: "moderate-high",
    patient_id: "P004",
    mrn: "MRN-2019-05673",
    
    demographics: {
      name: { first: "Michael", middle: "David", last: "Chen", preferred: "Mike" },
      dob: "1979-07-12",
      age: 45,
      sex: "M",
      race: "Asian",
      ethnicity: "Chinese-American"
    },
    
    contact: {
      phone: "478-555-7234",
      email: "mchen@techcorp.com",
      address: "4521 Oak Ridge Court, Macon, GA 31210",
      marital_status: "Married",
      spouse: "Jennifer Chen",
      emergency_contact: {
        name: "Jennifer Chen (wife)",
        phone: "478-555-7235"
      }
    },
    
    insurance: {
      carrier: "Aetna (through employer - Tech Solutions Inc)",
      plan: "PPO Gold",
      copay_specialist: "$40",
      copay_er: "$250",
      deductible: "$2000 (met)"
    },
    
    visit_reason: "Chest discomfort",
    chief_complaint: "Had episode of chest pressure yesterday while mowing lawn, concerned it might be my heart",
    
    clinical_summary: {
      complexity_factors: [
        "Multiple CV risk factors (HTN, HLD, prediabetes, obesity, family history)",
        "High ASCVD risk (>7.5%)",
        "Acute chest pain requiring urgent evaluation",
        "Significant work-related stress"
      ],
      
      active_problems: [
        {
          problem: "Chest Pain - Possible Angina (NEW)",
          onset: "Yesterday afternoon (10/08/24 around 4pm)",
          character: "Pressure/tightness in center of chest",
          severity: "6/10 at worst",
          duration: "15-20 minutes",
          location: "Substernal, pressure-like, 'like someone sitting on chest'",
          radiation: "Slight radiation to left shoulder",
          associated_symptoms: [
            "Shortness of breath",
            "Sweating (but was hot and exerting)",
            "Mild nausea",
            "No vomiting",
            "No palpitations",
            "No dizziness"
          ],
          onset_circumstances: "Mowing lawn on hot day, had just pushed mower up hill",
          relief: "Stopped activity, rested in shade for ~30 min, symptoms gradually resolved",
          since_then: "No recurrence, but worried. Able to climb stairs at home without symptoms.",
          similar_episodes: "None exactly like this. Occasional mild chest 'tightness' with heavy exertion over past 2-3 months, but always brief (<1 min) and attributed to being 'out of shape'",
          why_presenting_now: "Wife insisted he come in. Father had MI at age 52."
        },
        {
          problem: "Hypertension",
          onset: "2017",
          status: "Suboptimally controlled",
          recent_readings: {
            office: ["138/88 (6 months ago)", "142/90 (1 year ago)"],
            home: "Patient doesn't check at home regularly"
          },
          current_treatment: "Lisinopril 20mg daily",
          adherence: "Admits sometimes forgets - maybe 80% adherent"
        },
        {
          problem: "Hyperlipidemia",
          onset: "2017",
          status: "Not at goal for high-risk patient",
          last_lipids: {
            date: "2024-04-15",
            ldl: 145,
            hdl: 38,
            triglycerides: 210,
            total: 225
          },
          current_treatment: "Atorvastatin 20mg daily",
          adherence: "Better than BP med, ~90%",
          goal_ldl: "<100 (given ASCVD risk >7.5%), ideally <70 if CAD diagnosed"
        },
        {
          problem: "Prediabetes",
          onset: "2022",
          status: "Progressively worsening",
          a1c_trend: [
            { date: "2024-04-15", value: 6.2 },
            { date: "2023-04-10", value: 5.9 },
            { date: "2022-04-05", value: 5.7 }
          ],
          fasting_glucose: "118 mg/dL (2024-04-15)",
          interventions: "Counseled on lifestyle changes multiple times, limited success"
        },
        {
          problem: "Obesity",
          bmi: 32.8,
          weight: 215,
          height: "5'10\"",
          weight_history: [
            { date: "2024-04-15", weight: 212 },
            { date: "2023-04-10", weight: 205 },
            { date: "2022-04-05", weight: 198 }
          ],
          trend: "Steadily increasing despite counseling"
        },
        {
          problem: "Gastroesophageal Reflux Disease (GERD)",
          onset: "2015",
          status: "Well-controlled on PPI",
          symptoms: "Occasional heartburn, worse with spicy foods or late meals",
          current_treatment: "Omeprazole 20mg daily",
          note: "Important to distinguish GERD from cardiac chest pain"
        }
      ],
      
      past_medical_history: [
        "Hypertension (2017)",
        "Hyperlipidemia (2017)",
        "Prediabetes (2022)",
        "Obesity",
        "GERD (2015)",
        "Obstructive sleep apnea - mild (diagnosed 2020, CPAP prescribed but not using)"
      ],
      
      past_surgical_history: [
        { year: 2010, procedure: "Arthroscopic knee surgery (meniscus repair), left knee" },
        { year: 1995, procedure: "Appendectomy" }
      ],
      
      current_medications: [
        { name: "Lisinopril", dose: "20mg", frequency: "once daily", indication: "Hypertension", adherence: "~80%" },
        { name: "Atorvastatin", dose: "20mg", frequency: "once daily", indication: "Hyperlipidemia", adherence: "~90%" },
        { name: "Omeprazole", dose: "20mg", frequency: "once daily", indication: "GERD", adherence: "95%" },
        { name: "Aspirin", dose: "81mg", frequency: "once daily", started: "Started 6 months ago for primary prevention given high ASCVD risk", adherence: "90%" }
      ],
      
      allergies: [
        { allergen: "No known drug allergies" }
      ]
    },
    
    family_history: {
      father: {
        status: "Living", age: 78,
        significant: "MYOCARDIAL INFARCTION at age 52",
        current: "Diabetes, hypertension, CAD s/p CABG age 58"
      },
      mother: {
        status: "Living", age: 75,
        conditions: ["Hypertension", "Hyperlipidemia", "Osteoporosis"]
      },
      siblings: {
        brother_1: { age: 48, conditions: ["Hypertension", "Prediabetes"] },
        sister_1: { age: 43, conditions: ["Healthy"] }
      },
      paternal_grandfather: "Died age 65, MI",
      maternal_grandfather: "Died age 82, stroke",
      premature_cad_family_hx: "YES - father with MI at 52 (premature CAD defined as <55 in male relative)",
      diabetes_family_hx: "Father, paternal uncle, paternal grandmother"
    },
    
    social_history: {
      marital_status: "Married 18 years",
      children: "Two children - ages 14 and 11, both healthy",
      occupation: "Software engineer / team lead at tech company",
      work_stress: "HIGH - recently promoted to management, long hours, high pressure deadlines",
      typical_work_hours: "50-60 hours/week, some weekend work",
      
      tobacco: {
        status: "Never smoker"
      },
      
      alcohol: {
        status: "Moderate",
        frequency: "2-3 beers most evenings to 'unwind'",
        weekends: "3-4 drinks Friday/Saturday nights",
        concern: "Wife thinks he's drinking too much lately due to work stress"
      },
      
      drugs: { status: "None", denies_all: true },
      
      diet: {
        breakfast: "Often skips or coffee only",
        lunch: "Usually fast food or takeout at desk",
        dinner: "Wife cooks healthy meals but portions large, late dinners (8-9pm)",
        snacks: "Chips, cookies while working late",
        soda: "2-3 cans diet soda daily",
        assessment: "Poor diet quality, irregular meal timing, high calorie intake"
      },
      
      exercise: {
        current: "Minimal - sedentary job, no structured exercise",
        past: "Played basketball in college, was active until ~age 30",
        barriers: "Long work hours, fatigue, 'no time'",
        recent: "Yesterday's lawn mowing was more activity than usual in past month"
      },
      
      sleep: {
        duration: "5-6 hours on weeknights, catches up on weekends",
        quality: "Poor - wife reports loud snoring, occasional gasping",
        osa_diagnosis: "Diagnosed with mild OSA 2020, prescribed CPAP",
        cpap_use: "Not using - 'too uncomfortable', only used 2-3 months after getting it"
      },
      
      stress_management: {
        work_stress: "Very high - new management role overwhelming",
        coping: "Drinking, watching TV, 'zoning out on phone'",
        mental_health: "Denies depression but admits feeling 'burned out' and anxious about work performance"
      }
    },
    
    review_of_systems: {
      constitutional: "Some fatigue (attributes to poor sleep and work stress), no fever, no chills, no unintentional weight loss",
      
      cardiovascular: {
        chest_pain: "As per HPI - substernal pressure yesterday",
        palpitations: "Occasional awareness of heart beating, especially when stressed or after caffeine",
        orthopnea: "No",
        pnd: "No",
        edema: "No leg swelling",
        claudication: "No leg pain with walking",
        syncope: "No fainting or near-fainting"
      },
      
      respiratory: "No chronic cough, shortness of breath only with chest pain episode yesterday, no wheezing",
      
      gastrointestinal: "Occasional heartburn (GERD), well-controlled on omeprazole. Regular bowel habits. No nausea except during chest pain episode.",
      
      genitourinary: "No dysuria, nocturia x1 (baseline)",
      
      musculoskeletal: "Chronic mild left knee pain (s/p surgery), no new joint pains",
      
      neurologic: "No headaches, no dizziness, no weakness, no numbness",
      
      psychiatric: "Stressed about work, some anxiety, denies depression though wife concerned. Sleep deprived.",
      
      endocrine: "No heat/cold intolerance, no polyuria/polydipsia (though prediabetic)"
    },
    
    today_visit: {
      date: "2024-10-09",
      time: "09:30",
      urgency: "Urgent - chest pain evaluation",
      
      hpi_detailed: "45M with multiple CV risk factors (HTN, HLD, prediabetes, obesity, strong family history of premature CAD, sedentary lifestyle) presents with concerning chest pain episode yesterday. While pushing lawn mower up hill in hot weather around 4pm, developed substernal chest pressure/tightness, rated 6/10 severity, described as 'like someone sitting on my chest.' Associated with mild SOB, diaphoresis, nausea. Radiated slightly to left shoulder. Lasted 15-20 minutes, resolved gradually with rest in shade. No recurrence since, but now concerned given family history. Denies any symptoms currently. In retrospect, admits to 2-3 brief episodes (< 1 minute) of chest 'tightness' with heavy exertion over past few months - carrying heavy boxes up stairs, running to catch kids at park - but always dismissed as being out of shape. Never lasted >1 min. Yesterday's episode was different - longer duration, more severe, more associated symptoms. Wife very worried given his father's MI at 52. Patient reluctant to go to ER, came to office instead.",
      
      vitals: {
        bp: "148/92 (elevated - patient anxious)",
        hr: 88,
        rr: 16,
        temp: 98.4,
        weight: 215,
        height: "5'10\"",
        bmi: 32.8,
        o2_sat: "98% on room air"
      },
      
      physical_exam: {
        general: "Well-appearing Asian male, appears stated age, mildly anxious but no acute distress, able to speak in full sentences",
        
        heent: "Normocephalic, atraumatic. Pupils equal, round, reactive. Oropharynx clear.",
        
        neck: "Supple, no JVD, no thyromegaly, no carotid bruits, 2+ carotid pulses bilaterally",
        
        cardiovascular: {
          inspection: "PMI not displaced",
          palpation: "No thrills, no heaves",
          auscultation: "Regular rate and rhythm, normal S1/S2, no murmurs, no rubs, no gallops",
          peripheral_pulses: "2+ throughout (radial, femoral, dorsalis pedis, posterior tibial bilaterally), no bruits",
          extremities: "No edema, no cyanosis, capillary refill <2 seconds"
        },
        
        respiratory: "Clear to auscultation bilaterally, no wheezes, no crackles, symmetric chest expansion",
        
        abdomen: "Obese, soft, non-tender, non-distended, normal bowel sounds, no hepatosplenomegaly, no masses",
        
        musculoskeletal: "No chest wall tenderness to palpation",
        
        neurologic: "Alert and oriented x3, cranial nerves II-XII intact, no focal deficits",
        
        skin: "Warm, dry, no rashes"
      },
      
      in_office_workup: {
        ekg: {
          performed: "Yes, 12-lead EKG in office",
          timing: "Performed immediately upon arrival",
          interpretation: {
            rate: "82 bpm",
            rhythm: "Normal sinus rhythm",
            axis: "Normal axis",
            intervals: "PR 160ms, QRS 90ms, QT/QTc 400/420ms (normal)",
            st_segments: "No acute ST elevations or depressions",
            t_waves: "Flattened T waves in leads V4-V6 (non-specific, could be normal variant or suggest ischemia)",
            q_waves: "No pathologic Q waves",
            comparison: "No prior EKG on file for comparison",
            overall: "NO ACUTE CHANGES suggestive of STEMI, but flattened T waves in lateral leads are concerning in context of symptoms and risk factors"
          },
          note: "EKG can be normal or non-specific even in presence of significant CAD. Flattened T waves warrant further evaluation given clinical context."
        }
      },
      
      risk_stratification: {
        ascvd_risk_10_year: {
          calculated: "12.4%",
          inputs: {
            age: 45,
            sex: "Male",
            race: "Asian",
            total_cholesterol: 225,
            hdl: 38,
            sbp: 148,
            on_bp_med: true,
            diabetes: false,
            smoker: false
          },
          interpretation: "HIGH RISK (>7.5%)"
        },
        
        framingham_risk: "11.8% 10-year risk",
        
        risk_factors_summary: [
          "Hypertension (suboptimally controlled)",
          "Hyperlipidemia (LDL 145, not at goal)",
          "Prediabetes (A1C 6.2)",
          "Obesity (BMI 32.8)",
          "Sedentary lifestyle",
          "Poor diet",
          "Family history of premature CAD (father MI at 52)",
          "Obstructive sleep apnea (untreated)",
          "High stress, possible excess alcohol use",
          "Low HDL (38)"
        ],
        
        clinical_concern: "Multiple risk factors + exertional chest pain with duration >10 minutes = HIGH CONCERN for obstructive CAD"
      },
      
      differential_diagnosis: {
        most_concerning: [
          {
            diagnosis: "Angina Pectoris / Coronary Artery Disease",
            probability: "HIGH",
            supporting: [
              "Exertional chest pressure, substernal",
              "Duration 15-20 minutes",
              "Radiation to left shoulder",
              "Associated SOB, diaphoresis, nausea",
              "Resolved with rest",
              "Multiple cardiac risk factors",
              "Strong family history premature CAD",
              "Flattened T waves on EKG",
              "Recent similar but briefer episodes"
            ],
            against: [
              "Symptoms resolved, currently asymptomatic",
              "EKG no acute changes",
              "Young age (but father had MI at 52)"
            ],
            action: "URGENT cardiac workup required"
          },
          {
            diagnosis: "GERD / Esophageal spasm",
            probability: "POSSIBLE but less likely",
            supporting: [
              "Known GERD",
              "Substernal location",
              "Nausea"
            ],
            against: [
              "Exertional trigger",
              "Multiple cardiac risk factors make cardiac cause more likely",
              "20-minute duration more consistent with cardiac",
              "Associated SOB and diaphoresis"
            ]
          },
          {
            diagnosis: "Musculoskeletal chest pain",
            probability: "UNLIKELY",
            against: [
              "No chest wall tenderness",
              "Exertional trigger",
              "Associated systemic symptoms",
              "Not reproducible with palpation"
            ]
          }
        ]
      },
      
      assessment_and_plan: [
        {
          problem: "Chest Pain - Possible Angina Pectoris (HIGH CONCERN)",
          
          assessment: "45M with multiple significant cardiac risk factors (HTN, HLD, prediabetes, obesity, strong family history of premature CAD at age 52, sedentary lifestyle, OSA) presents with exertional substernal chest pressure lasting 15-20 minutes, radiation to left shoulder, associated SOB, diaphoresis, nausea, relieved by rest. Recent similar but briefer episodes. EKG shows non-specific T wave flattening in lateral leads. ASCVD 10-year risk 12.4%. This presentation is HIGH RISK for obstructive coronary disease and warrants urgent evaluation.",
          
          plan_immediate: [
            "URGENT CARDIOLOGY REFERRAL - called cardiology office, able to see patient tomorrow 10/10 at 2pm with Dr. James Patterson",
            "Stress test ordered - will be scheduled by cardiology",
            "Labs today: Troponin x2 (now and 3 hours), BMP, CBC, lipid panel, A1C, TSH",
            "Continue aspirin 81mg daily",
            "Start sublingual nitroglycerin 0.4mg - use if chest pain recurs (provided prescription and sample)",
            "STRICT ACTIVITY RESTRICTION until cardiac evaluation: No strenuous activity, no heavy lifting, no lawn work, no stairs if avoidable",
            "Patient instructed: If ANY chest pain recurs, even briefly - call 911 immediately, do NOT drive to office or ER",
            "If chest pain with rest, or lasting >5 minutes, or severe, or with new symptoms - call 911",
            "Patient and wife both understand urgency and warning signs"
          ],
          
          plan_pending_cardiology: "Depending on stress test results, patient may need cardiac catheterization. Will defer to cardiology for management decisions.",
          
          patient_education: [
            "Explained concern for coronary artery disease given risk factors and symptoms",
            "This is NOT a heart attack currently, but symptoms suggest blood flow to heart may be reduced during exertion",
            "Stress test will help determine if blockages present in heart arteries",
            "Important to see cardiologist urgently - appointment tomorrow",
            "Absolute activity restriction until cleared by cardiology",
            "Wife present for education, understands warning signs, knows to call 911 if any recurrence"
          ],
          
          disposition: "URGENT follow-up with cardiology tomorrow. Will call patient tonight to check on troponin results. Patient has office/cell numbers to call with any concerns."
        },
        {
          problem: "Hypertension - Uncontrolled",
          assessment: "BP 148/92 today (elevated even accounting for anxiety), has been suboptimally controlled. Currently on lisinopril 20mg with suboptimal adherence. Contributing to cardiovascular risk.",
          plan: [
            "Increase lisinopril to 40mg daily (will provide new prescription)",
            "Emphasized critical importance of daily medication adherence given cardiac risk",
            "Recommend home BP monitoring - will provide BP cuff prescription",
            "Target BP <130/80 given multiple cardiac risk factors",
            "Recheck after cardiology evaluation complete"
          ]
        },
        {
          problem: "Hyperlipidemia - Not at Goal",
          assessment: "LDL 145 on atorvastatin 20mg. Given HIGH ASCVD risk (>10%), goal LDL should be <100, ideally <70. If CAD confirmed, will need LDL <70.",
          plan: [
            "Increase atorvastatin to 80mg daily (high-intensity statin indicated for high risk)",
            "Recheck lipids in 6 weeks",
            "If CAD confirmed by cardiology, may need additional lipid-lowering therapy (ezetimibe or PCSK9i) to achieve goal <70"
          ]
        },
        {
          problem: "Prediabetes - Progressing",
          assessment: "A1C 6.2 and trending up. Obesity, sedentary, poor diet. Strong family history diabetes. At very high risk for progression to diabetes.",
          plan: [
            "Metformin 500mg daily indicated to prevent progression to diabetes (per ADA guidelines for A1C >6.0 with risk factors)",
            "Will start after cardiac evaluation complete (don't want to add too many new meds today)",
            "Intensive lifestyle counseling - diet and exercise critical",
            "Consider referral to diabetes prevention program",
            "Recheck A1C in 3 months"
          ]
        },
        {
          problem: "Obesity",
          assessment: "BMI 32.8. Major modifiable cardiac risk factor. Poor diet and sedentary lifestyle.",
          plan: [
            "Cardiology clearance needed before starting exercise program",
            "Once cleared, refer to cardiac rehab (likely covered if CAD diagnosed)",
            "Dietitian referral for medical nutrition therapy",
            "Target weight loss 10-15% of body weight (21-32 lbs) over next 6-12 months",
            "Will discuss GLP-1 agonists for weight loss if lifestyle modifications insufficient (once cardiac situation clarified)"
          ]
        },
        {
          problem: "Obstructive Sleep Apnea - Untreated",
          assessment: "Diagnosed 2020 with mild OSA. Not using CPAP. Untreated OSA increases cardiac risk and contributes to HTN.",
          plan: [
            "Strongly encouraged to resume CPAP use",
            "OSA worsens cardiovascular outcomes",
            "May need new sleep study if current CPAP not effective",
            "Will address after cardiac evaluation"
          ]
        },
        {
          problem: "Lifestyle Factors / Psychosocial",
          assessment: "High work stress, poor sleep, possibly excessive alcohol use, minimal exercise, poor diet. All contributing to cardiovascular risk and overall health.",
          plan: [
            "Need comprehensive lifestyle modification - this is NOT optional given cardiac risk",
            "Discussed alcohol reduction - current intake concerning and contributes to HTN",
            "May benefit from counseling for stress management and burnout",
            "Encouraged to prioritize health over work demands - 'you can't work if you have a heart attack'",
            "Wife supportive and will help with lifestyle changes",
            "May need mental health referral for anxiety/burnout after cardiac situation addressed"
          ]
        }
      ],
      
      orders_placed: [
        { type: "Labs - STAT", tests: ["Troponin I (now)", "Troponin I (in 3 hours)", "BMP", "CBC", "Lipid panel", "Hemoglobin A1C", "TSH"] },
        { type: "Referral - URGENT", specialty: "Cardiology", provider: "Dr. James Patterson", appointment: "Tomorrow 10/10/24 at 2pm" },
        { type: "DME", item: "Home blood pressure monitor", note: "For daily home BP monitoring" }
      ],
      
      prescriptions_new: [
        { med: "Lisinopril 40mg", sig: "Take 1 tablet daily", qty: 90, refills: 3, pharmacy: "CVS Riverside" },
        { med: "Atorvastatin 80mg", sig: "Take 1 tablet daily at bedtime", qty: 90, refills: 3, pharmacy: "CVS Riverside" },
        { med: "Nitroglycerin 0.4mg sublingual", sig: "Place 1 tablet under tongue if chest pain occurs. May repeat q5min x3. If no relief after 3 doses or pain worsens, call 911.", qty: 25, refills: 1, pharmacy: "CVS Riverside", note: "Instructed in proper use" }
      ],
      
      patient_instructions_detailed: [
        "ACTIVITY RESTRICTION: No strenuous activity, no heavy lifting (>10 lbs), minimize stairs, no lawn work, take it very easy until cleared by cardiology",
        
        "EMERGENCY INSTRUCTIONS: Call 911 immediately if:",
        "- ANY chest pain or pressure recurs",
        "- Shortness of breath",
        "- Pain lasting >5 minutes even with nitroglycerin",
        "- Severe or worsening pain",
        "- Pain with nausea, vomiting, sweating, lightheadedness",
        
        "MEDICATIONS:",
        "- Continue aspirin 81mg daily",
        "- START lisinopril 40mg (increased) - take every morning",
        "- START atorvastatin 80mg (increased) - take every evening",
        "- Continue omeprazole",
        "- Have nitroglycerin with you at all times - keep in pocket or on nightstand",
        
        "FOLLOW-UP:",
        "- Cardiology appointment TOMORROW (10/10) at 2pm - DO NOT MISS",
        "- Return to office in 3 hours for second troponin (patient will return at 12:30pm)",
        "- I will call you tonight with troponin results",
        "- Call my office or answering service with ANY concerns - you have the numbers",
        
        "LIFESTYLE:",
        "- Low sodium diet (<2000mg/day)",
        "- No alcohol until cardiac evaluation complete",
        "- Rest, take it easy",
        
        "Patient and wife verbalized understanding of all instructions and urgency of situation."
      ],
      
      time_spent: {
        face_to_face: "45 minutes",
        counseling: "30 minutes (>50% of visit)",
        complexity: "High - urgent cardiac evaluation, multiple problems, extensive counseling and coordination"
      },
      
      billing: {
        cpt: "99215",
        icd10: ["R07.9 (Chest pain, unspecified)", "I10 (Essential hypertension)", "E78.5 (Hyperlipidemia)", "R73.03 (Prediabetes)", "E66.9 (Obesity)", "G47.33 (Obstructive sleep apnea)", "Z86.79 (Family history premature CAD)"],
        justification: "High complexity urgent visit - chest pain evaluation with high cardiac risk, multiple chronic conditions requiring management, extensive counseling, coordination of urgent cardiology referral"
      },
      
      documentation_note: "This patient requires close monitoring. Called cardiology office personally to ensure urgent appointment. Spoke with Dr. Patterson's nurse - they will expedite stress test. Patient has my cell phone number. Wife understands gravity of situation. Will personally call patient tonight with troponin results and to check on symptoms."
    },
    
    key_clinical_issues: [
      "URGENT: Possible angina - requires immediate cardiac workup",
      "Multiple cardiac risk factors including strong family history",
      "Activity restriction until cleared by cardiology",
      "Close monitoring needed - troponin follow-up, cardiology tomorrow",
      "High risk for adverse cardiac event if not evaluated urgently",
      "Lifestyle modifications critical but need cardiac clearance first"
    ],
    
    red_flags: [
      "Any recurrence of chest pain - call 911 immediately",
      "If troponin elevated - may need ER transfer",
      "No improvement in symptoms over next 24-48 hours",
      "Development of rest angina",
      "Syncope or presyncope"
    ],
    
    follow_up_plan: {
      today_3pm: "Patient returns for second troponin",
      tonight: "Physician will call with troponin results",
      tomorrow_2pm: "Cardiology appointment with Dr. Patterson",
      one_week: "Office follow-up after cardiology evaluation complete"
    }
  }

},

  // ==========================================================================
  // PATIENT 5: MARGARET THOMPSON (High Complexity)
  // 68F - Post-MI, new HF diagnosis, diabetes, CKD, starting cardiac rehab
  // ==========================================================================
  
  "P005": {
    slot_time: "10:00",
    complexity: "high",
    patient_id: "P005",
    mrn: "MRN-2016-07824",
    
    demographics: {
      name: { first: "Margaret", middle: "Louise", last: "Thompson", preferred: "Maggie" },
      dob: "1956-04-22",
      age: 68,
      sex: "F",
      race: "White",
      ethnicity: "Non-Hispanic"
    },
    
    contact: {
      phone: "478-555-9142",
      address: "2847 Maple Avenue, Macon, GA 31204",
      lives_with: "Alone (widow)",
      emergency_contact: {
        name: "Jennifer Thompson (daughter)",
        phone: "478-555-9143",
        relationship: "Daughter"
      }
    },
    
    insurance: {
      primary: "Medicare Part B",
      secondary: "United Healthcare Medicare Advantage",
      part_d: "Express Scripts",
      copays: "Fixed copays, affordable"
    },
    
    visit_reason: "Post-MI follow-up, new heart failure, medication management",
    chief_complaint: "Feeling weak and tired since heart attack 3 weeks ago, new swelling in feet",
    
    clinical_summary: {
      complexity_factors: [
        "Recent NSTEMI 3 weeks ago",
        "New diagnosis of heart failure (EF 40%)",
        "Chronic kidney disease worsening",
        "Type 2 diabetes poorly controlled",
        "Starting cardiac rehab next week",
        "Living alone - functional concerns",
        "8 new medications post-MI",
        "Widow - limited support system"
      ],
      
      recent_major_event: {
        event: "Non-ST Elevation Myocardial Infarction (NSTEMI)",
        date: "2024-09-18",
        presentation: "68F presented to ED with 2 hours of substernal chest pressure, nausea, diaphoresis. Troponin elevated to 8.4. EKG showed ST depressions in V4-V6.",
        hospital: "Medical Center of Central Georgia",
        admission_dates: "2024-09-18 to 2024-09-21",
        
        cardiac_catheterization: {
          date: "2024-09-18 (emergent)",
          findings: "80% stenosis of proximal LAD, 70% stenosis of mid-RCA, 50% stenosis of LCx",
          intervention: "PCI with drug-eluting stent to LAD",
          note: "RCA lesion deferred - plan for staged PCI in 4-6 weeks if persistent ischemia on stress test"
        },
        
        complications: {
          heart_failure: "Developed acute systolic HF during hospitalization. Echo showed new LV dysfunction with EF 40% (was 55% two years ago). Moderate mitral regurgitation.",
          ckd_worsening: "Cr rose from baseline 1.4 to 2.1 post-contrast, improved to 1.8 by discharge with hydration",
          hyperglycemia: "Blood sugars 300-400 range during hospitalization, started on insulin"
        },
        
        discharge_summary_key_points: [
          "NSTEMI treated with PCI/DES to LAD",
          "New systolic heart failure (EF 40%)",
          "Acute on chronic kidney injury (Cr 1.8, baseline 1.4)",
          "Diabetes poorly controlled (A1C 9.2)",
          "Started on dual antiplatelet therapy (aspirin + ticagrelor)",
          "Started on high-intensity statin (atorvastatin 80mg)",
          "Started on beta blocker (metoprolol succinate)",
          "Started on ACE inhibitor (lisinopril)",
          "Started on basal insulin (Lantus)",
          "Cardiac rehab referral placed"
        ],
        
        discharge_medications: [
          "Aspirin 81mg daily",
          "Ticagrelor 90mg BID (continue x 12 months minimum)",
          "Atorvastatin 80mg daily",
          "Metoprolol succinate 50mg BID",
          "Lisinopril 10mg daily (start low due to CKD)",
          "Furosemide 20mg daily (new for HF)",
          "Metformin 1000mg BID (continue)",
          "Insulin glargine 20 units at bedtime (NEW)"
        ]
      },
      
      active_problems: [
        {
          problem: "Coronary Artery Disease, status post NSTEMI with PCI",
          onset: "2024-09-18",
          status: "Recent, recovering",
          current_symptoms: "No chest pain since discharge. Occasional mild dyspnea with exertion (likely from new HF).",
          residual_disease: "Known 70% RCA stenosis, 50% LCx stenosis - may need staged PCI",
          risk_factors: "Diabetes, hypertension, hyperlipidemia, CKD, postmenopausal, family history",
          secondary_prevention: "On optimal medical therapy post-MI"
        },
        {
          problem: "Heart Failure with Reduced Ejection Fraction (HFrEF)",
          onset: "2024-09-18 (new diagnosis during MI)",
          ejection_fraction: "40% (was 55% in 2022)",
          etiology: "Ischemic cardiomyopathy from MI",
          nyha_class: "II (dyspnea with moderate exertion)",
          current_symptoms: [
            "Dyspnea with climbing stairs (new)",
            "Bilateral lower extremity edema (new, 1+ pitting to ankles)",
            "Fatigue and weakness (markedly increased post-MI)",
            "No orthopnea or PND yet",
            "Weight gain 5 lbs since discharge"
          ],
          daily_weights: [
            { date: "2024-10-07", weight: 162 },
            { date: "2024-10-08", weight: 163 },
            { date: "2024-10-09", weight: 164 }
          ],
          baseline_weight: "159 lbs pre-MI",
          current_treatment: "Metoprolol, lisinopril, furosemide - suboptimal GDMT dosing"
        },
        {
          problem: "Type 2 Diabetes Mellitus",
          onset: "2010",
          status: "Poorly controlled, worsened during hospitalization",
          last_a1c: { value: 9.2, date: "2024-09-19" },
          a1c_trend: [
            { date: "2024-09-19", value: 9.2, note: "During hospitalization for MI" },
            { date: "2024-06-15", value: 8.1 },
            { date: "2024-03-12", value: 7.9 },
            { date: "2023-12-08", value: 7.8 }
          ],
          complications: [
            "Diabetic nephropathy (CKD Stage 3)",
            "Diabetic retinopathy (mild NPDR, last eye exam 2024-02)",
            "Peripheral neuropathy (feet)"
          ],
          home_glucose_monitoring: {
            frequency: "BID since starting insulin (fasting and bedtime)",
            recent_readings: "Fasting 180-240, bedtime 200-280",
            note: "Still running high despite insulin - needs titration"
          },
          current_treatment: "Metformin 1000mg BID, Insulin glargine 20 units qHS (started in hospital)"
        },
        {
          problem: "Chronic Kidney Disease Stage 3b",
          onset: "2018",
          status: "Worsening, especially post-MI",
          etiology: "Diabetic nephropathy, hypertensive nephrosclerosis, contrast-induced AKI",
          last_labs: {
            date: "2024-10-07 (2 weeks post-discharge)",
            creatinine: 1.9,
            egfr: 31,
            bun: 42,
            potassium: 4.8,
            uacr: 450
          },
          baseline_pre_mi: "Cr 1.4, eGFR 45",
          ckd_trajectory: [
            { date: "2024-10-07", egfr: 31, note: "Post-MI/contrast" },
            { date: "2024-08-15", egfr: 45, note: "Pre-MI baseline" },
            { date: "2024-05-10", egfr: 48 },
            { date: "2024-02-12", egfr: 52 }
          ],
          clinical_significance: "Approaching Stage 4 CKD (eGFR <30). May need nephrology referral soon. Limits medication options.",
          monitoring: "Close monitoring needed with all the new cardiac meds affecting kidneys"
        },
        {
          problem: "Hypertension",
          onset: "2005",
          status: "Previously controlled, now on hold to uptitrate ACE-I for HF",
          recent_readings: "128/74 at discharge, 132/78 today",
          goal: "<130/80",
          current_treatment: "Lisinopril 10mg daily (need to uptitrate for HF but limited by CKD)"
        },
        {
          problem: "Hyperlipidemia",
          status: "On high-intensity statin post-MI",
          last_lipids: {
            date: "2024-06-15",
            ldl: 135,
            hdl: 48,
            triglycerides: 178
          },
          goal_post_mi: "LDL <70 mg/dL",
          current_treatment: "Atorvastatin 80mg daily (started in hospital)"
        },
        {
          problem: "Hypothyroidism",
          onset: "2012",
          status: "Well-controlled",
          last_tsh: { value: 2.8, date: "2024-06-15" },
          current_treatment: "Levothyroxine 100mcg daily"
        },
        {
          problem: "Osteoarthritis",
          locations: ["Bilateral knees", "Hands"],
          status: "Chronic, limiting mobility",
          impact: "Makes cardiac rehab and exercise challenging",
          current_management: "Acetaminophen PRN (NSAIDs contraindicated with CKD and on dual antiplatelet therapy)"
        }
      ],
      
      past_surgical_history: [
        { year: 2024, procedure: "Percutaneous coronary intervention with DES to LAD" },
        { year: 2018, procedure: "Cholecystectomy (laparoscopic)" },
        { year: 1992, procedure: "Hysterectomy for fibroids" },
        { year: 1985, procedure: "Appendectomy" }
      ],
      
      current_medications: [
        { name: "Aspirin", dose: "81mg", frequency: "once daily", indication: "Post-MI, CAD", start_date: "2024-09-18" },
        { name: "Ticagrelor", dose: "90mg", frequency: "twice daily", indication: "Post-PCI (must continue x 12 months)", start_date: "2024-09-18", critical: true, duration: "Until September 2025" },
        { name: "Atorvastatin", dose: "80mg", frequency: "once daily at bedtime", indication: "Post-MI, high-intensity statin", start_date: "2024-09-18" },
        { name: "Metoprolol succinate", dose: "50mg", frequency: "twice daily", indication: "Post-MI, heart failure", start_date: "2024-09-18", note: "Need to uptitrate for HF" },
        { name: "Lisinopril", dose: "10mg", frequency: "once daily", indication: "Post-MI, heart failure, HTN, CKD protection", start_date: "2024-09-18", note: "Started low dose due to CKD, need to uptitrate for HF" },
        { name: "Furosemide", dose: "20mg", frequency: "once daily", indication: "Heart failure, volume management", start_date: "2024-09-18" },
        { name: "Metformin", dose: "1000mg", frequency: "twice daily", indication: "Type 2 Diabetes", start_date: "2010", note: "Borderline for eGFR 31, monitor closely" },
        { name: "Insulin glargine", dose: "20 units", frequency: "at bedtime", indication: "Type 2 Diabetes", start_date: "2024-09-18", note: "Needs titration - sugars still high" },
        { name: "Levothyroxine", dose: "100mcg", frequency: "once daily in morning", indication: "Hypothyroidism", start_date: "2012" },
        { name: "Acetaminophen", dose: "650mg", frequency: "three times daily as needed", indication: "Osteoarthritis pain", note: "Max 3000mg/day" }
      ],
      
      allergies: [
        { allergen: "Lisinopril", reaction: "Cough (developed after 2 weeks)", severity: "Mild", verified: true, note: "But tolerating so far since restart" },
        { allergen: "Codeine", reaction: "Nausea, vomiting", severity: "Moderate" }
      ],
      
      pharmacy_records: {
        primary_pharmacy: "Walmart Pharmacy",
        discharge_meds_filled: "2024-09-21 - all new medications filled",
        adherence_concern: "Patient overwhelmed by number of new medications, daughter helping with pillbox",
        cost_barriers: "Several new medications expensive (ticagrelor copay $85/month), daughter helping financially"
      }
    },
    
    specialist_consultations: [
      {
        specialty: "Cardiology",
        provider: "Dr. Robert Martinez, MD",
        practice: "Macon Heart Center",
        
        recent_encounters: [
          {
            date: "2024-09-18",
            setting: "Inpatient - cardiac cath lab",
            procedure: "Diagnostic cardiac catheterization with PCI",
            findings: "Three-vessel CAD: 80% proximal LAD (stented), 70% mid-RCA, 50% mid-LCx",
            intervention: "DES to proximal LAD with excellent result",
            complications: "None during procedure",
            recommendations: [
              "Dual antiplatelet therapy x 12 months minimum",
              "High-intensity statin",
              "Beta blocker and ACE-I for post-MI and new HF",
              "Cardiac rehab essential",
              "Follow-up stress test in 4-6 weeks to assess RCA lesion - may need staged PCI"
            ]
          },
          {
            date: "2024-09-20",
            setting: "Inpatient consultation",
            reason: "Heart failure management",
            findings: "New systolic dysfunction EF 40%, moderate MR. Patient developed volume overload during hospitalization.",
            echo_findings: {
              lvef: "40%",
              lv_size: "Mildly dilated",
              regional_wall_motion: "Hypokinesis of anterior and apical segments (LAD territory)",
              valves: "Moderate mitral regurgitation (functional)",
              diastolic_function: "Grade 2 diastolic dysfunction",
              rv_function: "Normal",
              estimated_pa_pressure: "38 mmHg"
            },
            recommendations: [
              "Start guideline-directed medical therapy for HFrEF",
              "Beta blocker, ACE-I, consider aldosterone antagonist if K+ allows",
              "Diuretic for volume management",
              "Target GDMT doses as tolerated by BP and renal function",
              "Repeat echo in 3 months to assess for recovery of EF",
              "May be ICD candidate if EF remains â‰¤35% after 40 days and optimal medical therapy"
            ]
          }
        ],
        
        upcoming_appointment: {
          date: "2024-10-15",
          reason: "Post-MI follow-up, review stress test results, assess for staged PCI of RCA"
        }
      },
      {
        specialty: "Endocrinology",
        provider: "Dr. Lisa Chang, MD",
        practice: "Georgia Diabetes Center",
        
        most_recent_visit: {
          date: "2024-06-15",
          reason: "Diabetes management",
          findings: "A1C 8.1, worsening control. Patient not checking sugars regularly. Resistant to starting insulin. Gaining weight. Metformin alone insufficient.",
          recommendations: [
            "Strongly recommended adding GLP-1 agonist or insulin",
            "Patient declined both - wanted to 'try harder with diet'",
            "Discussed CV benefits of GLP-1, patient still hesitant",
            "Follow-up in 3 months"
          ],
          note: "Patient started on insulin during MI hospitalization - this was clinically necessary and she's now accepting it"
        },
        
        plan_going_forward: "Will need to see endocrinology for insulin titration and optimization. May be able to add GLP-1 for additional benefit once cardiac status stable."
      },
      {
        specialty: "Ophthalmology",
        provider: "Dr. James Wilson, MD",
        
        last_exam: {
          date: "2024-02-12",
          findings: "Mild nonproliferative diabetic retinopathy OU, no macular edema",
          recommendation: "Annual follow-up, sooner if vision changes. Emphasized importance of glucose control.",
          next_due: "February 2025"
        }
      }
    ],
    
    imaging_studies: [
      {
        modality: "Transthoracic Echocardiogram",
        date: "2024-09-19",
        indication: "Evaluate LV function post-NSTEMI",
        findings: {
          lvef: "40% (moderately reduced)",
          lv_size: "Mildly dilated (LVEDD 5.6 cm)",
          lv_wall_thickness: "Normal",
          regional_wall_motion: "Hypokinesis of anterior wall, septum, and apex (LAD distribution)",
          rv_size_function: "Normal size and function",
          la_size: "Mildly dilated (4.2 cm)",
          mitral_valve: "Moderate functional mitral regurgitation secondary to LV dilation",
          aortic_valve: "Mild aortic sclerosis, no stenosis",
          tricuspid_valve: "Trace TR, estimated RVSP 38 mmHg",
          pericardium: "No effusion",
          diastolic_function: "Grade 2 diastolic dysfunction (pseudonormal pattern)"
        },
        comparison: "Echo from 2022 showed LVEF 55%, no regional wall motion abnormalities. Significant decline in function.",
        impression: "Moderate LV systolic dysfunction with regional wall motion abnormalities in LAD territory consistent with recent MI. Moderate functional MR. Mild pulmonary hypertension.",
        clinical_significance: "New heart failure. Will need GDMT optimization and repeat echo in 3 months to see if EF recovers."
      },
      {
        modality: "Chest X-ray",
        date: "2024-09-18",
        indication: "Chest pain, rule out MI",
        findings: "Mild cardiomegaly. Mild pulmonary vascular congestion. Small bilateral pleural effusions. No acute infiltrate.",
        impression: "Findings consistent with heart failure.",
        comparison: "No prior chest X-rays on file for comparison."
      },
      {
        modality: "Cardiac Catheterization Angiography",
        date: "2024-09-18",
        operator: "Dr. Robert Martinez",
        access: "Right radial artery",
        findings: {
          lmca: "Normal",
          lad: "80% stenosis in proximal segment with TIMI 2 flow",
          lcx: "50% stenosis in mid-segment",
          rca: "70% stenosis in mid-segment, TIMI 3 flow",
          lv_gram: "Not performed (renal protection)",
          hemodynamics: "Not recorded"
        },
        intervention: {
          vessel: "Proximal LAD",
          stent: "Drug-eluting stent 3.0 x 18mm",
          result: "Excellent, 0% residual stenosis, TIMI 3 flow",
          complications: "None"
        },
        plan: "Staged PCI to RCA if symptomatic or positive stress test in 4-6 weeks. LCx lesion does not require intervention at this time."
      },
      {
        modality: "EKG",
        date: "2024-09-18 (ED)",
        findings: "Sinus rhythm, rate 88. Normal axis. ST depressions 1-2mm in leads V4-V6, I, aVL. No Q waves. QTc 445ms.",
        interpretation: "Anterolateral ST depressions consistent with acute ischemia. No prior EKG for comparison.",
        clinical_correlation: "Consistent with NSTEMI"
      },
      {
        modality: "EKG",
        date: "2024-10-09 (today's visit)",
        findings: "Sinus rhythm, rate 72. Normal axis. Q waves in V2-V4 (new, consistent with prior anteroseptal MI). No acute ST changes. QTc 430ms.",
        interpretation: "Evidence of prior anteroseptal MI (Q waves). No acute changes. Improved from admission EKG.",
        comparison: "Compared to 2024-09-18, ST depressions have resolved, new Q waves developed."
      }
    ],
    
    family_history: {
      father: {
        status: "Deceased age 65",
        cause: "Myocardial infarction",
        conditions: ["CAD", "Diabetes", "Hypertension"]
      },
      mother: {
        status: "Deceased age 88",
        cause: "Stroke",
        conditions: ["Hypertension", "Dementia"]
      },
      siblings: {
        sister_1: { status: "Living", age: 72, conditions: ["CAD s/p CABG age 68", "Diabetes", "CKD"] },
        brother_1: { status: "Deceased age 63", cause: "MI", conditions: ["CAD", "Diabetes"] }
      },
      children: {
        daughter: { age: 42, conditions: ["Prediabetes", "Obesity"] }
      },
      family_cv_risk: "Very strong family history of premature CAD and MI"
    },
    
    social_history: {
      marital_status: "Widowed (husband died 2019)",
      living_situation: "Lives alone in single-story house, owns home",
      support_system: {
        daughter: "Jennifer lives 15 minutes away, very involved, helping with medications and appointments",
        son: "Lives in Florida, calls weekly but not available for daily support",
        friends: "Active in church community"
      },
      
      occupation: "Retired elementary school teacher (retired 2018)",
      
      tobacco: {
        status: "Former smoker",
        pack_years: 15,
        quit_date: "1990 (34 years ago)",
        current: "None since 1990"
      },
      
      alcohol: { status: "None", history: "Occasional social drinking in past, none currently" },
      drugs: { status: "Never used" },
      
      functional_status: {
        pre_mi: "Independent with all ADLs and IADLs. Active, walking daily, gardening.",
        current: "Significantly reduced since MI. Fatigues easily. Daughter helping with shopping, heavy housework. Can still manage basic ADLs but slower. Afraid to be too active.",
        mobility: "Walking with caution, no assistive device but unsteady at times",
        driving: "Has not driven since MI, anxious about driving"
      },
      
      exercise: {
        pre_mi: "Walked 30 minutes daily, light gardening",
        current: "Minimal activity, afraid to exert herself. Cardiac rehab scheduled to start 10/14.",
        barriers: "Fear of another heart attack, fatigue, knee pain"
      },
      
      diet: {
        pre_mi: "Generally healthy, home-cooked meals",
        current: "Poor appetite since MI, eating less. Daughter bringing meals. Not following diabetic diet closely - too overwhelmed."
      },
      
      psychosocial: {
        mood: "Anxious and somewhat depressed since MI. Fears dying. Afraid to be alone.",
        sleep: "Poor - wakes frequently worrying about her heart",
        coping: "Previously strong and independent, now feels vulnerable and scared",
        support_needs: "Would benefit from counseling, cardiac rehabilitation for confidence building"
      },
      
      financial: {
        income: "Fixed income - teacher's pension and social security",
        insurance: "Medicare with supplement - good coverage",
        medication_costs: "Ticagrelor expensive ($85/month), daughter helping. Applied for manufacturer assistance.",
        home_situation: "Owns home outright, manageable expenses"
      },
      
      advance_directives: {
        healthcare_proxy: "Daughter (Jennifer Thompson)",
        living_will: "Completed after MI",
        code_status: "Full code currently",
        wishes: "Wants 'everything done' but doesn't want prolonged suffering"
      }
    },
    
    today_visit: {
      date: "2024-10-09",
      time: "10:00",
      days_since_mi: 21,
      days_since_discharge: 18,
      
      chief_complaint: "Follow-up after heart attack. Feeling very weak and tired. New swelling in my feet.",
      
      hpi: "68F with recent NSTEMI (9/18/24) treated with PCI to LAD, now with new diagnosis of heart failure (EF 40%), presents for post-discharge follow-up. Patient reports feeling 'exhausted all the time' since coming home from hospital. Can walk around house but gets short of breath going up the 3 stairs to her bedroom. Has noticed swelling in both feet for past 4-5 days, worse at end of day. Weight has increased 5 pounds since discharge (now 164, was 159 pre-MI). Denies chest pain or pressure since discharge. No palpitations. No orthopnea yet but using 2 pillows at night (was 1 pre-MI). No PND. Occasional mild nausea (attributes to all the new pills). Appetite poor - 'nothing tastes good.' Checking blood sugars twice daily as instructed - running 180-240 fasting, 200-280 at bedtime despite insulin. Taking all medications but admits she's 'overwhelmed' by the number of pills and the cost of ticagrelor. Daughter has been very helpful with pillbox setup. Not driving yet, anxious about it. Cardiac rehab scheduled to start next week but worried she's 'not strong enough.' Feeling tearful and anxious frequently. Afraid to be alone. Sleep poor - wakes up worried about her heart.",
      
      review_of_systems: {
        constitutional: "Significant fatigue and weakness. Poor appetite. No fever or chills. No weight loss (actually gaining).",
        cardiovascular: "No chest pain since discharge. Mild dyspnea on exertion (climbing stairs). Bilateral lower extremity edema. No palpitations. No syncope or presyncope.",
        respiratory: "Dyspnea as above. No cough. No wheezing. No hemoptysis.",
        gastrointestinal: "Mild nausea (med-related?). Poor appetite. No vomiting, diarrhea, or constipation. No abdominal pain.",
        genitourinary: "Increased urination on furosemide. No dysuria. No hematuria.",
        musculoskeletal: "Chronic knee pain, unchanged. General weakness. No new joint pains.",
        neurologic: "No headaches, dizziness, weakness, or numbness. No stroke symptoms.",
        psychiatric: "Anxious and tearful frequently. Sleep disturbance. Worried about dying. Some features of depression.",
        endocrine: "No polyuria or polydipsia beyond diuretic effect. Knows blood sugars are high.",
        hematologic: "No easy bruising or bleeding on dual antiplatelet therapy."
      },
      
      vitals: {
        bp: "132/78 (seated), 125/72 (standing - no orthostasis)",
        hr: 72,
        rr: 16,
        temp: 98.2,
        weight: 164,
        height: 63,
        bmi: 29.1,
        o2_sat: "97% on room air",
        weight_change: "+5 lbs since discharge, +5 lbs since pre-MI"
      },
      
      physical_exam: {
        general: "Appears fatigued. Mildly anxious affect. Able to speak in complete sentences without difficulty.",
        
        heent: "Normocephalic, atraumatic. Conjunctivae pink. Oropharynx moist.",
        
        neck: "Supple. JVP 8-9 cm (mildly elevated). No thyromegaly. Carotids 2+ bilaterally without bruits.",
        
        cardiovascular: {
          inspection: "No visible heave or thrill",
          palpation: "PMI displaced laterally to midclavicular line (suggests LV dilation)",
          auscultation: "Regular rate and rhythm. Normal S1. Physiologic S2 split. Soft S3 gallop present (HF). II/VI systolic murmur at apex radiating to axilla (MR). No rubs.",
          peripheral_pulses: "2+ radial, DP, PT bilaterally",
          extremities: "1+ pitting edema bilateral ankles extending to mid-calf. Warm, well-perfused. No cyanosis."
        },
        
        respiratory: "Clear to auscultation bilaterally in all fields. No wheezes, crackles, or rhonchi. Good air movement. No increased work of breathing.",
        
        abdomen: "Soft, non-tender, non-distended. Normal bowel sounds. No hepatosplenomegaly. Liver edge not palpable. No ascites.",
        
        neurologic: "Alert and oriented x3. CN II-XII intact. Motor 5/5 in all extremities. Sensation decreased to monofilament in feet bilaterally (diabetic neuropathy). Reflexes 2+ and symmetric. Gait not assessed today.",
        
        skin: "Warm, dry. No rashes or lesions. Surgical wound from radial access healed well.",
        
        psychiatric: "Anxious and tearful during interview. Makes eye contact. Thoughts organized. Denies SI/HI."
      },
      
      labs_reviewed: {
        date: "2024-10-07 (2 days ago, obtained as ordered at discharge)",
        
        bmp: {
          sodium: 136,
          potassium: 4.8,
          chloride: 102,
          co2: 24,
          bun: 42,
          creatinine: 1.9,
          glucose: 234,
          calcium: 9.4,
          interpretation: "Cr worsened from 1.4 pre-MI to 1.9 currently. eGFR down to 31 from 45. Likely multifactorial - contrast nephropathy, poor forward flow from HF, ACE-I effect. Potassium acceptable at 4.8 despite ACE-I and CKD. Glucose elevated."
        },
        
        cbc: {
          wbc: 7.8,
          hemoglobin: 11.2,
          hematocrit: 34.1,
          platelets: 245,
          interpretation: "Mild anemia - likely anemia of CKD. Hgb was 12.8 pre-MI. Will need to monitor."
        },
        
        lipid_panel: {
          total_cholesterol: 145,
          ldl: 68,
          hdl: 48,
          triglycerides: 145,
          interpretation: "LDL at goal <70 on high-intensity statin. Good response."
        },
        
        bnp: {
          value: 892,
          interpretation: "Elevated, consistent with heart failure. No baseline for comparison."
        },
        
        troponin: {
          value: 0.12,
          interpretation: "Mildly elevated but declining from peak of 8.4 during MI. Expected in post-MI period."
        },
        
        a1c: {
          value: 9.2,
          date: "2024-09-19 (during hospitalization)",
          interpretation: "Markedly elevated. Needs aggressive management."
        }
      },
      
      assessment_and_plan: [
        {
          problem: "Heart Failure with Reduced Ejection Fraction (HFrEF), EF 40%",
          assessment: "New diagnosis following NSTEMI. Patient showing clinical signs of volume overload - LE edema, weight gain 5 lbs, mild JVP elevation, S3 gallop. Currently on suboptimal GDMT dosing. Needs uptitration of ACE-I and beta blocker but limited by CKD (eGFR 31) and need to monitor renal function closely.",
          
          plan: [
            "Increase furosemide to 40mg daily (from 20mg) given volume overload",
            "Check daily weights - call if gain >2 lbs in day or 5 lbs in week",
            "Continue metoprolol succinate 50mg BID - target dose 200mg daily (will increase gradually)",
            "Continue lisinopril 10mg - want to increase but need to watch creatinine and potassium",
            "Will recheck BMP in 1 week after furosemide increase",
            "If Cr stable, will increase lisinopril to 20mg next week",
            "Sodium restriction <2000mg/day - reviewed with patient and daughter",
            "Fluid restriction 2L/day",
            "Patient enrolled in cardiac rehab starting 10/14 - this is critical for recovery",
            "Repeat echo in 3 months (December) to reassess EF and see if recovery",
            "If EF remains â‰¤35% after 40 days on optimal medical therapy, will need ICD evaluation per guidelines"
          ],
          
          patient_education: [
            "Explained HF is a chronic condition requiring lifelong management",
            "Daily weights are crucial - provided weight log",
            "Importance of low sodium diet reviewed - daughter will help",
            "Medication adherence critical - each medicine serves important purpose",
            "Cardiac rehab will help her feel stronger and less afraid",
            "Reassured that many people live well with HF with proper management"
          ]
        },
        {
          problem: "Coronary Artery Disease, status post NSTEMI with PCI to LAD",
          assessment: "21 days post-MI. No recurrent chest pain. On appropriate secondary prevention medications. Has residual disease in RCA (70%) and LCx (50%) that may need intervention. Cardiology follow-up next week with stress test.",
          
          plan: [
            "Continue dual antiplatelet therapy: aspirin 81mg + ticagrelor 90mg BID",
            "CRITICAL: Ticagrelor must continue for minimum 12 months - patient understands",
            "Applied for manufacturer assistance program for ticagrelor to help with cost",
            "Continue high-intensity statin (atorvastatin 80mg) - LDL at goal",
            "Cardiac rehab essential for recovery and preventing future events",
            "Follow-up with cardiology 10/15 - stress test to assess RCA lesion",
            "May need staged PCI to RCA if stress test positive"
          ],
          
          activity_restrictions: "Cardiac rehab will guide appropriate activity progression. For now: light activity, short walks, no heavy lifting >10 lbs until cleared by cardiology."
        },
        {
          problem: "Type 2 Diabetes - Poorly Controlled",
          assessment: "A1C 9.2, marked hyperglycemia. Currently on metformin (borderline inappropriate for eGFR 31) and insulin glargine 20 units which is insufficient. Home glucose readings 180-280. Needs insulin titration. Concerned about metformin with declining renal function.",
          
          plan: [
            "Hold metformin given eGFR 31 (contraindicated <30, caution 30-45)",
            "Increase insulin glargine to 26 units at bedtime (increase by 6 units)",
            "Taught patient to increase by 2 units every 3 days if fasting >130 until fasting sugars 100-130",
            "Continue home glucose monitoring BID (fasting and bedtime)",
            "Recheck A1C in 6 weeks",
            "Once cardiac status stable and renal function clarified, may consider GLP-1 agonist for additional benefit (CV and renal protection)",
            "Endocrinology follow-up in 4 weeks for insulin management"
          ],
          
          diabetes_education: "Reviewed insulin injection technique, storage, dosing schedule with patient and daughter. Both comfortable with insulin administration."
        },
        {
          problem: "Chronic Kidney Disease Stage 3b, Worsening",
          assessment: "eGFR declined from 45 pre-MI to 31 currently. Multifactorial: contrast-induced, poor cardiac output from HF, ACE-I effect, diabetic nephropathy progression. Concerning trajectory. Approaching Stage 4 CKD.",
          
          plan: [
            "Close monitoring - recheck BMP in 1 week after diuretic change",
            "Holding metformin given eGFR 31",
            "Continuing ACE-I for cardiac and renal protection but dose-limited",
            "Monitoring potassium closely - was 4.8",
            "Avoiding nephrotoxins - no NSAIDs, no contrast unless essential",
            "If eGFR continues to decline or drops <30, will need nephrology referral",
            "Checking urine protein (UACR) today to assess degree of nephropathy"
          ]
        },
        {
          problem: "Hypertension",
          assessment: "BP 132/78 today - acceptable given recent MI and HF. On ACE-I and beta blocker. Limited ability to uptitrate due to kidney function.",
          plan: "Continue current regimen. Target <130/80. Will reassess as able to titrate HF medications."
        },
        {
          problem: "Anemia - New",
          assessment: "Hgb 11.2, down from 12.8 pre-MI. Likely anemia of chronic kidney disease given eGFR 31. Mild and asymptomatic currently but may contribute to fatigue.",
          plan: [
            "Check iron studies, B12, folate today",
            "If iron deficient, replace carefully (IV preferred over oral with CKD)",
            "Monitor Hgb - if drops below 10, may need EPO per nephrology",
            "Ensure adequate nutrition"
          ]
        },
        {
          problem: "Anxiety and Depression - Likely Post-MI Adjustment Disorder",
          assessment: "Significant anxiety about her health, fear of dying, fear of being alone, tearfulness, sleep disturbance, poor appetite. Classic adjustment disorder following major cardiac event. Also elements of depression.",
          
          plan: [
            "Screening: PHQ-9 today = 12 (moderate depression), GAD-7 = 15 (moderate anxiety)",
            "Cardiac rehab provides structured support and will help build confidence",
            "Referral to social work/counseling for supportive therapy",
            "Consider SSRI if symptoms persist after cardiac rehab starts",
            "Safety: Denies SI/HI, has good support from daughter",
            "Daughter aware and will monitor closely",
            "Follow-up in 2 weeks to reassess mood"
          ],
          
          counseling: "Validated her fears and anxiety as normal following MI. Reassured her that many patients feel this way initially and it improves with time, support, and cardiac rehab. Encouraged her to reach out to friends and church community. Daughter will help ensure she's not alone too much."
        },
        {
          problem: "Hypothyroidism",
          assessment: "Well-controlled on current dose of levothyroxine.",
          plan: "Continue levothyroxine 100mcg daily. Recheck TSH in 3 months with other labs."
        },
        {
          problem: "Osteoarthritis",
          assessment: "Chronic knee and hand pain. Limiting exercise ability. Cannot use NSAIDs due to CKD and dual antiplatelet therapy.",
          plan: "Continue acetaminophen PRN, max 3000mg/day given liver is fine. Cardiac rehab may help with strengthening and reducing load on knees."
        }
      ],
      
      orders_placed: [
        { type: "Labs - 1 week", tests: "BMP (check Cr, K+ after diuretic increase)" },
        { type: "Labs - Today", tests: "Iron studies, B12, folate, UACR" },
        { type: "Labs - 6 weeks", tests: "A1C, BMP, CBC, lipid panel, BNP, TSH" },
        { type: "Prescription - NEW", med: "Furosemide 40mg daily", qty: 90, refills: 3 },
        { type: "Prescription - CHANGE", med: "Insulin glargine - increase to 26 units at bedtime", note: "Patient to titrate up by 2 units every 3 days if fasting >130" },
        { type: "Prescription - HOLD", med: "Metformin - discontinued given eGFR 31" },
        { type: "DME", item: "Digital scale for daily weights" },
        { type: "Referral", to: "Social Work/Counseling", reason: "Post-MI adjustment, anxiety, depression" },
        { type: "Referral", to: "Endocrinology", appointment: "4 weeks", reason: "Insulin management, diabetes optimization" },
        { type: "Follow-up", when: "1 week", reason: "Check BMP after medication changes" },
        { type: "Follow-up", when: "2 weeks", reason: "Reassess volume status, mood, overall adjustment" },
        { type: "Imaging", test: "Repeat echocardiogram", when: "3 months (December)", reason: "Reassess LVEF and cardiac function" }
      ],
      
      prescriptions_modified: [
        { med: "Furosemide", new_dose: "40mg daily", old_dose: "20mg daily", reason: "Volume overload" },
        { med: "Insulin glargine", new_dose: "26 units at bedtime with titration instructions", old_dose: "20 units", reason: "Poor glucose control" },
        { med: "Metformin", status: "DISCONTINUED", reason: "eGFR 31 - contraindicated/high risk" }
      ],
      
      patient_instructions: [
        "Weigh yourself every morning after going to bathroom, before breakfast, with same scale, same clothing",
        "Call immediately if weight increases >2 lbs in one day or >5 lbs in one week",
        "Low sodium diet <2000mg per day - avoid adding salt, processed foods, canned soups",
        "Limit fluids to 8 cups (64oz) per day total",
        "Take all medications as prescribed - each one is important for your heart",
        "Check blood sugar twice daily - fasting and bedtime",
        "Increase insulin by 2 units every 3 days if fasting sugar >130 (explained in detail)",
        "Cardiac rehab starts Tuesday 10/14 at 9am - daughter will drive",
        "Call 911 if: chest pain, severe shortness of breath, passing out, one-sided weakness",
        "Activity: short walks OK, no heavy lifting, no driving until cleared by cardiology",
        "Return to office in 1 week for lab check",
        "Cardiology appointment 10/15 at 2pm - do not miss"
      ],
      
      time_spent: {
        face_to_face: "50 minutes",
        counseling: "35 minutes (>50% of visit)",
        complexity: "High - post-MI, new HF, multiple medication changes, extensive counseling on multiple issues, coordination of multiple specialists"
      },
      
      billing: {
        cpt: "99215",
        icd10: [
          "I21.4 (NSTEMI)",
          "I50.22 (Chronic systolic HF)",
          "I25.10 (CAD)",
          "E11.65 (DM with hyperglycemia, uncontrolled)",
          "N18.3b (CKD stage 3b)",
          "I10 (HTN)",
          "E78.5 (Hyperlipidemia)",
          "D63.1 (Anemia of CKD)",
          "F43.23 (Adjustment disorder with anxiety)"
        ],
        justification: "High complexity visit - post-MI with new heart failure, multiple medication adjustments, worsening renal function, uncontrolled diabetes, significant psychosocial issues, extensive counseling and coordination of care with cardiology and endocrinology"
      }
    },
    
    key_clinical_issues: [
      "Recent NSTEMI with PCI - high risk period, needs close monitoring",
      "New systolic heart failure (EF 40%) - volume overloaded, suboptimal GDMT dosing",
      "Worsening CKD (eGFR 31) - limits medication options, needs close monitoring",
      "Uncontrolled diabetes (A1C 9.2) - insulin needs titration, metformin discontinued",
      "Significant anxiety/depression post-MI - needs support and counseling",
      "Lives alone with limited support - safety concern",
      "Polypharmacy with new expensive medication (ticagrelor) - adherence risk",
      "Cardiac rehab starting next week - critical for recovery"
    ],
    
    red_flags: [
      "Any chest pain - could be recurrent ischemia from residual CAD",
      "Worsening dyspnea or edema - worsening HF",
      "Weight gain >2-5 lbs - volume overload",
      "Creatinine continues to rise - may need to stop ACE-I or refer nephrology",
      "Potassium >5.5 - hyperkalemia risk with ACE-I and CKD",
      "Severe hypoglycemia on insulin - needs dose adjustment",
      "Worsening depression/anxiety - suicide risk assessment needed",
      "Bleeding on dual antiplatelet therapy - serious concern"
    ],
    
    care_coordination: {
      cardiology: "Following for stress test, possible staged PCI, HF management. Next visit 10/15.",
      endocrinology: "Will see in 4 weeks for insulin optimization.",
      cardiac_rehab: "Starts 10/14 - critical for physical and psychological recovery.",
      social_work: "Referral placed for counseling support.",
      pharmacy: "Working on manufacturer assistance for ticagrelor.",
      home_health: "May need if functional status doesn't improve.",
      daughter: "Primary support - well-engaged, attending appointments, helping with medications."
    }
  },

  // ==========================================================================
  // PATIENT 6: THOMAS BRADLEY (Very High Complexity)
  // 72M - COPD exacerbation with cor pulmonale, CHF, diabetes, recent sepsis
  // ==========================================================================
  
  "P006": {
    slot_time: "10:30",
    complexity: "very-high",
    patient_id: "P006",
    mrn: "MRN-2014-09376",
    
    demographics: {
      name: { first: "Thomas", middle: "Edward", last: "Bradley", preferred: "Tom" },
      dob: "1952-08-17",
      age: 72,
      sex: "M",
      race: "White",
      ethnicity: "Non-Hispanic"
    },
    
    contact: {
      phone: "478-555-6288",
      address: "1847 Pine Street, Macon, GA 31201",
      lives_with: "Wife (Patricia, age 69)",
      emergency_contact: {
        name: "Patricia Bradley (wife)",
        phone: "478-555-6289"
      }
    },
    
    insurance: {
      primary: "Medicare Part B",
      secondary: "Aetna Medicare Supplement",
      part_d: "Humana",
      oxygen_coverage: "Covered by Medicare with prescription"
    },
    
    visit_reason: "Post-hospitalization follow-up - COPD exacerbation and sepsis",
    chief_complaint: "Discharged from hospital 1 week ago, still very short of breath, on oxygen now",
    
    clinical_summary: {
      complexity_factors: [
        "Severe COPD GOLD 4 (very severe) with frequent exacerbations",
        "Cor pulmonale (right heart failure from lung disease)",
        "Recent hospitalization for COPD exacerbation complicated by sepsis",
        "New home oxygen requirement",
        "Type 2 diabetes uncontrolled",
        "Chronic systolic heart failure (biventricular)",
        "Chronic kidney disease stage 3b",
        "Active smoker despite severe lung disease",
        "Multiple prior ICU admissions",
        "High risk for readmission",
        "Palliative care discussions needed"
      ],
      
      recent_hospitalization: {
        admission_date: "2024-09-25",
        discharge_date: "2024-10-02",
        length_of_stay: "7 days (2 days ICU)",
        hospital: "Medical Center of Central Georgia",
        attending: "Dr. Patricia Williams (Hospitalist)",
        
        admission_diagnosis: "COPD exacerbation, sepsis",
        
        presentation: "72M with severe COPD (GOLD 4) presented to ED with 4-day history of worsening dyspnea, increased cough with green sputum, fever to 101.8F. Wife called EMS when patient became confused and lethargic. In ED: Tachypneic (RR 32), tachycardic (HR 118), hypoxemic (O2 sat 82% on RA â†’ 90% on 15L non-rebreather), hypotensive (BP 88/54). Labs showed WBC 18.2, procalcitonin 4.8, lactate 3.2, Cr 2.4 (baseline 1.6). CXR showed right lower lobe infiltrate.",
        
        hospital_course_summary: [
          "ICU Day 1-2: Septic shock from pneumonia. Required vasopressors (norepinephrine), IV antibiotics (ceftriaxone + azithromycin), aggressive IV fluids. Developed acute respiratory failure requiring BiPAP. Blood cultures positive for Streptococcus pneumoniae. Cr peaked at 2.8 (AKI on CKD). Managed conservatively - no intubation per patient wishes. Improved with treatment.",
          
          "Floor Day 3-5: Weaned off vasopressors. Transitioned from BiPAP to high-flow oxygen. Treated with IV methylprednisolone, nebulizers, antibiotics. Diuresed carefully for volume overload from aggressive fluid resuscitation (developed worsening bilateral edema, elevated JVP). Required IV furosemide. Cr improved to 1.9.",
          
          "Day 6-7: Continued to improve but remained hypoxemic. Multiple attempts to wean oxygen unsuccessful - desats to 80s without O2. Pulmonology consulted - new baseline O2 requirement. Discharged on home oxygen 3L continuous. Antibiotics completed in hospital. Home health arranged."
        ],
        
        complications: [
          "Septic shock requiring ICU and vasopressors",
          "Acute respiratory failure managed with BiPAP",
          "Acute kidney injury on CKD (Cr 2.8, improved to 1.9)",
          "Volume overload requiring IV diuresis",
          "New home oxygen requirement",
          "Deconditioning - significantly weaker"
        ],
        
        discharge_summary_excerpts: {
          diagnoses: [
            "Acute COPD exacerbation - severe",
            "Community-acquired pneumonia (CAP) with sepsis",
            "Septic shock",
            "Acute respiratory failure",
            "Cor pulmonale with decompensation",
            "Acute kidney injury on CKD stage 3",
            "Type 2 Diabetes Mellitus",
            "Chronic systolic heart failure"
          ],
          
          discharge_condition: "Improved but still requiring supplemental oxygen. Weak and deconditioned. Hypoxemic at baseline. High risk for readmission.",
          
          discharge_medications: [
            "Oxygen 3L continuous via nasal cannula",
            "Tiotropium 18mcg inhaled daily",
            "Fluticasone/salmeterol 250/50 2 puffs BID",
            "Albuterol 2 puffs q4h PRN",
            "Prednisone taper: 40mg x3 days, 30mg x3 days, 20mg x3 days, 10mg x3 days, then stop",
            "Furosemide 40mg daily (increased from 20mg)",
            "Metoprolol tartrate 25mg BID",
            "Lisinopril 10mg daily",
            "Metformin 500mg BID",
            "Atorvastatin 40mg daily",
            "Aspirin 81mg daily"
          ],
          
          follow_up_instructions: [
            "PCP within 1 week",
            "Pulmonology within 2 weeks",
            "Home health for oxygen management and assessment",
            "Smoking cessation critical - patient counseled multiple times",
            "Advance care planning discussion recommended"
          ]
        }
      },
      
      active_problems: [
        {
          problem: "Chronic Obstructive Pulmonary Disease (COPD) - GOLD 4 (Very Severe)",
          onset: "Diagnosed 2008",
          severity: "GOLD 4 (very severe obstruction)",
          phenotype: "Chronic bronchitis with frequent exacerbations",
          last_pfts: {
            date: "2023-06-15",
            fev1: "32% predicted (severely reduced)",
            fvc: "58% predicted",
            fev1_fvc_ratio: "0.48 (severely obstructed)",
            dlco: "38% predicted (severe impairment)",
            interpretation: "Severe obstructive lung disease with severe diffusion impairment"
          },
          exacerbation_history: {
            last_12_months: 4,
            hospitalizations_last_year: 3,
            icu_admissions_ever: 5,
            last_exacerbation: "Current hospitalization 9/25-10/02/24"
          },
          current_symptoms: {
            dyspnea: "At rest and with minimal activity (mMRC dyspnea scale 4 - cannot leave house due to dyspnea)",
            cough: "Chronic productive cough, worse in mornings, thick white/yellow sputum daily",
            wheezing: "Intermittent",
            chest_tightness: "Frequent",
            exercise_tolerance: "Can walk <50 feet on oxygen before stopping due to dyspnea",
            functional_status: "Severely limited, mostly bedbound or chair-bound"
          },
          smoking_history: {
            status: "Current smoker",
            pack_years: 75,
            started_age: 15,
            current_use: "5-7 cigarettes per day despite severe COPD",
            quit_attempts: "Multiple, none successful for >3 months",
            cessation_counseling: "Provided at every visit, resistant"
          },
          oxygen_therapy: {
            status: "NEW - started during recent hospitalization",
            prescription: "3L continuous via nasal cannula",
            o2_sat_on_room_air: "82-85%",
            o2_sat_on_3l: "90-92%",
            supplier: "Apria Home Healthcare",
            portable_concentrator: "Ordered, not yet delivered",
            compliance: "Patient reports wearing 'most of the time' but wife says he takes it off to smoke"
          },
          medications: [
            "Tiotropium 18mcg inhaled daily (long-acting anticholinergic)",
            "Fluticasone/salmeterol 250/50 2 puffs BID (ICS/LABA)",
            "Albuterol 2 puffs q4h PRN (rescue)",
            "Prednisone taper (current) - finishing steroid course from hospitalization",
            "Roflumilast 500mcg daily (PDE4 inhibitor for frequent exacerbators)"
          ]
        },
        {
          problem: "Cor Pulmonale (Right Heart Failure secondary to COPD)",
          onset: "2020",
          pathophysiology: "Pulmonary hypertension from chronic hypoxemia and COPD â†’ RV failure",
          echo_findings: {
            date: "2024-09-26 (during hospitalization)",
            rv_size: "Moderately dilated",
            rv_function: "Moderately to severely reduced",
            tricuspid_regurgitation: "Moderate to severe",
            estimated_rvsp: "58 mmHg (severe pulmonary hypertension)",
            ra_size: "Severely dilated",
            lv_size_function: "Mildly reduced LVEF 45%, mild LV dilation",
            note: "Biventricular dysfunction - both right and left heart failure"
          },
          current_symptoms: [
            "Severe bilateral lower extremity edema (3+ pitting to thighs)",
            "Ascites (new)",
            "Jugular venous distension",
            "Hepatomegaly",
            "Fatigue and weakness"
          ],
          medications: "Furosemide 40mg daily, oxygen therapy"
        },
        {
          problem: "Chronic Systolic Heart Failure (Biventricular)",
          onset: "2019",
          ejection_fraction: "45% (mildly reduced, was 50% last year)",
          etiology: "Ischemic (prior MI 2017) + cor pulmonale",
          nyha_class: "IV (symptoms at rest)",
          current_symptoms: "As above - combined RV and LV failure causing severe edema, dyspnea, fatigue",
          medications: "Metoprolol, lisinopril, furosemide, aspirin, statin"
        },
        {
          problem: "Type 2 Diabetes Mellitus",
          onset: "2012",
          status: "Poorly controlled",
          last_a1c: { value: 9.8, date: "2024-09-26" },
          complications: [
            "Diabetic neuropathy (feet and hands)",
            "Diabetic nephropathy (CKD)",
            "No retinopathy documented (hasn't seen eye doctor in 2 years)"
          ],
          home_monitoring: "Rarely checks blood sugars",
          medications: "Metformin 500mg BID (suboptimal dosing)"
        },
        {
          problem: "Chronic Kidney Disease Stage 3b",
          onset: "2018",
          etiology: "Diabetic nephropathy, hypertensive nephrosclerosis, recurrent AKI from heart failure",
          last_labs: {
            date: "2024-10-02 (at discharge)",
            creatinine: 1.9,
            egfr: 36,
            note: "Improved from AKI peak of 2.8, but worse than baseline 1.6"
          },
          baseline_pre_hospitalization: "Cr 1.6, eGFR 42"
        },
        {
          problem: "Coronary Artery Disease, status post MI",
          onset: "MI in 2017",
          history: "STEMI 2017, treated medically (no PCI - patient refused), medical management ongoing",
          current_status: "No angina currently, on aspirin and statin"
        },
        {
          problem: "Hypertension",
          status: "Difficult to assess given heart failure and multiple admissions",
          medications: "Metoprolol, lisinopril"
        },
        {
          problem: "Peripheral Vascular Disease",
          manifestations: "Decreased pedal pulses, history of intermittent claudication",
          not_candidate_for_intervention: "Too high risk given multiple comorbidities"
        },
        {
          problem: "Tobacco Use Disorder",
          status: "Active smoker despite severe COPD and multiple hospitalizations",
          barriers: "Severe nicotine addiction, depression, lack of motivation, doesn't believe quitting will help 'at this point'",
          interventions_tried: "Nicotine replacement, varenicline (didn't tolerate), bupropion (didn't help), counseling (resistant)"
        },
        {
          problem: "Depression",
          status: "Likely present but never formally treated",
          symptoms: "Low mood, anhedonia, hopelessness, passive death wishes ('wouldn't mind if I didn't wake up')",
          note: "Contributing to tobacco use and poor self-care"
        }
      ],
      
      past_surgical_history: [
        { year: 2017, procedure: "None - refused cardiac catheterization during MI" },
        { year: 2015, procedure: "Hernia repair (inguinal)" },
        { year: 1998, procedure: "Appendectomy" }
      ],
      
      current_medications: [
        { name: "Oxygen", dose: "3L continuous", route: "Nasal cannula", indication: "Severe hypoxemia from COPD", critical: true },
        { name: "Tiotropium (Spiriva)", dose: "18mcg", frequency: "once daily", route: "Inhaled", indication: "COPD maintenance" },
        { name: "Fluticasone/Salmeterol (Advair)", dose: "250/50mcg", frequency: "2 puffs twice daily", route: "Inhaled", indication: "COPD maintenance" },
        { name: "Albuterol", dose: "2 puffs", frequency: "every 4 hours as needed", route: "Inhaled", indication: "COPD rescue" },
        { name: "Roflumilast (Daliresp)", dose: "500mcg", frequency: "once daily", route: "Oral", indication: "Reduce COPD exacerbations" },
        { name: "Prednisone", dose: "Taper", frequency: "Currently 20mg daily x 3 days, then 10mg x 3 days, then stop", indication: "COPD exacerbation recovery" },
        { name: "Furosemide", dose: "40mg", frequency: "once daily", route: "Oral", indication: "Heart failure, cor pulmonale", note: "Increased from 20mg" },
        { name: "Metoprolol tartrate", dose: "25mg", frequency: "twice daily", route: "Oral", indication: "Heart failure, HTN, CAD" },
        { name: "Lisinopril", dose: "10mg", frequency: "once daily", route: "Oral", indication: "Heart failure, HTN, CKD protection" },
        { name: "Metformin", dose: "500mg", frequency: "twice daily", route: "Oral", indication: "Type 2 Diabetes" },
        { name: "Atorvastatin", dose: "40mg", frequency: "once daily", route: "Oral", indication: "CAD, hyperlipidemia" },
        { name: "Aspirin", dose: "81mg", frequency: "once daily", route: "Oral", indication: "CAD" }
      ],
      
      allergies: [
        { allergen: "No known drug allergies" }
      ]
    },
    
    family_history: {
      father: {
        status: "Deceased age 68",
        cause: "COPD, respiratory failure",
        smoking: "Heavy smoker"
      },
      mother: {
        status: "Deceased age 74",
        cause: "Stroke",
        conditions: ["Hypertension", "Diabetes"]
      },
      siblings: {
        brother: { status: "Deceased age 65", cause: "Lung cancer", smoking: "Heavy smoker" }
      },
      family_smoking: "Extensive family history of smoking-related disease"
    },
    
    social_history: {
      marital_status: "Married 48 years",
      spouse: "Patricia Bradley, age 69, has COPD herself (GOLD 2, also smoker)",
      living_situation: "Small house, difficult to navigate with oxygen tubing, stairs to bedroom",
      
      children: {
        son: { age: 46, location: "Lives in Florida", contact: "Minimal" },
        daughter: { age: 43, location: "Lives in Macon", involvement: "Helps occasionally but works full-time, has young children" }
      },
      
      support_system: "Limited. Wife is primary caregiver but has her own health issues. Daughter helps when she can. Patient and wife both resistant to outside help.",
      
      occupation: "Retired construction worker (retired on disability 2015 due to COPD)",
      
      tobacco: {
        status: "CURRENT SMOKER",
        pack_years: 75,
        started: "Age 15",
        current: "5-7 cigarettes per day despite severe COPD, multiple hospitalizations, and home oxygen",
        quit_attempts: "Countless, none sustained >3 months",
        longest_quit: "4 months in 2019 after ICU admission",
        barriers: [
          "Severe nicotine addiction",
          "Depression",
          "Belief that 'damage is done, too late to quit'",
          "Lives with another smoker (wife)",
          "Smoking one of few remaining pleasures",
          "Takes oxygen off to smoke outside"
        ],
        safety: "Fire risk with oxygen - repeatedly counseled, resistant to advice"
      },
      
      alcohol: { status: "Denies", history: "Heavy drinking in past, quit 20 years ago" },
      drugs: { status: "Denies" },
      
      functional_status: {
        adls: "Requires assistance with bathing (too weak and short of breath). Needs help dressing. Can feed self if food prepared. Incontinent at times (can't get to bathroom fast enough with oxygen).",
        iadls: "Wife manages all household tasks, medications, appointments, finances.",
        mobility: "Wheelchair-bound for distances >50 feet. Can walk in house with oxygen but very slowly, maximum 20-30 feet before stopping to rest. High fall risk - fell twice in past month.",
        equipment: "Portable oxygen concentrator (on order), wheelchair, bedside commode, walker"
      },
      
      living_conditions: {
        home_environment: "Cluttered, makes oxygen tubing navigation difficult. Stairs to bedroom - patient now sleeping in recliner in living room. Poor ventilation. Both patients smoke inside occasionally despite oxygen.",
        safety_concerns: [
          "Fire risk with oxygen and smoking",
          "Fall risk",
          "Unable to evacuate quickly in emergency",
          "Clutter and oxygen tubing - tripping hazard",
          "Lives 30 minutes from hospital",
          "Limited ability to call for help if wife incapacitated"
        ]
      },
      
      financial: {
        income: "Disability, social security - fixed income, limited",
        insurance: "Medicare with supplement - good coverage for medical",
        challenges: "Oxygen supplies, medications, home modifications needed but can't afford"
      },
      
      advance_directives: {
        code_status: "DNR/DNI - completed during recent hospitalization after discussions",
        healthcare_proxy: "Wife (Patricia)",
        wishes: "Does not want intubation or 'machines keeping me alive.' Wants comfort measures. Not interested in hospice yet.",
        note: "Had frank discussion during hospitalization about disease trajectory and prognosis"
      },
      
      psychosocial: {
        mood: "Depressed - low mood, hopelessness, passive death wishes",
        coping: "Poor - continued smoking despite knowing consequences",
        social_isolation: "Severe - rarely leaves house, few visitors",
        relationship: "Wife is only consistent support but relationship strained by illness",
        spiritual: "Was religious, no longer attends church due to mobility/oxygen"
      }
    },
    
    today_visit: {
      date: "2024-10-09",
      time: "10:30",
      days_since_discharge: 7,
      
      chief_complaint: "I'm still so short of breath. Can't hardly do anything. And my legs are really swollen again.",
      
      hpi: "72M with severe COPD (GOLD 4), cor pulmonale, biventricular heart failure, presents 7 days post-discharge following hospitalization for COPD exacerbation and sepsis. Patient reports he is 'not much better' than when discharged. Still requires oxygen 3L continuously - desaturates to low 80s without it. Has tried walking short distances in house but becomes severely dyspneic after 10-20 feet. Cough persistent, productive of thick yellow-white sputum (baseline for him). No fever. Lower extremity edema has worsened significantly since discharge - now up to thighs bilaterally, 'can barely get pants on.' Describes new abdominal swelling. Weight gain of 8 pounds since discharge (now 182, was 174 at discharge, 168 before hospitalization). Reports urinating less despite being on furosemide - 'only going 2-3 times a day and not much each time.' Admits he has not been taking furosemide every day - 'I forget' and wife also admits she can't keep track of all the medications. Home health visited twice - checked vitals, O2 equipment working properly. Still smoking 5-7 cigarettes daily - 'I know I shouldn't but it's one of the only things I enjoy.' Takes oxygen off to smoke outside. Wife reports he wears oxygen 'most of the time' but not consistently. Not checking blood sugars. Appetite poor. Very weak and fatigued. Mood low - states 'I don't know how much longer I can keep doing this.' Denies acute chest pain. No hemoptysis.",
      
      review_of_systems: {
        constitutional: "Severe fatigue, weakness, poor appetite. No fever or chills currently. Weight gain 8 lbs.",
        cardiovascular: "No chest pain. Severe dyspnea. Massive bilateral LE edema. Orthopnea - sleeps in recliner, cannot lie flat. PND - wakes gasping for air multiple times nightly.",
        respiratory: "Severe dyspnea at rest and with any activity. Chronic productive cough with yellow-white sputum (baseline). Wheezing. Chest tightness. No hemoptysis. O2 sat drops to low 80s off oxygen.",
        gastrointestinal: "Poor appetite. Abdominal distension (new). No nausea, vomiting, or diarrhea. Constipation (baseline).",
        genitourinary: "Decreased urinary output despite diuretic. Nocturia 4-5x. No dysuria.",
        neurologic: "No confusion (was confused during sepsis, now back to baseline). No focal weakness. Peripheral neuropathy in feet (baseline).",
        musculoskeletal: "Severe generalized weakness. Legs so swollen they are painful. Can barely ambulate.",
        psychiatric: "Depressed mood. Hopelessness. Passive death wishes. Denies active SI. Not interested in life. 'Wouldn't mind if I didn't wake up.'",
        hematologic: "No bleeding or easy bruising."
      },
      
      vitals: {
        bp: "118/72",
        hr: 92,
        rr: 24,
        temp: 98.0,
        weight: 182,
        o2_sat: "91% on 3L O2 via NC (desats to 82% on RA after 30 seconds)",
        weight_change: "+8 lbs since discharge (174 â†’ 182), +14 lbs since pre-hospitalization (168)"
      },
      
      physical_exam: {
        general: "Elderly male appearing older than stated age, chronically ill-appearing, in mild respiratory distress at rest even on oxygen, speaking in short phrases between breaths",
        
        heent: "Normocephalic, atraumatic. Conjunctivae pale (anemia). Pursed-lip breathing noted. Oropharynx dry.",
        
        neck: "JVP markedly elevated to angle of jaw (>15 cm). No thyromegaly. Carotids diminished.",
        
        cardiovascular: {
          inspection: "Visible heave over left parasternal area (RV hypertrophy)",
          palpation: "Prominent RV heave palpable. PMI not palpable due to hyperinflated lungs.",
          auscultation: "Distant heart sounds due to hyperinflation. Regular rhythm. Loud P2 (pulmonary hypertension). III/VI systolic murmur at left lower sternal border increasing with inspiration (tricuspid regurgitation). No S3 or S4 appreciated.",
          peripheral_pulses: "Diminished throughout - radials 1+, femorals 1+, DPs barely palpable, PTs not palpable",
          extremities: "MASSIVE 3-4+ pitting edema bilaterally from feet to mid-thighs. Skin taut, shiny. Weeping edema present. Cool to touch distally. Venous stasis changes."
        },
        
        respiratory: {
          inspection: "Increased AP diameter (barrel chest). Use of accessory muscles. Paradoxical abdominal breathing.",
          palpation: "Decreased tactile fremitus",
          percussion: "Hyperresonant throughout",
          auscultation: "Severely decreased breath sounds throughout all lung fields. Diffuse expiratory wheezes bilaterally. Prolonged expiratory phase. No crackles. Distant breath sounds."
        },
        
        abdomen: "Distended with apparent ascites (new). Positive fluid wave. Liver edge palpable 4 cm below costal margin (hepatomegaly from RV failure). Non-tender. Bowel sounds hypoactive.",
        
        extremities: "As above - massive edema. Chronic venous stasis changes. No acute DVT signs but impossible to fully assess. Nails dystrophic.",
        
        neurologic: "Alert and oriented x3 (improved from hospitalization). Affect flat, depressed. CN II-XII intact. Strength difficult to assess due to deconditioning - appears 4/5 globally. Sensation decreased in feet to light touch (neuropathy).",
        
        skin: "Cool peripherally. Pallor. Chronic skin changes from smoking. No acute rashes."
      },
      
      labs_reviewed: {
        date: "2024-10-02 (at hospital discharge - no new labs today but will order)",
        
        note: "Reviewing discharge labs since no recent labs. Will recheck today given worsening HF.",
        
        bmp: {
          sodium: 131,
          potassium: 4.5,
          chloride: 96,
          co2: 32,
          bun: 52,
          creatinine: 1.9,
          glucose: 210,
          interpretation: "Hyponatremia (volume overload), elevated CO2 (chronic respiratory acidosis, COPD), elevated BUN/Cr ratio (prerenal azotemia from poor forward flow), hyperglycemia"
        },
        
        cbc: {
          wbc: 9.2,
          hemoglobin: 10.8,
          hematocrit: 33.2,
          platelets: 245,
          interpretation: "Anemia - chronic disease + CKD. Borderline macrocytic. WBC normalized from 18 during sepsis."
        },
        
        bnp: {
          value: 1842,
          interpretation: "Markedly elevated - severe heart failure (both RV and LV)"
        },
        
        a1c: {
          value: 9.8,
          date: "2024-09-26",
          interpretation: "Very poor diabetes control"
        }
      },
      
      assessment_and_plan: [
        {
          problem: "Acute on Chronic Decompensated Biventricular Heart Failure",
          assessment: "Patient is in severe decompensated heart failure - both right and left sides. Volume overloaded with massive anasarca (3-4+ edema to thighs), ascites, elevated JVP, weight gain 14 lbs from baseline, decreased urine output despite diuretic. BNP 1842. Contributing factors: (1) COPD driving cor pulmonale and RV failure, (2) poor medication adherence - not taking furosemide daily, (3) continued hypoxemia and chronic lung disease, (4) ischemic cardiomyopathy (prior MI). This is life-threatening volume overload. Patient needs aggressive diuresis but has kidney disease limiting options. Oral diuretics not working.",
          
          immediate_plan: [
            "Patient needs HOSPITALIZATION for IV diuresis",
            "This level of volume overload cannot be managed outpatient",
            "Called hospitalist - patient accepted for direct admission today",
            "Will need IV furosemide drip, likely 10-20mg/hour",
            "Goal net negative 2-3L daily until euvolemic",
            "Monitor renal function, electrolytes closely",
            "May need addition of metolazone if diuretic-resistant",
            "Consider paracentesis if ascites causing significant respiratory compromise"
          ],
          
          discussion_with_patient: [
            "Explained severity of fluid overload and need for hospitalization",
            "Patient initially resistant - 'I just got out of the hospital'",
            "Explained that without aggressive treatment, his lungs will fill with fluid and he could die",
            "Reviewed DNR/DNI status - still wants comfort but agrees to hospitalization for symptom management",
            "Wife supportive of plan",
            "Patient agrees to admission"
          ]
        },
        {
          problem: "Severe COPD GOLD 4 - Recent Exacerbation, Recovering",
          assessment: "Status post hospitalization for severe COPD exacerbation and pneumonia/sepsis. Still recovering. Completing steroid taper. On home oxygen 3L continuously but compliance poor - takes off to smoke. Baseline severe disease - FEV1 32%, mMRC dyspnea score 4. Active smoker despite everything. Fire risk with oxygen and smoking. Poor prognosis.",
          
          plan: [
            "Continue current COPD regimen during hospitalization",
            "Continue oxygen - may need to increase if worsens with diuresis (sometimes happens)",
            "Complete prednisone taper as scheduled (3 more days of 10mg then stop)",
            "Continue tiotropium, Advair, albuterol, roflumilast",
            "Pulmonology to see inpatient if needed",
            "SMOKING CESSATION CRITICAL - repeated counseling, patient resistant",
            "Fire risk with O2 and smoking - serious safety issue - EMS will not respond if fire occurs",
            "Consider palliative care consult for goals of care discussion"
          ]
        },
        {
          problem: "Cor Pulmonale (Right Heart Failure from Pulmonary Hypertension)",
          assessment: "Severe RV failure driving much of his volume overload. RVSP 58 mmHg, RV severely dilated and dysfunctional. Oxygen therapy is only treatment for pulmonary hypertension in COPD - but patient not compliant. Continued smoking worsens pulmonary HTN.",
          
          plan: [
            "Oxygen compliance critical - not negotiable",
            "Diuresis will help but RV failure will persist as long as COPD and pulmonary HTN present",
            "No pulmonary vasodilators indicated (not beneficial in COPD-related PH)",
            "Smoking cessation would help - patient resistant"
          ]
        },
        {
          problem: "Type 2 Diabetes - Very Poorly Controlled",
          assessment: "A1C 9.8, blood sugars >200s. Not checking sugars at home. On suboptimal metformin dose. Metformin borderline inappropriate for eGFR 36. Neuropathy present. Hasn't seen eye doctor in 2 years. High risk for complications.",
          
          plan: [
            "Hold metformin during hospitalization given AKI risk with diuresis and eGFR 36",
            "Will need insulin in hospital - patient historically resistant but may accept given severity of illness",
            "Endocrine consult if available inpatient",
            "Once acute issues resolved, needs diabetes optimization - likely insulin + possibly GLP-1 if kidneys allow",
            "Diabetic eye exam URGENT - schedule upon discharge",
            "Check A1C during hospitalization"
          ]
        },
        {
          problem: "Chronic Kidney Disease Stage 3b, at risk for AKI",
          assessment: "Baseline Cr 1.6, eGFR 42. Currently Cr 1.9, eGFR 36 after recent AKI (peaked at 2.8). Poor forward flow from heart failure causing prerenal azotemia. Will get worse before better with diuresis but necessary. High risk for acute tubular necrosis if hypoperfusion occurs.",
          
          plan: [
            "Careful diuresis with close monitoring of renal function",
            "Daily BMP during hospitalization",
            "May need to hold ACE-I temporarily if Cr rises significantly",
            "Avoid nephrotoxins",
            "If Cr rises >30% or eGFR drops <30, slow diuresis and consider nephrology consult"
          ]
        },
        {
          problem: "Medication Non-Adherence",
          assessment: "Patient and wife overwhelmed by medication regimen. Not taking furosemide daily - this is life-threatening given his heart failure. Wife has early dementia herself and cannot reliably manage his medications.",
          
          plan: [
            "Home health to set up pillbox system and provide medication management",
            "Simplify regimen where possible",
            "Consider once-daily dosing when feasible",
            "VNA to supervise medication administration if patient returns home",
            "May need facility placement if cannot manage at home"
          ]
        },
        {
          problem: "Depression with Passive Death Wishes",
          assessment: "Severe depression - hopelessness, anhedonia, passive death wishes. Contributing to poor self-care and continued smoking. No active SI plan but 'wouldn't mind dying.' Given multiple medical issues and poor prognosis, depression is understandable but untreated.",
          
          plan: [
            "Psychiatry or palliative care consult inpatient for evaluation and treatment recommendations",
            "SSRI may help if appropriate - sertraline or citalopram good options in elderly with medical comorbidities",
            "Counseling if willing",
            "Assess carefully for active SI - currently denies plan or intent",
            "Wife to monitor closely",
            "Palliative care for existential distress and goals of care"
          ]
        },
        {
          problem: "Tobacco Use Disorder - Active",
          assessment: "Continued smoking despite severe COPD, home oxygen, multiple hospitalizations. Severe nicotine addiction. Depression contributing. Major factor in disease progression and poor prognosis. FIRE RISK.",
          
          plan: [
            "Intensive smoking cessation counseling during hospitalization - captive audience",
            "Nicotine replacement therapy inpatient",
            "Consider varenicline or bupropion if willing (tried before but may be willing now given severity)",
            "Psychiatric treatment of depression may help motivation to quit",
            "Family meeting to address safety and smoking",
            "If continues smoking with oxygen at home, may need to discontinue oxygen (fire risk) - but then will die of hypoxemia - untenable situation"
          ]
        },
        {
          problem: "End-Stage Disease / Palliative Care Needs",
          assessment: "This patient has end-stage cardiopulmonary disease. Multiple organ system involvement. Frequent hospitalizations. Severe functional decline. Poor quality of life. Likely months to 1-2 years life expectancy. DNR/DNI in place. Palliative care approach appropriate.",
          
          plan: [
            "Palliative care consult during hospitalization",
            "Goals of care discussion with patient and family",
            "Symptom management focus",
            "NOT offering hospice yet as patient 'not ready' but plant seeds",
            "May benefit from home hospice for symptom management even if not fully ready for end-of-life care",
            "Advance care planning - update directives, discuss what he wants",
            "Quality of life vs prolonging life discussion"
          ]
        }
      ],
      
      orders_placed: [
        { type: "HOSPITAL ADMISSION", to: "Medical floor via direct admission", reason: "Acute decompensated heart failure requiring IV diuresis, volume overload" },
        { type: "Labs - Today before admission", tests: "BMP, CBC, BNP, glucose" },
        { type: "Admission orders communicated", includes: [
          "IV furosemide drip",
          "Strict I/O",
          "Daily weights",
          "Daily BMP",
          "Continue home COPD meds",
          "Continue oxygen",
          "Hold metformin",
          "Cardiology consult",
          "Pulmonology consult",
          "Palliative care consult",
          "Consider endocrine consult",
          "Psychiatry consult for depression"
        ]},
        { type: "Code status", status: "DNR/DNI - confirmed with patient" },
        { type: "Contact", to: "Hospitalist Dr. Williams - patient expected on medical floor within 2 hours" }
      ],
      
      patient_communication: [
        "Long discussion with patient and wife about severity of condition",
        "Explained he is in heart failure with life-threatening fluid overload",
        "Reviewed that oral diuretics not working - needs IV",
        "Discussed DNR/DNI status - patient reaffirmed wishes",
        "Wants to be comfortable but willing to accept hospitalization for symptom relief",
        "Does NOT want ICU or intubation",
        "Reviewed critical importance of taking medications daily",
        "SERIOUS discussion about smoking with oxygen - fire risk, harm to self and others",
        "Explained continuing to smoke is 'pouring gasoline on a fire' regarding his lung disease",
        "Patient acknowledged understanding but unclear if will actually quit",
        "Wife tearful - understands how serious situation is",
        "Daughter called during visit - updated on plan"
      ],
      
      time_spent: {
        face_to_face: "65 minutes",
        counseling: "45 minutes (>50% of visit time)",
        complexity: "Very high - multiple unstable life-threatening conditions, extensive counseling on multiple issues, goals of care discussion, coordination of hospital admission, family meeting"
      },
      
      billing: {
        cpt: "99215",
        icd10: [
          "I50.9 (Heart failure, unspecified - biventricular)",
          "I27.81 (Cor pulmonale)",
          "J44.1 (COPD with acute exacerbation)",
          "J96.91 (Respiratory failure)",
          "N18.3b (CKD stage 3b)",
          "E11.65 (DM with hyperglycemia)",
          "F17.210 (Nicotine dependence, cigarettes)",
          "F32.9 (Major depressive disorder)",
          "Z99.81 (Long-term oxygen dependence)"
        ],
        justification: "Very high complexity office visit for patient with multiple severe life-threatening conditions including decompensated heart failure requiring immediate hospitalization, extensive counseling on smoking cessation and goals of care, medication non-adherence interventions, depression management, coordination of hospital admission and multiple specialist consultations"
      }
    },
    
    key_clinical_issues: [
      "Life-threatening volume overload - requires immediate hospitalization for IV diuresis",
      "End-stage COPD and heart failure - poor prognosis",
      "Active smoker despite home oxygen - major safety and health risk",
      "Medication non-adherence causing decompensation",
      "Depression with passive death wishes - contributing to poor self-care",
      "High risk for readmission within 30 days",
      "Palliative care needs - likely months to 1-2 years to live",
      "Living situation unsafe - limited support, fire risk",
      "Wife has early dementia - cannot manage his care adequately"
    ],
    
    red_flags: [
      "Any worsening respiratory distress - could be pulmonary edema, COPD exacerbation, PE",
      "Chest pain - could be MI given CAD history",
      "Altered mental status - could be hypoxia, hypercarbia, sepsis",
      "Acute renal failure during diuresis - may limit ability to diurese",
      "Severe hyperkalemia - could be fatal",
      "Fire in home from smoking with oxygen",
      "Death at home - given prognosis and DNR/DNI status, this is possible"
    ],
    
    prognosis: {
      short_term: "High risk for death during this hospitalization or within 30 days. Multiple organ dysfunction. End-stage disease.",
      long_term: "Poor. Life expectancy likely months to 1-2 years maximum. Will likely have multiple additional hospitalizations. Quality of life very poor.",
      factors: "Continued smoking, heart failure, cor pulmonale, COPD, diabetes, CKD, depression, poor social support, medication non-adherence"
    },
    
    disposition: "Direct admission to medical floor today via hospitalist Dr. Williams. EMS transport arranged. Wife will follow. Will provide hospital updates."
  }

};

export default PATIENT_DATABASE;