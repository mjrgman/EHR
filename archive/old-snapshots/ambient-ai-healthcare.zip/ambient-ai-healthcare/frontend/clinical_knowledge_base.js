// CLINICAL KNOWLEDGE BASE
// This comprehensive medical knowledge base provides the AI with evidence-based 
// clinical intelligence for decision support, drug information, and treatment protocols.

export const CLINICAL_KNOWLEDGE_BASE = {
  
  // ============================================================================
  // MEDICATION DATABASE
  // ============================================================================
  
  medications: {
    
    // Diabetes Medications
    metformin: {
      generic_name: "Metformin Hydrochloride",
      brand_names: ["Glucophage", "Glumetza", "Fortamet"],
      drug_class: "Biguanide",
      indications: ["Type 2 Diabetes Mellitus"],
      mechanism: "Decreases hepatic glucose production, decreases intestinal absorption of glucose, improves insulin sensitivity",
      
      dosing: {
        initial: "500mg PO BID or 850mg PO daily with meals",
        titration: "Increase by 500mg weekly or 850mg every 2 weeks",
        maximum: "2550mg/day (divided doses)",
        common_regimens: ["500mg BID", "850mg BID", "1000mg BID"]
      },
      
      contraindications: [
        "eGFR <30 mL/min/1.73mÂ²",
        "Metabolic acidosis",
        "Acute heart failure",
        "Severe hepatic impairment"
      ],
      
      adverse_effects: {
        common: ["Diarrhea", "Nausea", "Abdominal discomfort", "Metallic taste"],
        serious: ["Lactic acidosis (rare)", "Vitamin B12 deficiency (long-term use)"]
      },
      
      monitoring: ["Renal function annually", "Vitamin B12 every 2-3 years on long-term therapy"],
      
      drug_interactions: [
        {
          drug: "Contrast dye",
          interaction: "Hold metformin before and 48 hours after iodinated contrast procedures if eGFR <60",
          severity: "major"
        },
        {
          drug: "Alcohol",
          interaction: "Increased risk of lactic acidosis",
          severity: "moderate"
        }
      ],
      
      insurance: {
        typical_tier: 1,
        typical_copay: "$4-10/month",
        prior_auth_usually_required: false
      },
      
      patient_counseling: [
        "Take with food to reduce GI upset",
        "May cause diarrhea initially - usually improves",
        "Report severe abdominal pain, muscle pain, or difficulty breathing",
        "Do not crush or chew extended-release tablets"
      ]
    },
    
    empagliflozin: {
      generic_name: "Empagliflozin",
      brand_names: ["Jardiance"],
      drug_class: "SGLT2 Inhibitor",
      indications: [
        "Type 2 Diabetes Mellitus",
        "Heart failure with reduced ejection fraction",
        "Reduce risk of cardiovascular death in T2DM with CVD"
      ],
      mechanism: "Inhibits sodium-glucose co-transporter 2 in proximal tubule, increases urinary glucose excretion",
      
      dosing: {
        diabetes: "10mg PO daily, may increase to 25mg daily",
        heart_failure: "10mg PO daily",
        timing: "Morning, with or without food"
      },
      
      contraindications: [
        "Type 1 diabetes",
        "Diabetic ketoacidosis",
        "eGFR <20 (avoid initiation if <45)",
        "Dialysis"
      ],
      
      adverse_effects: {
        common: [
          "Genital mycotic infections (10% women, 4% men)",
          "Urinary tract infections",
          "Increased urination",
          "Hypotension (volume depletion)"
        ],
        serious: [
          "Diabetic ketoacidosis (rare)",
          "Acute kidney injury",
          "Fournier's gangrene (very rare)",
          "Lower limb amputation (small increased risk)"
        ]
      },
      
      benefits: {
        a1c_reduction: "0.5-0.8%",
        weight_loss: "2-3 kg average",
        cardiovascular: "38% reduction in CV death in EMPA-REG trial",
        renal: "Slows progression of diabetic kidney disease",
        heart_failure: "Reduces HF hospitalizations"
      },
      
      monitoring: [
        "Renal function at baseline and periodically",
        "Volume status in elderly or those on diuretics",
        "Signs of genital infections"
      ],
      
      drug_interactions: [
        {
          drug: "Diuretics",
          interaction: "Increased risk of volume depletion and hypotension",
          severity: "moderate",
          recommendation: "Monitor volume status, may need diuretic dose adjustment"
        },
        {
          drug: "Insulin/Sulfonylureas",
          interaction: "Increased risk of hypoglycemia",
          severity: "moderate",
          recommendation: "May need to reduce insulin or sulfonylurea dose"
        }
      ],
      
      insurance: {
        typical_tier: 3,
        typical_copay: "$40-70/month",
        prior_auth_usually_required: false,
        note: "Most plans cover for diabetes without PA after metformin trial"
      },
      
      patient_counseling: [
        "Increases sugar in urine - may increase yeast infections",
        "Stay hydrated, especially in hot weather or when ill",
        "Report severe abdominal pain, nausea/vomiting (ketoacidosis warning)",
        "Maintain good perineal hygiene to reduce infection risk",
        "Report signs of UTI or genital infection promptly"
      ],
      
      special_considerations: {
        genital_infections: "If recurrent, consider alternative SGLT2i or different drug class. Proper hygiene counseling important.",
        volume_depletion: "Assess volume status before initiating in elderly, those on loop diuretics, or with low BP"
      }
    },
    
    semaglutide: {
      generic_name: "Semaglutide",
      brand_names: ["Ozempic (diabetes)", "Wegovy (obesity)", "Rybelsus (oral)"],
      drug_class: "GLP-1 Receptor Agonist",
      indications: [
        "Type 2 Diabetes Mellitus",
        "Reduce cardiovascular events in T2DM with CVD",
        "Chronic weight management (Wegovy)"
      ],
      mechanism: "GLP-1 agonist - increases insulin secretion, decreases glucagon, slows gastric emptying, reduces appetite",
      
      dosing: {
        ozempic_diabetes: {
          initial: "0.25mg SC weekly x 4 weeks (not therapeutic, for GI tolerance)",
          maintenance: "0.5mg SC weekly (may increase to 1mg after 4+ weeks, max 2mg)",
          timing: "Once weekly, same day each week, any time of day"
        },
        rybelsus_oral: {
          initial: "3mg PO daily x 30 days",
          maintenance: "7mg daily (may increase to 14mg)",
          administration: "On empty stomach with â‰¤4oz water, wait 30 min before food/drink/other meds"
        }
      },
      
      contraindications: [
        "Personal or family history of medullary thyroid carcinoma",
        "Multiple Endocrine Neoplasia syndrome type 2 (MEN 2)",
        "Pregnancy (discontinue if pregnancy planned or occurs)"
      ],
      
      adverse_effects: {
        common: [
          "Nausea (15-20%, usually transient)",
          "Vomiting",
          "Diarrhea",
          "Constipation",
          "Abdominal pain",
          "Decreased appetite"
        ],
        serious: [
          "Pancreatitis (rare)",
          "Diabetic retinopathy complications (rapid A1C reduction)",
          "Acute kidney injury (from severe GI effects)",
          "Hypoglycemia (when combined with insulin/sulfonylureas)",
          "Gallbladder disease"
        ]
      },
      
      benefits: {
        a1c_reduction: "1.5-2.0% average",
        weight_loss: "10-15 lbs over 6 months at 0.5mg, 15-20 lbs at 1mg",
        cardiovascular: "26% reduction in major CV events (SUSTAIN-6 trial)",
        renal: "24% reduction in kidney disease progression (FLOW trial, 2024)"
      },
      
      monitoring: [
        "Blood glucose",
        "Weight and BMI",
        "Renal function (if significant GI effects)",
        "Signs/symptoms of pancreatitis",
        "Diabetic retinopathy (in patients with pre-existing retinopathy)"
      ],
      
      drug_interactions: [
        {
          drug: "Oral medications",
          interaction: "Delays gastric emptying, may affect absorption of oral drugs",
          severity: "moderate",
          recommendation: "Take oral contraceptives and antibiotics at least 1 hour before semaglutide"
        },
        {
          drug: "Insulin",
          interaction: "Increased risk of hypoglycemia",
          severity: "moderate",
          recommendation: "Reduce insulin dose by 20-30% when initiating"
        }
      ],
      
      insurance: {
        ozempic: {
          typical_tier: 3,
          typical_copay: "$25-100/month with insurance",
          prior_auth: "Usually not required if metformin tried first",
          savings_program: "Manufacturer savings card available"
        }
      },
      
      patient_counseling: [
        "Nausea is common but usually improves after 4-8 weeks",
        "Take with food initially if nausea occurs, stay hydrated",
        "Injection technique: subcutaneous in abdomen, thigh, or upper arm",
        "Rotate injection sites to prevent lipodystrophy",
        "Can be taken any day of the week but same day weekly",
        "If miss dose and <5 days late, take ASAP; if >5 days, skip and resume schedule",
        "Report severe abdominal pain that doesn't go away (pancreatitis warning)",
        "May feel full faster - eat smaller portions"
      ],
      
      titration_strategy: {
        rationale: "Start low to build GI tolerance",
        schedule: "0.25mg x 4 weeks â†’ 0.5mg x 4+ weeks â†’ 1mg if needed for A1C goal",
        when_to_increase: "If tolerating well and A1C >7% after 3 months on current dose",
        when_not_to_increase: "If significant nausea/vomiting, weight loss goal achieved, or A1C at goal"
      },
      
      special_populations: {
        ckd: "Safe in CKD, including stage 4-5. Provides renal protection. Monitor for dehydration from GI effects.",
        elderly: "Start low, titrate slowly. Monitor for dehydration and nutrition.",
        pregnancy: "Discontinue when pregnancy detected or 2 months before planned conception"
      }
    },
    
    lisinopril: {
      generic_name: "Lisinopril",
      brand_names: ["Prinivil", "Zestril"],
      drug_class: "ACE Inhibitor",
      indications: [
        "Hypertension",
        "Heart failure with reduced ejection fraction",
        "Post-myocardial infarction",
        "Diabetic nephropathy"
      ],
      mechanism: "Inhibits ACE, preventing conversion of angiotensin I to angiotensin II, reduces aldosterone secretion",
      
      dosing: {
        hypertension: {
          initial: "10mg PO daily",
          usual: "20-40mg daily",
          maximum: "80mg daily"
        },
        heart_failure: {
          initial: "2.5-5mg PO daily",
          target: "20-40mg daily"
        },
        timing: "Once daily, same time of day"
      },
      
      contraindications: [
        "History of angioedema with ACE inhibitors",
        "Pregnancy (teratogenic)",
        "Bilateral renal artery stenosis"
      ],
      
      adverse_effects: {
        common: [
          "Dry cough (10-20%)",
          "Dizziness",
          "Headache",
          "Fatigue"
        ],
        serious: [
          "Angioedema (rare but life-threatening)",
          "Hyperkalemia",
          "Acute kidney injury (usually reversible)",
          "Hypotension (first dose effect)"
        ]
      },
      
      benefits: {
        cv_protection: "Reduces CV events and mortality in high-risk patients",
        renal_protection: "Slows progression of diabetic and non-diabetic CKD",
        heart_failure: "Reduces mortality and hospitalizations"
      },
      
      monitoring: [
        "Blood pressure",
        "Renal function and potassium within 1-2 weeks of initiation/dose change",
        "Continue monitoring every 3-6 months"
      ],
      
      drug_interactions: [
        {
          drug: "Potassium supplements/K-sparing diuretics",
          interaction: "Increased risk of hyperkalemia",
          severity: "major",
          recommendation: "Monitor potassium closely, may need to avoid combination"
        },
        {
          drug: "NSAIDs",
          interaction: "Reduced antihypertensive effect, increased risk of AKI and hyperkalemia",
          severity: "moderate",
          recommendation: "Use NSAIDs sparingly, monitor renal function and BP"
        },
        {
          drug: "Lithium",
          interaction: "Increased lithium levels",
          severity: "major",
          recommendation: "Monitor lithium levels closely"
        }
      ],
      
      renal_dosing: {
        "eGFR >30": "No adjustment needed",
        "eGFR 10-30": "Start 50% of usual dose",
        "eGFR <10": "Start 2.5mg daily, titrate carefully"
      },
      
      insurance: {
        typical_tier: 1,
        typical_copay: "$4-10/month",
        prior_auth_usually_required: false
      },
      
      patient_counseling: [
        "May cause dry cough - report if bothersome",
        "Can cause dizziness, especially when standing (rises slowly from sitting/lying)",
        "Report swelling of face, lips, tongue, or throat immediately (angioedema)",
        "Women of childbearing age: Not safe in pregnancy, discuss contraception",
        "Continue taking even if feeling well - controls BP, protects organs"
      ],
      
      special_considerations: {
        cough: "Occurs in 10-20%. If bothersome, can switch to ARB (e.g., losartan). Usually develops within first weeks to months.",
        acute_kidney_injury: "Small rise in creatinine (up to 30%) is expected and acceptable. If >30% increase, reassess volume status, check for obstruction or NSAID use.",
        first_dose_hypotension: "More common in volume-depleted patients or those on diuretics. Consider starting low dose."
      }
    },
    
    atorvastatin: {
      generic_name: "Atorvastatin Calcium",
      brand_names: ["Lipitor"],
      drug_class: "HMG-CoA Reductase Inhibitor (Statin)",
      indications: [
        "Hyperlipidemia",
        "Primary prevention of ASCVD in high-risk patients",
        "Secondary prevention after MI, stroke, or other ASCVD events"
      ],
      mechanism: "Inhibits HMG-CoA reductase, reducing cholesterol synthesis in the liver",
      
      dosing: {
        low_intensity: "10mg daily (30% LDL reduction)",
        moderate_intensity: "20mg daily (40% LDL reduction)",
        high_intensity: "40-80mg daily (50% LDL reduction)",
        timing: "Once daily, preferably at bedtime"
      },
      
      contraindications: [
        "Active liver disease",
        "Pregnancy and breastfeeding",
        "Hypersensitivity to statins"
      ],
      
      adverse_effects: {
        common: [
          "Myalgia (muscle aches) 5-10%",
          "Headache",
          "Nausea",
          "Diarrhea"
        ],
        serious: [
          "Rhabdomyolysis (very rare, <0.1%)",
          "Hepatotoxicity (transaminase elevations)",
          "New-onset diabetes (small increased risk)",
          "Cognitive effects (controversial)"
        ]
      },
      
      benefits: {
        ldl_reduction: "30-50% depending on dose",
        cv_risk_reduction: "25-35% reduction in major CV events",
        mortality: "Reduced all-cause mortality in secondary prevention"
      },
      
      monitoring: [
        "Lipid panel at baseline, 4-12 weeks after initiation, then every 3-12 months",
        "ALT at baseline (routine monitoring no longer recommended)",
        "Monitor for muscle symptoms"
      ],
      
      drug_interactions: [
        {
          drug: "Gemfibrozil",
          interaction: "Significantly increases statin levels, high risk of myopathy",
          severity: "major",
          recommendation: "Avoid combination"
        },
        {
          drug: "CYP3A4 inhibitors (clarithromycin, itraconazole, grapefruit juice)",
          interaction: "Increased atorvastatin levels",
          severity: "moderate",
          recommendation: "Use lowest effective statin dose, avoid large amounts of grapefruit"
        }
      ],
      
      insurance: {
        typical_tier: 1,
        typical_copay: "$4-10/month",
        prior_auth_usually_required: false
      },
      
      patient_counseling: [
        "Take at bedtime for best effect",
        "Report unexplained muscle pain, tenderness, or weakness",
        "Continue healthy diet and exercise",
        "Avoid grapefruit juice (can increase drug levels)",
        "Don't stop suddenly - consistent use provides CV protection",
        "Women: Not safe in pregnancy - use reliable contraception"
      ],
      
      statin_intensity_selection: {
        high_intensity_indications: [
          "Clinical ASCVD (MI, stroke, PAD)",
          "LDL â‰¥190 mg/dL",
          "Diabetes age 40-75 with LDL 70-189 and 10-year ASCVD risk â‰¥7.5%"
        ],
        moderate_intensity_indications: [
          "Diabetes age 40-75 with lower risk",
          "10-year ASCVD risk 7.5-19.9%"
        ]
      }
    },
    
    aspirin: {
      generic_name: "Aspirin (Acetylsalicylic Acid)",
      brand_names: ["Bayer", "Ecotrin", "many others"],
      drug_class: "Antiplatelet Agent, NSAID",
      indications: [
        "Secondary prevention after MI/stroke",
        "Primary prevention in select high-risk patients",
        "Acute coronary syndrome"
      ],
      mechanism: "Irreversibly inhibits COX-1, preventing platelet aggregation",
      
      dosing: {
        primary_prevention: "81mg PO daily (controversial, individualize risk/benefit)",
        secondary_prevention: "81mg PO daily",
        acs: "162-325mg loading, then 81mg daily"
      },
      
      contraindications: [
        "Active bleeding",
        "Severe bleeding disorder",
        "Aspirin allergy/hypersensitivity"
      ],
      
      adverse_effects: {
        common: ["GI upset", "Dyspepsia"],
        serious: ["GI bleeding", "Hemorrhagic stroke (rare)", "Aspirin-exacerbated respiratory disease"]
      },
      
      monitoring: ["Signs of bleeding", "Annual assessment of continued need"],
      
      drug_interactions: [
        {
          drug: "Anticoagulants (warfarin, DOACs)",
          interaction: "Significantly increased bleeding risk",
          severity: "major",
          recommendation: "Use only if clear indication, monitor closely"
        },
        {
          drug: "NSAIDs (ibuprofen)",
          interaction: "Reduced antiplatelet effect of aspirin, increased GI bleeding",
          severity: "moderate",
          recommendation: "Take aspirin 2 hours before ibuprofen if both needed"
        }
      ],
      
      patient_counseling: [
        "Take with food if stomach upset occurs",
        "Enteric-coated may reduce GI effects",
        "Report unusual bleeding or bruising",
        "Don't stop suddenly if prescribed for heart protection - increases CV risk",
        "Tell all providers you take aspirin before procedures"
      ],
      
      primary_prevention_guidelines: {
        uspstf_2022: "Low-dose aspirin for primary prevention in adults 40-59 with â‰¥10% 10-year CV risk (individualized decision). Not recommended for primary prevention in adults â‰¥60.",
        considerations: "Bleeding risk vs CV benefit. Consider discontinuing if age >70 without CVD."
      }
    },
    
    fluconazole: {
      generic_name: "Fluconazole",
      brand_names: ["Diflucan"],
      drug_class: "Triazole Antifungal",
      indications: [
        "Vulvovaginal candidiasis",
        "Oropharyngeal candidiasis",
        "Esophageal candidiasis",
        "Systemic candidiasis"
      ],
      mechanism: "Inhibits fungal cytochrome P450 enzyme 14Î±-demethylase, disrupting ergosterol synthesis",
      
      dosing: {
        vaginal_yeast: "150mg PO single dose",
        recurrent_vaginal: "150mg day 1, 4, 7, then 150mg weekly x 6 months",
        oral_thrush: "200mg day 1, then 100mg daily x 7-14 days"
      },
      
      contraindications: [
        "Coadministration with certain medications (see interactions)",
        "Hypersensitivity to azoles"
      ],
      
      adverse_effects: {
        common: ["Nausea", "Headache", "Abdominal pain"],
        serious: ["Hepatotoxicity (rare)", "QT prolongation", "Stevens-Johnson syndrome (very rare)"]
      },
      
      drug_interactions: [
        {
          drug: "Warfarin",
          interaction: "Increased INR, bleeding risk",
          severity: "major",
          recommendation: "Monitor INR closely, may need warfarin dose reduction"
        },
        {
          drug: "Statins",
          interaction: "Increased statin levels, myopathy risk",
          severity: "moderate",
          recommendation: "Consider brief statin interruption or use low dose"
        }
      ],
      
      patient_counseling: [
        "For vaginal yeast infection, single dose usually sufficient",
        "If recurrent infections (>4/year), may need longer treatment course",
        "Partner treatment usually not necessary unless symptomatic",
        "Maintain good hygiene to prevent recurrence"
      ],
      
      clinical_pearls: {
        recurrent_candidiasis: "If â‰¥4 episodes per year, investigate for underlying causes: uncontrolled diabetes, immunosuppression, antibiotic use, SGLT2 inhibitor use. May need maintenance suppression."
      }
    }
  },
  
  // ============================================================================
  // DRUG INTERACTION CHECKER
  // ============================================================================
  
  checkDrugInteractions: function(medicationList) {
    const interactions = [];
    const drugNames = medicationList.map(m => m.name.toLowerCase());
    
    // Check each medication against the database
    for (let i = 0; i < drugNames.length; i++) {
      const drug1 = drugNames[i];
      const drug1Data = this.medications[drug1];
      
      if (drug1Data && drug1Data.drug_interactions) {
        for (const interaction of drug1Data.drug_interactions) {
          // Check if the interacting drug is in the list
          for (let j = 0; j < drugNames.length; j++) {
            if (i !== j && drugNames[j].includes(interaction.drug.toLowerCase())) {
              interactions.push({
                drug1: medicationList[i].name,
                drug2: medicationList[j].name,
                interaction: interaction.interaction,
                severity: interaction.severity,
                recommendation: interaction.recommendation || ""
              });
            }
          }
        }
      }
    }
    
    return interactions;
  },
  
  // ============================================================================
  // CLINICAL PROTOCOLS & GUIDELINES
  // ============================================================================
  
  clinical_protocols: {
    
    diabetes_management: {
      name: "Type 2 Diabetes Management",
      source: "ADA Standards of Care 2024",
      
      goals: {
        a1c: {
          general: "<7%",
          less_stringent: "<8% (elderly, limited life expectancy, high hypoglycemia risk)",
          more_stringent: "<6.5% (select patients, early disease, no CV disease)"
        },
        blood_pressure: "<130/80 mmHg",
        ldl: "<100 mg/dL (higher risk) or <70 mg/dL (very high risk/ASCVD)"
      },
      
      treatment_algorithm: {
        step1: {
          title: "Initial therapy",
          medication: "Metformin",
          rationale: "First-line unless contraindicated. Well-tolerated, inexpensive, CV neutral, weight neutral",
          dose: "Start 500mg BID or 850mg daily, titrate to 1000mg BID or 2000mg daily",
          when_to_add_second_agent: "If A1C remains â‰¥7% after 3 months at max tolerated dose"
        },
        
        step2: {
          title: "Add second agent based on compelling indications",
          options: [
            {
              drug_class: "GLP-1 agonist",
              indication: "ASCVD, high CV risk, obesity, or need to minimize hypoglycemia",
              preferred_agents: ["Semaglutide", "Dulaglutide", "Liraglutide"],
              benefits: "1.5-2% A1C reduction, 10-15 lbs weight loss, CV benefit, renal protection",
              drawbacks: "Injectable (most), GI side effects, expensive"
            },
            {
              drug_class: "SGLT2 inhibitor",
              indication: "Heart failure, CKD (eGFR â‰¥20), high CV risk",
              preferred_agents: ["Empagliflozin", "Dapagliflozin", "Canagliflozin"],
              benefits: "0.5-0.8% A1C reduction, 5-7 lbs weight loss, CV and renal benefits, HF hospitalization reduction",
              drawbacks: "Genital infections, DKA risk (rare), expensive"
            },
            {
              drug_class: "DPP-4 inhibitor",
              indication: "Need to minimize hypoglycemia, cost-conscious",
              preferred_agents: ["Sitagliptin", "Linagliptin"],
              benefits: "0.5-0.8% A1C reduction, weight neutral, well-tolerated",
              drawbacks: "No CV benefit, modest efficacy"
            },
            {
              drug_class: "Sulfonylurea",
              indication: "Cost is major concern",
              preferred_agents: ["Glipizide", "Glimepiride"],
              benefits: "1-1.5% A1C reduction, inexpensive",
              drawbacks: "Weight gain, hypoglycemia risk, no CV benefit"
            },
            {
              drug_class: "Basal insulin",
              indication: "A1C >9%, symptoms of hyperglycemia",
              preferred_agents: ["Insulin glargine", "Insulin detemir"],
              benefits: "Most potent A1C reduction (1.5-3.5%)",
              drawbacks: "Hypoglycemia, weight gain, requires monitoring and titration"
            }
          ]
        },
        
        step3: {
          title: "Triple therapy if A1C remains above goal",
          strategy: "Add third agent from different class, or intensify insulin therapy",
          considerations: "Reassess adherence, address barriers, consider specialist referral"
        }
      },
      
      monitoring_frequency: {
        a1c: "Every 3 months if not at goal, every 6 months if stable at goal",
        self_monitoring: "Variable based on medications - more frequent with insulin",
        annual_screening: [
          "Lipid panel",
          "Urine albumin-to-creatinine ratio",
          "Serum creatinine and eGFR",
          "Dilated eye exam",
          "Comprehensive foot exam",
          "Monofilament testing"
        ]
      },
      
      lifestyle_modifications: {
        diet: "Mediterranean or DASH diet, carbohydrate awareness, portion control",
        exercise: "150 minutes/week moderate intensity, resistance training 2-3x/week",
        weight_loss: "5-10% weight loss improves glycemic control significantly"
      },
      
      special_populations: {
        ckd: {
          medication_adjustments: "Metformin safe to eGFR 30. GLP-1 and SGLT2i provide renal protection. Avoid sulfonylureas.",
          monitoring: "More frequent renal function checks"
        },
        elderly: {
          a1c_goal: "Less stringent (7.5-8%) to reduce hypoglycemia risk",
          medication_preferences: "Avoid sulfonylureas, prefer GLP-1/SGLT2i for low hypo risk"
        }
      }
    },
    
    hypertension_management: {
      name: "Hypertension Management",
      source: "ACC/AHA 2017, Updated 2023",
      
      blood_pressure_goals: {
        general: "<130/80 mmHg",
        diabetes_or_ckd: "<130/80 mmHg",
        elderly_healthy: "<130/80 mmHg (if tolerated)",
        elderly_frail: "<140/90 mmHg (individualized)"
      },
      
      treatment_algorithm: {
        step1: {
          title: "Initial monotherapy or combination",
          options: [
            "ACE inhibitor or ARB (preferred if diabetes or CKD)",
            "Thiazide diuretic (chlorthalidone preferred)",
            "Calcium channel blocker (long-acting)"
          ],
          combination_initial: "Consider if BP >20/10 above goal or stage 2 HTN (â‰¥140/90)"
        },
        
        step2: {
          title: "Add second agent from different class",
          preferred_combinations: [
            "ACE-I/ARB + Thiazide diuretic",
            "ACE-I/ARB + Calcium channel blocker",
            "Calcium channel blocker + Thiazide diuretic"
          ],
          avoid: "ACE-I + ARB together (increased adverse effects, no added benefit)"
        },
        
        step3: {
          title: "Triple therapy",
          strategy: "ACE-I/ARB + CCB + Thiazide diuretic",
          consider: "Referral to hypertension specialist if BP still uncontrolled"
        },
        
        step4: {
          title: "Resistant hypertension",
          definition: "Uncontrolled BP on 3 agents including diuretic, or controlled on â‰¥4 agents",
          workup: "Screen for secondary causes, assess adherence, check home BP",
          additional_agents: ["Spironolactone", "Beta-blocker", "Alpha blocker"]
        }
      },
      
      special_populations: {
        diabetes: {
          preferred: "ACE-I or ARB for renal protection",
          goal: "<130/80 mmHg"
        },
        ckd: {
          preferred: "ACE-I or ARB to slow progression",
          monitoring: "Check K+ and Cr within 1-2 weeks, accept up to 30% Cr increase"
        },
        black_patients: {
          initial_therapy: "Thiazide diuretic or CCB (ACE-I less effective as monotherapy)",
          with_diabetes_ckd: "ACE-I or ARB still preferred"
        }
      },
      
      lifestyle_modifications: {
        weight_loss: "1 mmHg reduction per kg lost",
        dash_diet: "8-14 mmHg reduction",
        sodium_restriction: "<1500mg ideal, <2300mg minimum - 5-6 mmHg reduction",
        exercise: "4-5 mmHg reduction",
        alcohol_moderation: "2-4 mmHg reduction"
      }
    },
    
    ckd_management: {
      name: "Chronic Kidney Disease Management",
      source: "KDIGO 2024",
      
      staging: {
        stage_1: { egfr: "â‰¥90", albuminuria: "May have", description: "Normal or high GFR with kidney damage" },
        stage_2: { egfr: "60-89", albuminuria: "May have", description: "Mild reduction in GFR with kidney damage" },
        stage_3a: { egfr: "45-59", description: "Mild to moderate reduction in GFR" },
        stage_3b: { egfr: "30-44", description: "Moderate to severe reduction in GFR" },
        stage_4: { egfr: "15-29", description: "Severe reduction in GFR" },
        stage_5: { egfr: "<15", description: "Kidney failure" }
      },
      
      albuminuria_categories: {
        A1: { uacr: "<30", description: "Normal to mildly increased" },
        A2: { uacr: "30-300", description: "Moderately increased" },
        A3: { uacr: ">300", description: "Severely increased" }
      },
      
      treatment_priorities: {
        slow_progression: [
          "ACE-I or ARB for albuminuria",
          "SGLT2 inhibitor (empagliflozin, dapagliflozin) - strong renal protective benefit",
          "GLP-1 agonist if diabetic",
          "BP control <130/80",
          "Optimize glycemic control if diabetic (A1C 7-7.5%)"
        ],
        prevent_complications: [
          "Anemia management (goal Hgb >10 g/dL)",
          "Bone and mineral disorder management",
          "Metabolic acidosis correction",
          "Volume and electrolyte management"
        ]
      },
      
      medication_adjustments: {
        metformin: "Safe to eGFR 30, reduce dose if 30-45, discontinue if <30",
        nsaids: "Avoid - nephrotoxic, worsen HTN",
        ace_i_arb: "Continue unless AKI, severe hyperkalemia. Small Cr rise (up to 30%) acceptable.",
        sglt2_inhibitors: "Can initiate if eGFR â‰¥20. Continue even as eGFR declines for renal protection."
      },
      
      monitoring: {
        stage_3a: "Annual eGFR, UACR, electrolytes",
        stage_3b_4: "Every 3-6 months",
        stage_5: "Monthly, prepare for RRT"
      },
      
      referral_to_nephrology: [
        "eGFR <30",
        "Rapid decline (>5 mL/min/year)",
        "Heavy proteinuria (UACR >300)",
        "Unclear etiology",
        "Difficult to manage complications"
      ]
    },
    
    antibiotic_stewardship: {
      name: "Antibiotic Stewardship Guidelines",
      
      upper_respiratory_infection: {
        typical_duration: "7-10 days viral syndrome",
        antibiotic_indicated: "NO - viral in vast majority",
        red_flags_for_bacterial: [
          "Symptoms >10 days without improvement",
          "Severe symptoms (fever >102Â°F, purulent nasal discharge, facial pain) for â‰¥3 days",
          "Worsening after initial improvement ('double sickening')"
        ],
        if_bacterial_suspected: "Amoxicillin-clavulanate 500-875mg BID x 5-7 days (or doxycycline if PCN allergy)"
      },
      
      acute_bronchitis: {
        typical_cause: "Viral 90-95%",
        antibiotic_indicated: "NO unless clear evidence of pneumonia",
        appropriate_treatment: "Symptomatic care - cough suppressants, bronchodilators if wheezing",
        patient_education: "Cough may persist 3-4 weeks, antibiotic won't help"
      },
      
      urinary_tract_infection: {
        uncomplicated_cystitis: {
          first_line: "Nitrofurantoin 100mg BID x 5 days",
          alternative: "TMP-SMX DS BID x 3 days (if local resistance <20%)",
          avoid: "Fluoroquinolones (save for complicated infections)"
        },
        pyelonephritis: {
          outpatient: "Ciprofloxacin 500mg BID x 7 days OR Levofloxacin 750mg daily x 5 days",
          inpatient: "Based on culture/sensitivities"
        }
      },
      
      skin_soft_tissue_infection: {
        uncomplicated_cellulitis: "Cephalexin 500mg QID x 5-7 days",
        mrsa_suspected: "TMP-SMX DS BID + Cephalexin OR Doxycycline 100mg BID",
        abscess: "Incision and drainage primary treatment, antibiotics if extensive or immunocompromised"
      }
    }
  },
  
  // ============================================================================
  // CLINICAL DECISION RULES & CALCULATORS
  // ============================================================================
  
  clinical_calculators: {
    
    egfr_ckd_epi: function(creatinine, age, sex, race) {
      // CKD-EPI equation (2021, race-free version)
      const k = sex === 'F' ? 0.7 : 0.9;
      const alpha = sex === 'F' ? -0.241 : -0.302;
      const min_value = Math.min(creatinine / k, 1);
      const max_value = Math.max(creatinine / k, 1);
      
      let egfr = 142 * Math.pow(min_value, alpha) * Math.pow(max_value, -1.200) * Math.pow(0.9938, age);
      if (sex === 'F') egfr *= 1.012;
      
      return Math.round(egfr);
    },
    
    ascvd_risk_calculator: function(age, sex, race, totalChol, hdl, systolicBP, treatedForBP, diabetes, smoker) {
      // Pooled Cohort Equations for 10-year ASCVD risk
      // This is a simplified version - full calculator more complex
      
      let lnAge = Math.log(age);
      let lnTotalChol = Math.log(totalChol);
      let lnHDL = Math.log(hdl);
      let lnSBP = treatedForBP ? Math.log(systolicBP) : 0;
      let lnUntreatedSBP = !treatedForBP ? Math.log(systolicBP) : 0;
      
      let s;
      if (sex === 'F' && race === 'white') {
        s = -29.799 + 4.884 * lnAge + 13.540 * lnTotalChol - 3.114 * lnHDL - 13.578 * lnHDL * lnAge +
            2.019 * lnSBP + 1.957 * lnUntreatedSBP + (diabetes ? 0.661 : 0) + (smoker ? 7.574 : 0) - 1.665 * (smoker ? lnAge : 0);
        return (1 - Math.pow(0.9665, Math.exp(s - 86.61))) * 100;
      }
      // Add other race/sex combinations for complete implementation
      
      return null; // Placeholder
    },
    
    bmi_calculator: function(weight_lbs, height_inches) {
      return (weight_lbs / (height_inches * height_inches)) * 703;
    },
    
    medication_adherence_rate: function(fillHistory, expectedFills) {
      return (fillHistory.length / expectedFills) * 100;
    }
  },
  
  // ============================================================================
  // LABORATORY REFERENCE RANGES & INTERPRETATION
  // ============================================================================
  
  lab_reference_ranges: {
    
    a1c: {
      unit: "%",
      ranges: [
        { max: 5.6, interpretation: "Normal", color: "green" },
        { min: 5.7, max: 6.4, interpretation: "Prediabetes", color: "yellow" },
        { min: 6.5, interpretation: "Diabetes", color: "red" }
      ],
      goals: {
        general_diabetes: "< 7%",
        individualized_less_stringent: "< 8%",
        individualized_more_stringent: "< 6.5%"
      },
      clinical_significance: function(value, previousValue) {
        const change = value - previousValue;
        if (change >= 0.5) return "Significant worsening - reassess treatment regimen";
        if (change >= 0.3) return "Worsening trend - reinforce adherence and lifestyle";
        if (change <= -0.5) return "Good improvement - current regimen effective";
        return "Stable";
      }
    },
    
    glucose_fasting: {
      unit: "mg/dL",
      ranges: [
        { max: 99, interpretation: "Normal", color: "green" },
        { min: 100, max: 125, interpretation: "Prediabetes", color: "yellow" },
        { min: 126, interpretation: "Diabetes", color: "red" }
      ]
    },
    
    creatinine: {
      unit: "mg/dL",
      ranges: {
        male: [{ min: 0.7, max: 1.3, interpretation: "Normal" }],
        female: [{ min: 0.6, max: 1.2, interpretation: "Normal" }]
      },
      clinical_significance: function(value, baseline) {
        const percentChange = ((value - baseline) / baseline) * 100;
        if (percentChange > 50) return "Acute kidney injury - investigate cause immediately";
        if (percentChange > 30) return "Significant decline - assess volume status, medications, obstruction";
        if (percentChange > 10) return "Mild increase - monitor closely";
        return "Stable";
      }
    },
    
    egfr: {
      unit: "mL/min/1.73mÂ²",
      stages: [
        { min: 90, stage: "1", interpretation: "Normal or high" },
        { min: 60, max: 89, stage: "2", interpretation: "Mildly decreased" },
        { min: 45, max: 59, stage: "3a", interpretation: "Mild to moderately decreased" },
        { min: 30, max: 44, stage: "3b", interpretation: "Moderately to severely decreased" },
        { min: 15, max: 29, stage: "4", interpretation: "Severely decreased" },
        { max: 14, stage: "5", interpretation: "Kidney failure" }
      ],
      actions: {
        stage_1_2: "Monitor annually, address CV risk factors",
        stage_3a: "Monitor every 6-12 months, assess for CKD complications",
        stage_3b: "Monitor every 3-6 months, adjust medications, consider nephrology referral",
        stage_4: "Monitor every 3 months, nephrology referral, prepare for RRT",
        stage_5: "Nephrology management, initiate dialysis planning"
      }
    },
    
    urine_microalbumin_creatinine_ratio: {
      unit: "mcg/mg",
      ranges: [
        { max: 29, category: "A1", interpretation: "Normal to mildly increased", color: "green" },
        { min: 30, max: 300, category: "A2", interpretation: "Moderately increased", color: "yellow" },
        { min: 301, category: "A3", interpretation: "Severely increased", color: "red" }
      ],
      clinical_significance: {
        A1: "No evidence of kidney damage",
        A2: "Early kidney damage, initiate/intensify ACE-I/ARB and SGLT2i",
        A3: "Advanced kidney damage, aggressive treatment, nephrology involvement"
      }
    },
    
    ldl_cholesterol: {
      unit: "mg/dL",
      ranges: [
        { max: 69, interpretation: "Optimal for very high risk", color: "green" },
        { min: 70, max: 99, interpretation: "Optimal for high risk", color: "green" },
        { min: 100, max: 129, interpretation: "Near optimal", color: "yellow" },
        { min: 130, max: 159, interpretation: "Borderline high", color: "orange" },
        { min: 160, max: 189, interpretation: "High", color: "red" },
        { min: 190, interpretation: "Very high", color: "red" }
      ],
      goals_by_risk: {
        very_high_risk: "< 70 mg/dL",
        high_risk: "< 100 mg/dL",
        moderate_risk: "< 130 mg/dL"
      }
    },
    
    blood_pressure: {
      unit: "mmHg",
      classification: [
        { systolic_max: 119, diastolic_max: 79, category: "Normal", action: "Encourage lifestyle modification", color: "green" },
        { systolic_min: 120, systolic_max: 129, diastolic_max: 79, category: "Elevated", action: "Lifestyle modification", color: "yellow" },
        { systolic_min: 130, systolic_max: 139, diastolic_min: 80, diastolic_max: 89, category: "Stage 1 HTN", action: "Lifestyle + medication if high CV risk", color: "orange" },
        { systolic_min: 140, diastolic_min: 90, category: "Stage 2 HTN", action: "Lifestyle + medication", color: "red" }
      ],
      goals: {
        general: "< 130/80",
        diabetes_ckd: "< 130/80",
        elderly_fit: "< 130/80",
        elderly_frail: "< 140/90"
      }
    },
    
    hemoglobin_a1c: {
      clinical_actions: function(value, patientFactors) {
        if (value < 7.0) return "At goal - continue current regimen";
        if (value >= 7.0 && value < 8.0) return "Above goal - intensify therapy, assess adherence";
        if (value >= 8.0 && value < 9.0) return "Significantly above goal - add second agent or adjust doses";
        if (value >= 9.0) return "Markedly elevated - consider triple therapy or insulin, assess barriers";
        return "Unknown";
      }
    }
  },
  
  // ============================================================================
  // SPECIALIST REFERRAL GUIDELINES
  // ============================================================================
  
  referral_guidelines: {
    
    endocrinology: {
      urgent: [
        "Diabetic ketoacidosis",
        "Hyperosmolar hyperglycemic state",
        "Severe hypoglycemia with altered mental status"
      ],
      routine: [
        "A1C persistently >9% despite multiple medications",
        "Difficult to control diabetes (frequent hypo/hyperglycemia)",
        "Starting insulin pump therapy",
        "Pregnancy with diabetes",
        "Pancreatic insufficiency"
      ]
    },
    
    nephrology: {
      urgent: [
        "Acute kidney injury with no clear reversible cause",
        "Rapid decline in kidney function",
        "Severe electrolyte abnormalities"
      ],
      routine: [
        "eGFR < 30 mL/min/1.73mÂ²",
        "eGFR decline > 5 mL/min/year",
        "Urine albumin-to-creatinine ratio > 300 mg/g",
        "Unclear etiology of CKD",
        "Difficult to control hypertension with CKD",
        "Anemia with CKD (Hgb < 10 g/dL)"
      ]
    },
    
    cardiology: {
      urgent: [
        "Acute coronary syndrome",
        "Decompensated heart failure",
        "New significant arrhythmia",
        "Syncope"
      ],
      routine: [
        "Abnormal stress test",
        "Newly diagnosed heart failure",
        "Valvular heart disease",
        "Atrial fibrillation (new or difficult to control)",
        "Palpitations"
      ]
    },
    
    gastroenterology: {
      urgent: [
        "GI bleeding",
        "Severe abdominal pain",
        "Persistent vomiting"
      ],
      routine: [
        "Screening colonoscopy (age 45-75, earlier if family history)",
        "Abnormal liver function tests",
        "Chronic diarrhea or constipation",
        "GERD refractory to PPI therapy",
        "Elevated pancreatic enzymes"
      ]
    },
    
    ophthalmology: {
      urgent: [
        "Sudden vision loss",
        "Retinal detachment symptoms (flashes, floaters, curtain)"
      ],
      routine: [
        "Annual diabetic eye exam",
        "New diagnosis of diabetes (exam within 1 year)",
        "Diabetic retinopathy requiring treatment",
        "Cataracts affecting function",
        "Glaucoma screening (age > 60)"
      ]
    }
  },
  
  // ============================================================================
  // PATIENT EDUCATION MATERIALS
  // ============================================================================
  
  patient_education: {
    
    diabetes_basics: {
      what_is_it: "Diabetes is a condition where blood sugar levels are too high because your body doesn't make enough insulin or doesn't use insulin properly.",
      why_control_matters: "High blood sugar over time damages blood vessels and nerves, leading to heart disease, stroke, kidney disease, vision loss, and nerve damage.",
      target_a1c: "Most people with diabetes should aim for A1C below 7%. This reduces risk of complications.",
      self_monitoring: "Check blood sugar as recommended by your provider. Keep a log. Look for patterns."
    },
    
    diet_for_diabetes: {
      carbohydrate_awareness: "Carbs raise blood sugar most. Focus on portion control, not elimination.",
      plate_method: "Fill half plate with non-starchy vegetables, quarter with lean protein, quarter with whole grains or starchy vegetables.",
      foods_to_emphasize: ["Vegetables", "Lean proteins", "Whole grains", "Healthy fats (nuts, olive oil, avocado)"],
      foods_to_limit: ["Sugary drinks", "Sweets and desserts", "White bread and pasta", "Fried foods"]
    },
    
    sglt2_inhibitor_education: {
      how_it_works: "This medication helps your kidneys remove extra sugar through your urine.",
      benefits: "Lowers blood sugar, helps with weight loss, protects your heart and kidneys.",
      side_effects_common: "More likely to get yeast infections because sugar in urine. Stay well-hydrated.",
      when_to_call: "Severe abdominal pain, nausea/vomiting that won't stop, trouble breathing - could be rare but serious ketoacidosis.",
      prevention_tips: "Good hygiene, stay hydrated, continue taking even if you're not eating much (unless instructed to hold)"
    },
    
    glp1_agonist_education: {
      how_it_works: "Helps your pancreas make insulin when blood sugar is high, slows digestion, reduces appetite.",
      injection_technique: "Inject under the skin in abdomen, thigh, or upper arm. Rotate sites. Once weekly same day.",
      nausea_management: [
        "Eat smaller, more frequent meals",
        "Avoid fatty or spicy foods",
        "Stay hydrated",
        "Usually improves after 4-8 weeks",
        "Don't stop medication without talking to your provider"
      ],
      when_to_call: "Severe abdominal pain (especially radiating to back), persistent vomiting, signs of allergic reaction"
    },
    
    blood_pressure_management: {
      why_it_matters: "High blood pressure damages blood vessels, increasing risk of heart attack, stroke, and kidney disease.",
      lifestyle_changes: [
        "Lose weight if overweight (even 5-10 lbs helps)",
        "Reduce sodium to less than 2300mg per day",
        "Exercise 30 minutes most days",
        "Limit alcohol",
        "Manage stress"
      ],
      medication_adherence: "Take blood pressure medications every day, even if you feel fine. High BP usually has no symptoms.",
      home_monitoring: "Check BP at home if possible. Take multiple readings at different times."
    }
  }
};

// ============================================================================
// CLINICAL DECISION SUPPORT FUNCTIONS
// ============================================================================

export const ClinicalDecisionSupport = {
  
  // Generate treatment recommendations based on patient data
  generateDiabetesRecommendations: function(patientData) {
    const a1c = patientData.labs_latest.a1c.value;
    const currentMeds = patientData.clinical_summary.current_medications;
    const problems = patientData.clinical_summary.active_problems;
    
    const recommendations = [];
    
    // Check if on metformin
    const onMetformin = currentMeds.some(m => m.name.toLowerCase() === 'metformin');
    
    if (!onMetformin && a1c > 6.5) {
      recommendations.push({
        priority: "high",
        recommendation: "Start metformin as first-line therapy",
        rationale: "ADA guidelines recommend metformin as initial pharmacologic therapy unless contraindicated",
        dose: "Start 500mg BID with meals, titrate to 1000mg BID over 4-8 weeks"
      });
    }
    
    // If A1C above goal on metformin alone
    if (onMetformin && a1c >= 7.0) {
      const hasCV Disease = problems.some(p => p.problem.includes('cardiovascular') || p.problem.includes('heart'));
      const hasCKD = problems.some(p => p.problem.includes('CKD') || p.problem.includes('kidney'));
      const isObese = patientData.vitals_current.bmi > 30;
      
      if (hasCKD || hasCV Disease) {
        recommendations.push({
          priority: "high",
          recommendation: "Add GLP-1 agonist (semaglutide) for multi-system protection",
          rationale: "Patient has CKD/CV disease. GLP-1 provides glycemic control plus proven cardiovascular and renal benefits (SUSTAIN-6, FLOW trials)",
          dose: "Semaglutide 0.25mg SC weekly x 4 weeks, then 0.5mg weekly",
          expected_benefit: "1.5-2% A1C reduction, 10-15 lbs weight loss, CV and renal protection"
        });
      }
      
      if (hasCKD && !currentMeds.some(m => m.name.includes('empagliflozin'))) {
        recommendations.push({
          priority: "high",
          recommendation: "Consider SGLT2 inhibitor for renal protection",
          rationale: "Strong evidence for slowing CKD progression. Can be used with GLP-1.",
          caveat: "Patient previously stopped empagliflozin due to recurrent candidiasis. May consider after GLP-1 is stable, or try different SGLT2i (canagliflozin or dapagliflozin)"
        });
      }
    }
    
    return recommendations;
  },
  
  // Check for medication appropriateness
  assessMedicationSafety: function(patientData) {
    const safety_checks = [];
    const creatinine = patientData.labs_latest.creatinine.value;
    const egfr = patientData.labs_latest.egfr.value;
    const meds = patientData.clinical_summary.current_medications;
    
    // Check metformin dosing with renal function
    const metformin = meds.find(m => m.name.toLowerCase() === 'metformin');
    if (metformin && egfr < 30) {
      safety_checks.push({
        severity: "critical",
        issue: "Metformin contraindicated with eGFR < 30",
        action: "DISCONTINUE metformin immediately"
      });
    } else if (metformin && egfr < 45) {
      safety_checks.push({
        severity: "moderate",
        issue: "Metformin dose should be reduced with eGFR 30-45",
        action: "Consider reducing dose to 1000mg daily maximum"
      });
    }
    
    // Check for drug interactions
    const interactions = CLINICAL_KNOWLEDGE_BASE.checkDrugInteractions(meds);
    interactions.forEach(interaction => {
      safety_checks.push({
        severity: interaction.severity,
        issue: `Interaction between ${interaction.drug1} and ${interaction.drug2}`,
        detail: interaction.interaction,
        action: interaction.recommendation
      });
    });
    
    return safety_checks;
  },
  
  // Generate lab monitoring schedule
  generateMonitoringPlan: function(patientData) {
    const schedule = [];
    const problems = patientData.clinical_summary.active_problems;
    const meds = patientData.clinical_summary.current_medications;
    
    // Diabetes monitoring
    if (problems.some(p => p.problem.includes('Diabetes'))) {
      schedule.push({
        test: "Hemoglobin A1C",
        frequency: patientData.labs_latest.a1c.value < 7 ? "Every 6 months" : "Every 3 months",
        rationale: "Monitor glycemic control"
      });
      
      schedule.push({
        test: "Urine microalbumin-to-creatinine ratio",
        frequency: "Annually",
        rationale: "Screen for diabetic nephropathy"
      });
      
      schedule.push({
        test: "Dilated eye exam",
        frequency: "Annually",
        rationale: "Screen for diabetic retinopathy"
      });
    }
    
    // CKD monitoring
    if (problems.some(p => p.problem.includes('CKD'))) {
      const ckdStage = problems.find(p => p.problem.includes('CKD')).problem;
      const frequency = ckdStage.includes('3a') ? "Every 6 months" : "Every 3 months";
      
      schedule.push({
        test: "Basic Metabolic Panel (creatinine, eGFR, electrolytes)",
        frequency: frequency,
        rationale: "Monitor kidney function progression"
      });
    }
    
    // ACE inhibitor monitoring
    if (meds.some(m => m.name.toLowerCase().includes('lisinopril'))) {
      schedule.push({
        test: "Potassium and Creatinine",
        frequency: "1-2 weeks after starting/dose change, then every 3-6 months",
        rationale: "Monitor for hyperkalemia and acute kidney injury"
      });
    }
    
    // Statin monitoring
    if (meds.some(m => m.name.toLowerCase().includes('statin'))) {
      schedule.push({
        test: "Lipid panel",
        frequency: "Annually if at goal",
        rationale: "Assess treatment efficacy"
      });
    }
    
    return schedule;
  }
};

export default CLINICAL_KNOWLEDGE_BASE;