import React, { useState, useEffect } from 'react';
import { Mic, Send, User, Calendar, Activity, FileText, Clock, AlertCircle, CheckCircle, XCircle } from 'lucide-react';

// ============================================================================
// CLINICAL KNOWLEDGE BASE - Embedded Medical Intelligence
// ============================================================================

const CLINICAL_KNOWLEDGE = {
  medications: {
    metformin: {
      class: "Biguanide",
      a1c_reduction: "1-2%",
      benefits: "First-line, inexpensive, CV neutral, weight neutral",
      side_effects: "GI upset (diarrhea, nausea), lactic acidosis (rare)",
      dosing: "500-1000mg BID with meals, max 2550mg/day",
      contraindications: "eGFR <30",
      monitoring: "Renal function annually, B12 every 2-3 years"
    },
    empagliflozin: {
      class: "SGLT2 Inhibitor",
      a1c_reduction: "0.5-0.8%",
      benefits: "Weight loss, CV protection, renal protection, reduces HF hospitalizations",
      side_effects: "Genital infections (10% women), UTIs, volume depletion, DKA (rare)",
      dosing: "10-25mg daily",
      cv_benefit: "38% reduction in CV death (EMPA-REG)",
      renal_benefit: "Slows CKD progression",
      note: "Sarah stopped due to recurrent yeast infections"
    },
    semaglutide: {
      class: "GLP-1 Agonist",
      a1c_reduction: "1.5-2.0%",
      weight_loss: "10-15 lbs over 6 months",
      benefits: "Strong A1C reduction, weight loss, CV protection, renal protection",
      side_effects: "Nausea (15-20%, usually transient), vomiting, diarrhea",
      dosing: "Start 0.25mg SC weekly x4 weeks (tolerance building), then 0.5mg weekly, may increase to 1mg",
      cv_benefit: "26% reduction in major CV events (SUSTAIN-6)",
      renal_benefit: "24% reduction in kidney disease progression (FLOW trial 2024)",
      monitoring: "Watch for nausea, pancreatitis symptoms",
      counseling: "Nausea common but improves, take with food, rotate injection sites",
      insurance: "Tier 3, usually covered without PA after metformin trial"
    },
    lisinopril: {
      class: "ACE Inhibitor",
      benefits: "BP control, renal protection in diabetes/CKD, CV protection",
      side_effects: "Dry cough (10-20%), hyperkalemia, AKI (usually reversible)",
      dosing: "10-40mg daily for HTN",
      monitoring: "K+ and Cr within 1-2 weeks of starting, then every 3-6 months",
      note: "Small Cr rise (up to 30%) acceptable and indicates appropriate renal protection"
    }
  },
  
  drug_interactions: {
    check: function(medList) {
      const interactions = [];
      const meds = medList.map(m => m.name.toLowerCase());
      
      if (meds.includes('lisinopril') && meds.includes('empagliflozin')) {
        interactions.push({
          severity: "moderate",
          drugs: "Lisinopril + Empagliflozin",
          interaction: "Both can cause volume depletion and AKI",
          recommendation: "Monitor volume status and renal function closely"
        });
      }
      
      return interactions;
    }
  },
  
  clinical_protocols: {
    diabetes_treatment: {
      step1: "Metformin first-line unless contraindicated",
      step2_with_ckd_cvd: "Add GLP-1 agonist (semaglutide) for CV and renal protection",
      step2_with_ckd: "SGLT2i provides renal protection but consider patient tolerance",
      a1c_goal: "<7% for most, <8% for elderly/frail, <6.5% for early disease"
    },
    
    ckd_management: {
      stage_3a: "eGFR 45-59, monitor every 6 months, continue ACE-I/ARB",
      albuminuria_a2: "UACR 30-300, indicates kidney damage, intensify ACE-I/ARB and add SGLT2i or GLP-1",
      metformin_safety: "Safe to eGFR 30, reduce dose 30-45, stop if <30",
      sglt2_use: "Can initiate if eGFR â‰¥20, continue for renal protection"
    },
    
    hypertension_goals: {
      diabetes_ckd: "<130/80 mmHg",
      first_line: "ACE-I or ARB for diabetes/CKD"
    }
  },
  
  decision_support: {
    diabetes_recommendations: function(a1c, currentMeds, hasCV, hasCKD, bmi) {
      const recs = [];
      
      const onMetformin = currentMeds.some(m => m.name.toLowerCase().includes('metformin'));
      const onGLP1 = currentMeds.some(m => m.name.toLowerCase().includes('semaglutide') || m.name.toLowerCase().includes('ozempic'));
      const onSGLT2 = currentMeds.some(m => m.name.toLowerCase().includes('empagliflozin') || m.name.toLowerCase().includes('jardiance'));
      
      if (!onMetformin && a1c >= 6.5) {
        recs.push({
          priority: "high",
          action: "Start metformin 500mg BID, titrate to 1000mg BID",
          rationale: "First-line per ADA guidelines"
        });
      }
      
      if (onMetformin && a1c >= 7.0 && !onGLP1 && (hasCV || hasCKD || bmi > 30)) {
        recs.push({
          priority: "high",
          action: "Add semaglutide (Ozempic) 0.25mg weekly x4 weeks, then 0.5mg weekly",
          rationale: `Patient has ${hasCKD ? 'CKD' : ''}${hasCV ? ' CV disease' : ''}${bmi > 30 ? ' obesity' : ''}. GLP-1 provides: 1.5-2% A1C reduction, 10-15 lbs weight loss, CV protection (26% event reduction), renal protection (24% slowed progression).`,
          evidence: "SUSTAIN-6 trial (CV), FLOW trial 2024 (renal)",
          expected_benefit: "A1C should drop from 8.4% to ~6.9-7.4% over 3-6 months"
        });
      }
      
      if (hasCKD && !onSGLT2 && a1c >= 7.0) {
        recs.push({
          priority: "moderate",
          action: "Consider restarting SGLT2i (different agent than empagliflozin)",
          rationale: "Strong renal protection. Patient stopped empagliflozin due to yeast infections - could try canagliflozin or dapagliflozin after GLP-1 is stable.",
          timing: "Wait 4-8 weeks after starting GLP-1 to assess tolerance"
        });
      }
      
      return recs;
    },
    
    medication_safety: function(egfr, meds) {
      const alerts = [];
      
      meds.forEach(med => {
        if (med.name.toLowerCase().includes('metformin') && egfr < 30) {
          alerts.push({
            severity: "critical",
            drug: "Metformin",
            issue: "Contraindicated with eGFR <30",
            action: "DISCONTINUE immediately"
          });
        } else if (med.name.toLowerCase().includes('metformin') && egfr < 45) {
          alerts.push({
            severity: "moderate",
            drug: "Metformin",
            issue: "Dose should be reduced with eGFR 30-45",
            action: "Consider max 1000mg daily"
          });
        }
      });
      
      return alerts;
    }
  }
};

// ============================================================================
// PATIENT DATA - Sarah Mitchell
// ============================================================================

const PATIENT_DATA = {
  patient_id: "P001",
  mrn: "MRN-2018-04792",
  demographics: {
    name: { first: "Sarah", middle: "Ann", last: "Mitchell", preferred: "Sarah" },
    dob: "1963-01-15",
    age: 62,
    sex: "F"
  },
  clinical_summary: {
    active_problems: [
      {
        problem: "Type 2 Diabetes Mellitus",
        status: "Uncontrolled",
        last_a1c: { value: 8.4, date: "2024-10-09", trend: "worsening" },
        notes: "Patient self-discontinued empagliflozin in August 2024 due to recurrent vulvovaginal candidiasis. Control has worsened since."
      },
      {
        problem: "Chronic Kidney Disease Stage 3a",
        status: "Progressive",
        last_egfr: { value: 52, date: "2024-10-09", trend: "declining" },
        last_creatinine: { value: 1.3, date: "2024-10-09" },
        albuminuria: { uacr: 45, date: "2024-10-09", category: "moderately increased", new_finding: true }
      },
      {
        problem: "Hypertension",
        status: "Suboptimally controlled",
        recent_bp: "142/88",
        goal: "<130/80"
      },
      {
        problem: "Obesity",
        bmi: 32.1,
        weight_trend: "+8 lbs in 3 months"
      }
    ],
    current_medications: [
      {
        name: "Metformin",
        dose: "1000mg",
        frequency: "twice daily",
        indication: "Type 2 Diabetes",
        last_fill: "2024-09-25",
        adherence: { rate: 0.95, status: "Excellent adherence" }
      },
      {
        name: "Lisinopril",
        dose: "20mg",
        frequency: "once daily",
        indication: "Hypertension, CKD protection",
        last_fill: "2024-09-18",
        adherence: { rate: 0.92, status: "Good adherence" }
      },
      {
        name: "Atorvastatin",
        dose: "20mg",
        frequency: "once daily at bedtime",
        indication: "Hyperlipidemia",
        last_fill: "2024-09-30",
        adherence: { rate: 0.89, status: "Good adherence" }
      },
      {
        name: "Aspirin",
        dose: "81mg",
        frequency: "once daily",
        indication: "Primary prevention - diabetes with CV risk",
        otc: true
      }
    ],
    discontinued_medications: [
      {
        name: "Empagliflozin (Jardiance)",
        dose: "25mg daily",
        stop_date: "2024-08-20",
        reason: "Patient self-discontinued due to recurrent vulvovaginal candidiasis",
        clinical_impact: "A1C worsened from 7.2 to 8.4 after discontinuation",
        urgent_care_visits: [
          { date: "2024-03-28", reason: "Vulvovaginal candidiasis", treatment: "Fluconazole 150mg" },
          { date: "2024-04-19", reason: "Recurrent vulvovaginal candidiasis", treatment: "Fluconazole 150mg" }
        ],
        pharmacy_evidence: {
          last_fill: "2024-03-15",
          expected_run_out: "2024-04-14",
          refill_requested: false,
          patient_informed_provider: false,
          discovered: "Pharmacy records review at today's visit"
        }
      }
    ],
    allergies: [
      { allergen: "Penicillin", reaction: "Rash", severity: "Moderate" },
      { allergen: "Sulfa drugs", reaction: "Hives", severity: "Moderate" }
    ]
  },
  vitals_current: {
    date: "2024-10-09",
    bp: "142/88",
    pulse: 76,
    weight: 187,
    height: 64,
    bmi: 32.1,
    weight_change_3mo: "+8 lbs",
    weight_history: [
      { date: "2024-10-09", weight: 187 },
      { date: "2024-07-15", weight: 179 },
      { date: "2024-04-10", weight: 181 }
    ]
  },
  labs_latest: {
    date: "2024-10-09",
    a1c: { 
      value: 8.4, 
      previous: 7.8,
      change: "+0.6 from 3 months ago",
      trend: [
        { date: "2024-10-09", value: 8.4 },
        { date: "2024-07-15", value: 7.8 },
        { date: "2024-04-10", value: 7.2 },
        { date: "2024-01-08", value: 7.5 }
      ]
    },
    creatinine: { 
      value: 1.3, 
      previous: 1.0,
      change: "up from 1.0 nine months ago",
      trend: [
        { date: "2024-10-09", value: 1.3 },
        { date: "2024-07-15", value: 1.2 },
        { date: "2024-04-10", value: 1.0 },
        { date: "2024-01-08", value: 1.1 }
      ]
    },
    egfr: { 
      value: 52, 
      previous: 68,
      stage: "CKD Stage 3a",
      trend: [
        { date: "2024-10-09", value: 52 },
        { date: "2024-07-15", value: 58 },
        { date: "2024-04-10", value: 68 }
      ]
    },
    microalbumin: { 
      value: 45, 
      category: "Moderately increased (A2)",
      status: "NEW FINDING - indicates diabetic nephropathy",
      previous: "Normal (<30) on all prior tests",
      clinical_significance: "Early kidney damage, requires intensification of treatment"
    },
    bmp: {
      sodium: 138,
      potassium: 4.2,
      glucose: 214
    },
    lipids: {
      ldl: 98,
      hdl: 52,
      triglycerides: 156,
      ldl_goal: "<100 for diabetes",
      at_goal: true
    }
  },
  visit_history: [
    {
      date: "2024-07-15",
      a1c: 7.8,
      notes: "A1C increased from 7.2. Patient admitted dietary indiscretion. Still thought to be on empagliflozin at this time."
    },
    {
      date: "2024-04-10",
      a1c: 7.2,
      notes: "Excellent response to SGLT2i. A1C improved from 7.5 to 7.2. Patient very happy with medication. Weight down 4 lbs."
    }
  ],
  today_visit: {
    date: "2024-10-09",
    time: "08:00",
    reason: "Diabetes and hypertension follow-up, lab review",
    chief_complaint: "Here for routine diabetes and blood pressure check with lab results",
    key_issues: [
      "A1C significantly worsened to 8.4% (up from 7.2 when on SGLT2i)",
      "New finding of microalbuminuria 45 - indicates diabetic nephropathy",
      "Patient stopped Jardiance without telling us - discovered via pharmacy records",
      "Weight gain of 8 pounds in 3 months",
      "BP elevated at 142/88, above goal",
      "Kidney function declining (eGFR 52, down from 68)"
    ],
    clinical_decisions_needed: [
      "Intensify diabetes management - A1C 8.4% requires additional agent",
      "Address new kidney damage - microalbuminuria requires action",
      "BP management - currently above goal",
      "Weight management approach"
    ]
  },
  social_history: {
    occupation: "Administrative assistant",
    marital_status: "Married",
    exercise: "Minimal - walking program lapsed 6 weeks ago",
    diet: "Admits difficulty with carbohydrate control, evening snacking",
    stressors: "Mother in early-stage dementia, patient is primary caregiver coordinator"
  },
  insurance: {
    carrier: "Blue Cross Blue Shield of Georgia",
    plan: "PPO Silver Plus",
    ozempic_coverage: "Tier 3, no prior auth required after metformin trial",
    copay: "$25-35 for tier 3 with current deductible status"
  }
};

// ============================================================================
// MAIN COMPONENT
// ============================================================================

const AI_EHR_Demo = () => {
  const [mode, setMode] = useState('schedule');
  const [query, setQuery] = useState('');
  const [conversation, setConversation] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showAmbientInfo, setShowAmbientInfo] = useState(true);

  useEffect(() => {
    if (mode === 'briefing' && conversation.length === 0) {
      handleMorningBriefing();
    } else if (mode === 'pre-visit' && conversation.length === 0) {
      handlePreVisitBriefing();
    } else if (mode === 'in-room' && conversation.length === 0) {
      handleRoomEntry();
    }
  }, [mode]);

  const handleMorningBriefing = async () => {
    setIsProcessing(true);
    const briefing = await queryAI(
      "Provide a concise morning briefing for Sarah Mitchell's 8am visit. Focus on the THREE critical issues that need immediate attention based on her latest labs. Be specific about values and clinical significance. This should take 30 seconds to read."
    );
    
    setConversation([{
      role: 'assistant',
      content: briefing,
      timestamp: new Date().toLocaleTimeString()
    }]);
    setIsProcessing(false);
  };

  const handlePreVisitBriefing = async () => {
    setIsProcessing(true);
    const briefing = await queryAI(
      "Provide a comprehensive pre-visit briefing for Sarah Mitchell. Include: (1) What's her clinical trajectory since last visit? (2) What key lab findings do I need to know? (3) Why did her diabetes worsen? (4) What treatment decisions will I need to make today? Use specific data. This is my preparation before entering the room."
    );
    
    setConversation([{
      role: 'assistant',
      content: briefing,
      timestamp: new Date().toLocaleTimeString()
    }]);
    setIsProcessing(false);
  };

  const handleRoomEntry = async () => {
    setIsProcessing(true);
    const briefing = await queryAI(
      "I just entered the exam room with Sarah Mitchell. Give me the essential information I need RIGHT NOW in 2-3 sentences: today's vital signs, the main clinical issue, and what I should focus on."
    );
    
    setConversation([{
      role: 'assistant',
      content: briefing,
      timestamp: new Date().toLocaleTimeString()
    }]);
    setIsProcessing(false);
  };

  const queryAI = async (userQuery) => {
    const systemPrompt = `You are an AI clinical assistant integrated into an Electronic Health Record system. You provide evidence-based decision support to physicians in real-time.

COMPLETE PATIENT DATA:
${JSON.stringify(PATIENT_DATA, null, 2)}

CLINICAL KNOWLEDGE BASE:
${JSON.stringify(CLINICAL_KNOWLEDGE, null, 2)}

YOUR ROLE:
- Answer questions using BOTH the patient data AND clinical knowledge base
- Speak like a knowledgeable colleague, not a computer
- Be concise but thorough - physicians are busy
- Provide specific values, dates, and trends
- When recommending treatments, cite evidence and expected outcomes
- Explain clinical significance of findings
- Proactively mention safety issues (drug interactions, contraindications)
- Use clinical knowledge to enhance recommendations

CLINICAL CONTEXT:
- Patient: Sarah Mitchell, 62-year-old with T2DM, CKD 3a, HTN, obesity
- Today's visit: Diabetes worsening, new kidney damage found
- Key issue: She secretly stopped Jardiance 2 months ago due to yeast infections
- Decision needed: What medication to add for her diabetes given CKD and obesity

RESPONSE STYLE:
- Short paragraphs, easy to scan
- Use specific numbers and dates
- Explain WHY things matter clinically
- Suggest next steps or decisions when appropriate
- If asked about treatment options, use the clinical decision support functions

Current query: ${userQuery}`;

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 2000,
          messages: [
            { role: "user", content: systemPrompt }
          ]
        })
      });

      const data = await response.json();
      return data.content[0].text;
    } catch (error) {
      console.error("AI Query Error:", error);
      return "I'm having trouble accessing the clinical data right now. Please try again.";
    }
  };

  const handleSendQuery = async () => {
    if (!query.trim() || isProcessing) return;

    const userMessage = {
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString()
    };

    setConversation(prev => [...prev, userMessage]);
    setQuery('');
    setIsProcessing(true);

    const response = await queryAI(query);

    setConversation(prev => [...prev, {
      role: 'assistant',
      content: response,
      timestamp: new Date().toLocaleTimeString()
    }]);

    setIsProcessing(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendQuery();
    }
  };

  const handleDocumentation = async () => {
    setIsProcessing(true);
    const doc = await queryAI(
      "Generate a complete SOAP note for today's visit. Include: Chief Complaint, HPI (mention she stopped Jardiance without informing us, why her A1C worsened), Physical Exam (use vitals provided), Labs Reviewed (A1C 8.4 up from 7.2, new microalbuminuria 45, Cr 1.3 up from 1.0), Assessment & Plan for EACH problem: (1) Type 2 Diabetes uncontrolled - start semaglutide 0.25mg weekly with titration plan and rationale; (2) CKD Stage 3a with new albuminuria - continue ACE-I, note GLP-1 provides renal protection; (3) HTN not at goal - continue current, recheck in 6 weeks; (4) Obesity - anticipate weight loss with GLP-1. Include patient counseling provided and follow-up plan in 6 weeks. Use standard medical documentation format."
    );
    
    setConversation([{
      role: 'assistant',
      content: doc,
      timestamp: new Date().toLocaleTimeString()
    }]);
    setIsProcessing(false);
  };

  // UI Components
  const ScheduleView = () => (
    <div className="flex flex-col items-center justify-center h-full space-y-6 p-8">
      <Calendar className="w-16 h-16 text-blue-600" />
      <h2 className="text-2xl font-semibold text-gray-800">Today's Schedule</h2>
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-yellow-50 border-l-4 border-yellow-500 rounded">
            <div className="flex items-center space-x-4">
              <Clock className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="font-semibold text-gray-800">8:00 AM - Sarah Mitchell, 62</p>
                <p className="text-sm text-gray-600">Diabetes & HTN follow-up â€¢ Lab review</p>
                <p className="text-xs text-red-600 font-semibold mt-1">âš ï¸ A1C worsened to 8.4% â€¢ New kidney damage</p>
              </div>
            </div>
            <AlertCircle className="w-5 h-5 text-yellow-600" />
          </div>
          <div className="p-4 bg-gray-50 border-l-4 border-gray-300 rounded opacity-50">
            <p className="font-semibold text-gray-600">8:30 AM - Michael Torres, 34</p>
            <p className="text-sm text-gray-500">New patient â€¢ ADHD evaluation</p>
          </div>
          <div className="p-4 bg-gray-50 border-l-4 border-gray-300 rounded opacity-50">
            <p className="font-semibold text-gray-600">9:00 AM - Jennifer Walsh, 45</p>
            <p className="text-sm text-gray-500">Annual wellness visit</p>
          </div>
        </div>
        <div className="mt-6 pt-4 border-t space-y-3">
          <button
            onClick={() => setMode('briefing')}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold flex items-center justify-center space-x-2"
          >
            <Activity className="w-5 h-5" />
            <span>Start Day - Morning Briefing</span>
          </button>
          <p className="text-xs text-gray-500 text-center">
            AI will automatically brief you on critical issues before you start seeing patients
          </p>
        </div>
      </div>
    </div>
  );

  const AmbientInfoPanel = () => {
    if (!showAmbientInfo) return null;
    
    return (
      <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-lg shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <User className="w-6 h-6" />
            <div>
              <h3 className="text-xl font-semibold">Sarah Mitchell, 62</h3>
              <p className="text-sm text-gray-400">DOB: 01/15/1963 â€¢ MRN: 2018-04792</p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-slate-700 p-3 rounded">
            <p className="text-xs text-gray-400">Blood Pressure</p>
            <p className="text-lg font-semibold text-red-400">142/88 â†‘</p>
            <p className="text-xs text-gray-400">Goal: &lt;130/80</p>
          </div>
          <div className="bg-slate-700 p-3 rounded">
            <p className="text-xs text-gray-400">Weight</p>
            <p className="text-lg font-semibold text-yellow-400">187 lbs â†‘</p>
            <p className="text-xs text-gray-400">+8 lbs/3mo</p>
          </div>
          <div className="bg-slate-700 p-3 rounded">
            <p className="text-xs text-gray-400">A1C</p>
            <p className="text-lg font-semibold text-red-400">8.4% â†‘â†‘</p>
            <p className="text-xs text-gray-400">was 7.2</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-slate-700 p-3 rounded">
            <p className="text-xs text-gray-400">Creatinine</p>
            <p className="text-base font-semibold text-yellow-400">1.3 â†‘</p>
            <p className="text-xs text-gray-400">was 1.0</p>
          </div>
          <div className="bg-slate-700 p-3 rounded">
            <p className="text-xs text-gray-400">eGFR</p>
            <p className="text-base font-semibold text-yellow-400">52 â†“</p>
            <p className="text-xs text-gray-400">CKD 3a</p>
          </div>
        </div>

        <div className="space-y-2 text-sm mb-4">
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
            <p className="text-gray-300">T2DM â€¢ CKD 3a â€¢ HTN â€¢ Obesity</p>
          </div>
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
            <p className="text-gray-300">Allergies: Penicillin, Sulfa</p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-600">
          <p className="text-xs text-gray-400 mb-2">ðŸ”´ Critical Today</p>
          <div className="space-y-1 text-sm">
            <p className="text-red-300">â€¢ New microalbuminuria (kidney damage)</p>
            <p className="text-yellow-300">â€¢ Stopped Jardiance without telling us</p>
            <p className="text-yellow-300">â€¢ A1C worsened 7.2 â†’ 8.4</p>
          </div>
        </div>

        {mode === 'in-room' && (
          <div className="mt-4 pt-4 border-t border-slate-600">
            <p className="text-xs text-gray-400 mb-2">Today's Plan</p>
            <p className="text-sm text-green-300">Consider GLP-1 (renal + CV protection)</p>
          </div>
        )}
      </div>
    );
  };

  const ConversationView = () => (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {conversation.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-3xl rounded-lg p-4 ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white shadow-md text-gray-800'
              }`}
            >
              <div className="flex items-start space-x-2">
                {msg.role === 'assistant' && (
                  <Activity className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                )}
                <div className="flex-1">
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                  <p className="text-xs mt-2 opacity-70">{msg.timestamp}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
        {isProcessing && (
          <div className="flex justify-start">
            <div className="bg-white shadow-md rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-blue-600 animate-pulse" />
                <p className="text-gray-600">Processing clinical data...</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {mode !== 'schedule' && mode !== 'documentation' && (
        <div className="border-t bg-white p-4">
          <div className="flex space-x-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask anything: 'A1C trend?' â€¢ 'Treatment options?' â€¢ 'When last filled Jardiance?' â€¢ 'Drug interactions?'"
              className="flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              disabled={isProcessing}
            />
            <button
              onClick={handleSendQuery}
              disabled={isProcessing || !query.trim()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <button
              onClick={() => setQuery("What's her A1C trend over the past year?")}
              className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-gray-700"
            >
              ðŸ“Š A1C trend
            </button>
            <button
              onClick={() => setQuery("What are my treatment options for her diabetes given she has CKD?")}
              className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-gray-700"
            >
              ðŸ’Š Treatment options
            </button>
            <button
              onClick={() => setQuery("When did she last fill the Jardiance and why did she stop?")}
              className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-gray-700"
            >
              ðŸ” Jardiance history
            </button>
            <button
              onClick={() => setQuery("Any drug interactions with her current medications?")}
              className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-gray-700"
            >
              âš ï¸ Interactions
            </button>
            <button
              onClick={() => setQuery("What's the evidence for GLP-1 agonists in patients with CKD?")}
              className="text-xs bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-gray-700"
            >
              ðŸ“š GLP-1 evidence
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const ModeSelector = () => (
    <div className="bg-white border-b px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex space-x-2">
          <button
            onClick={() => { setMode('schedule'); setConversation([]); }}
            className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
              mode === 'schedule' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            ðŸ“… Schedule
          </button>
          <button
            onClick={() => { setMode('briefing'); setConversation([]); }}
            className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
              mode === 'briefing' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            ðŸŒ… Morning Briefing
          </button>
          <button
            onClick={() => { setMode('pre-visit'); setConversation([]); }}
            className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
              mode === 'pre-visit' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            ðŸ“‹ Pre-Visit
          </button>
          <button
            onClick={() => { setMode('in-room'); setConversation([]); }}
            className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
              mode === 'in-room' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            ðŸ¥ In Room
          </button>
          <button
            onClick={() => { setMode('documentation'); setConversation([]); handleDocumentation(); }}
            className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${
              mode === 'documentation' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            ðŸ“ Documentation
          </button>
        </div>
        <div className="text-sm text-gray-600">
          {mode === 'schedule' && 'ðŸ“Š View today\'s schedule'}
          {mode === 'briefing' && 'ðŸ¤– AI synthesizes critical information'}
          {mode === 'pre-visit' && 'ðŸ” Comprehensive visit preparation'}
          {mode === 'in-room' && 'ðŸ’¬ Real-time clinical decision support'}
          {mode === 'documentation' && 'âš¡ Auto-generate complete note'}
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">AI-Powered EHR System</h1>
            <p className="text-sm text-blue-100">Live Demonstration: Transforming Healthcare with Artificial Intelligence</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-semibold">Dr. Michael Chen</p>
              <p className="text-xs text-blue-100">Macon Primary Care</p>
            </div>
            <User className="w-10 h-10 bg-blue-500 rounded-full p-2" />
          </div>
        </div>
      </div>

      <ModeSelector />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Ambient Info */}
        {(mode === 'pre-visit' || mode === 'in-room') && (
          <div className="w-80 p-6 border-r bg-gray-50 overflow-y-auto">
            <AmbientInfoPanel />
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden">
          {mode === 'schedule' ? <ScheduleView /> : <ConversationView />}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white border-t px-6 py-3">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <p>
            <span className="font-semibold">Demo Status:</span> AI-powered EHR with embedded clinical intelligence â€¢ 
            Patient data simulated â€¢ Clinical knowledge base active
          </p>
          <p className="text-xs">Thursday, October 09, 2025 â€¢ 8:00 AM</p>
        </div>
      </div>
    </div>
  );
};

export default AI_EHR_Demo;