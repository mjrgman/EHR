# AI-EHR MODULE VERIFICATION CHECKLIST

## Use this to verify the workflow is working correctly

---

## ✅ STEP 1: STARTING THE DAY

Test: Say "What's on my schedule today?"

**Required Response:**
- [ ] Responds via VOICE (not just text)
- [ ] Summarizes ALL 6 patients
- [ ] Highlights 3-4 critical cases
- [ ] Mentions specific clinical issues
- [ ] Identifies decisions needed today
- [ ] Completes in under 2 minutes
- [ ] No clicking or typing required

**PASS/FAIL: _____**

---

## ✅ STEP 2: PREPARING FOR PATIENT

Test: Say "Prep me on Sarah Mitchell"

**Required Response:**
- [ ] Provides 60-90 second briefing
- [ ] Includes patient age and reason for visit
- [ ] Explains clinical trajectory since last visit
- [ ] Lists current medications
- [ ] Reviews recent labs with trends
- [ ] Identifies critical issues for TODAY
- [ ] Mentions A1C 8.4%, stopped Jardiance, kidney damage
- [ ] Recommends GLP-1 agonist needed

**PASS/FAIL: _____**

---

## ✅ STEP 3: REAL-TIME CLINICAL SUPPORT

Test: Say "Start her on Ozempic"

**Required Response:**
- [ ] Confirms order immediately
- [ ] Provides dosing (0.25mg weekly → 0.5mg)
- [ ] Explains benefits (A1C reduction, weight loss)
- [ ] Mentions side effects (nausea)
- [ ] Cites evidence (FLOW trial, 24% CKD reduction)
- [ ] Confirms insurance coverage
- [ ] States prescription sent to pharmacy
- [ ] All via VOICE

Test: Say "Increase lisinopril to 40mg"

**Required Response:**
- [ ] Confirms change
- [ ] Notes appropriate for kidney function (eGFR 52)
- [ ] Recommends recheck labs in 1 week
- [ ] Updates internal medication list

**PASS/FAIL: _____**

---

## ✅ STEP 4: EVIDENCE-BASED DECISION SUPPORT

Test: Say "What's the evidence for GLP-1s in kidney disease?"

**Required Response:**
- [ ] Cites FLOW trial 2024
- [ ] Mentions 24% reduction in CKD progression
- [ ] References SUSTAIN-6 for CV benefits
- [ ] Provides concise, evidence-based answer
- [ ] Under 60 seconds

Test: Say "Any drug interactions?"

**Required Response:**
- [ ] Checks medication list immediately
- [ ] Identifies lisinopril + any potassium-sparing agent
- [ ] Recommends monitoring if applicable
- [ ] Provides safety guidance

Test: Say "What medications is she on now?"

**Required Response:**
- [ ] Lists metformin, lisinopril, atorvastatin
- [ ] **INCLUDES Ozempic (just added)**
- [ ] **SHOWS lisinopril 40mg (just increased)**
- [ ] PROVES state management works
- [ ] Remembers ALL changes from THIS conversation

**PASS/FAIL: _____**

---

## ✅ STEP 5: AUTOMATED DOCUMENTATION

Test: Say "Document this visit"

**Required Response:**
- [ ] Generates complete SOAP note
- [ ] Includes HPI with relevant details
- [ ] Lists medication changes: Ozempic started, lisinopril increased
- [ ] Provides rationale: A1C control, CKD progression
- [ ] Lists orders: Labs in 6 weeks
- [ ] Includes follow-up plan
- [ ] Includes billing justification
- [ ] Generated in SECONDS (not minutes)
- [ ] ALL decisions from conversation included

**PASS/FAIL: _____**

---

## ✅ CRITICAL MEMORY TEST

Run this sequence WITHOUT PAUSING:

1. Say: "Start Sarah on Ozempic"
2. Wait for response
3. Say: "Order A1C in 6 weeks"
4. Wait for response
5. Say: "What changes did we make for Sarah today?"

**Required Response:**
- [ ] Remembers Ozempic was started
- [ ] Remembers A1C ordered
- [ ] Lists BOTH changes accurately
- [ ] Maintains state across multiple commands
- [ ] NO loss of context

**PASS/FAIL: _____**

---

## ✅ MULTI-PATIENT TEST

Run this sequence:

1. Say: "Prep me on Sarah Mitchell"
2. Say: "Start her on Ozempic"
3. Say: "Who's next?"
4. Say: "Prep me on Robert Williams"
5. Say: "Recommend admission for IV diuresis"
6. Say: "What did we decide for Sarah?"

**Required Response:**
- [ ] Maintains separate state for Sarah and Robert
- [ ] When asked about Sarah at step 6, recalls Ozempic
- [ ] Does NOT confuse Sarah and Robert
- [ ] Tracks multiple patients simultaneously

**PASS/FAIL: _____**

---

## ✅ VOICE INTERACTION QUALITY

Test: Use ONLY voice for 5 minutes

**Required:**
- [ ] Understands natural speech (not just perfect diction)
- [ ] Handles medical terminology correctly
- [ ] Responds conversationally (not robotic)
- [ ] Confirms actions clearly via voice
- [ ] No typing or clicking needed at any point

**PASS/FAIL: _____**

---

## ✅ TIMING REQUIREMENTS

**Measure actual times:**

Morning briefing duration: _____ seconds (must be <120)
Patient prep duration: _____ seconds (must be 60-90)
Medication order response: _____ seconds (must be <45)
Documentation generation: _____ seconds (must be <30)

**All timing requirements met: YES / NO**

---

## FINAL VERIFICATION

### Core Workflow Test

Complete this full sequence without any failures:

1. ✅ Morning briefing (under 2 min)
2. ✅ Patient prep (60-90 sec)
3. ✅ Medication order (confirmed with reasoning)
4. ✅ Clinical question (evidence-based answer)
5. ✅ State verification (remembers changes)
6. ✅ Documentation (complete SOAP note)

**All steps completed successfully: YES / NO**

---

## MODULE STATUS

**READY FOR DEMONSTRATION:** ✅ / ❌

**If ANY checkbox is unchecked, the module is NOT working correctly.**

**If ANY timing requirement is not met, the workflow is NOT efficient enough.**

**If state management fails AT ALL, the module is NOT functional.**

---

## This workflow is NON-NEGOTIABLE

Every feature must work.
Every timing must be met.
Every memory test must pass.

**Only deploy when ALL checks pass.**